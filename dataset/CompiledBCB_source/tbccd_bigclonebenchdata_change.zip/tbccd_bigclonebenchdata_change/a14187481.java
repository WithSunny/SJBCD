import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14187481 {
public UNKNOWN ONLY;
public UNKNOWN LOG;
	public UNKNOWN DrJava;
	public UNKNOWN Version;
	public UNKNOWN OptionConstants;
	public UNKNOWN getSurveyURL(){ return null; }
	public UNKNOWN maySubmitSurvey(){ return null; }
	public UNKNOWN noAction(){ return null; }
    protected void yesAction()  throws Throwable {
        try {
            String result = getSurveyURL() + "&buildtime=" + Version.getBuildTimeString();
            LOG.log(result);
            if (!(Boolean)(Object)maySubmitSurvey()) {
                return;
            }
            BufferedReader br = null;
            try {
                URL url = new URL(result);
                InputStream urls = url.openStream();
                InputStreamReader is = new InputStreamReader(urls);
                br = new BufferedReader(is);
                String line;
                StringBuilder sb = new StringBuilder();
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                    sb.append(System.getProperty("line.separator"));
                }
                LOG.log(sb.toString());
            } catch (IOException e) {
                LOG.log("Could not open URL using Java", e);
                try {
                    ONLY.openURL(new URL(result));
                    DrJava.getConfig().setSetting(OptionConstants.LAST_DRJAVA_SURVEY_RESULT, result);
                } catch (IOException e2) {
                    LOG.log("Could not open URL using web browser", e2);
                }
            } finally {
                try {
                    if (br != null) br.close();
                } catch (IOException e) {
                }
            }
        } finally {
            noAction();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN LAST_DRJAVA_SURVEY_RESULT;
	public UNKNOWN getConfig(){ return null; }
	public UNKNOWN getBuildTimeString(){ return null; }
	public UNKNOWN setSetting(UNKNOWN o0, String o1){ return null; }
	public UNKNOWN log(String o0, IOException o1){ return null; }
	public UNKNOWN log(String o0){ return null; }
	public UNKNOWN openURL(URL o0){ return null; }
}
