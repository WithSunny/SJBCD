import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14911883 {
    public boolean smsResponse(String customerPhoneNumber) throws Throwable, ClientProtocolException, IOException {
        boolean message = true;
        String textMessage = "La%20sua%20prenotazione%20e%60%20andata%20a%20buon%20fine";
        DefaultHttpClient httpclient = new DefaultHttpClient();
        String uri = "http://smswizard.globalitalia.it/smsgateway/send.asp";
        String other = "http://smswizard.globalitalia.it/smsgateway/send.asp";
        String url = uri + "?" + "Account=sardricerche" + "&Password=v8LomdZT" + "&PhoneNumbers=" + "%2b393285683484" + "&SMSData=" + textMessage + "&Recipients=1" + "&Sender=Web Hotel" + "&ID=11762";
        String urlProva = other + "?" + "Account=sardricerche" + "&Password=v8LomdZT" + "&PhoneNumbers=" + customerPhoneNumber + "&SMSData=" + textMessage + "&Recipients=1" + "&Sender=+393337589951" + "&ID=11762";
        HttpPost httpPost = new HttpPost(urlProva);
        HttpResponse response =(HttpResponse)(Object) httpclient.execute(httpPost);
        HttpEntity entity =(HttpEntity)(Object) response.getEntity();
        return message;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ClientProtocolException extends Exception{
	public ClientProtocolException(String errorMessage) { super(errorMessage); }
}

class DefaultHttpClient {
	
	public UNKNOWN execute(HttpPost o0){ return null; }
}

class HttpPost {
	
	HttpPost(){}
	HttpPost(String o0){}
}

class HttpResponse {
	
	public UNKNOWN getEntity(){ return null; }
}

class HttpEntity {
	
	
}
