import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a11843018 {
public UNKNOWN SubjectPublicKeyInfo;
	public UNKNOWN id;
    public  void RespID(PublicKey key) throws Throwable, OCSPException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA1");
            ASN1InputStream aIn = new ASN1InputStream(key.getEncoded());
            SubjectPublicKeyInfo info =(SubjectPublicKeyInfo)(Object) SubjectPublicKeyInfo.getInstance(aIn.readObject());
            digest.update((byte)(Object)info.getPublicKeyData().getBytes());
            ASN1OctetString keyHash =(ASN1OctetString)(Object) new DEROctetString(digest.digest());
            this.id =(UNKNOWN)(Object) new ResponderID(keyHash);
        } catch (Exception e) {
            throw new OCSPException("problem creating ID: " + e, e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getInstance(UNKNOWN o0){ return null; }
	public UNKNOWN getBytes(){ return null; }
}

class OCSPException extends Exception{
	public OCSPException(String errorMessage) { super(errorMessage); }
	OCSPException(String o0, Exception o1){}
	OCSPException(){}
}

class ASN1InputStream {
	
	ASN1InputStream(byte[] o0){}
	ASN1InputStream(){}
	public UNKNOWN readObject(){ return null; }
}

class SubjectPublicKeyInfo {
	
	public UNKNOWN getPublicKeyData(){ return null; }
}

class ASN1OctetString {
	
	
}

class DEROctetString {
	
	DEROctetString(byte[] o0){}
	DEROctetString(){}
}

class ResponderID {
	
	ResponderID(){}
	ResponderID(ASN1OctetString o0){}
}
