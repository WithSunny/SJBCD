import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10785896 {
public UNKNOWN pageContext;
	public UNKNOWN hexDigit(byte o0){ return null; }
	public UNKNOWN getId(){ return null; }
    private void createProperty(String objectID, String value, String propertyID, Long userID) throws Throwable, JspTagException {
        ClassProperty classProperty = new ClassProperty(new Long(propertyID));
        String newValue = value;
        if (classProperty.getName().equals("Password")) {
            try {
                MessageDigest crypt = MessageDigest.getInstance("MD5");
                crypt.update(value.getBytes());
                byte digest[] = crypt.digest();
                StringBuffer hexString = new StringBuffer();
                for (int i = 0; i < digest.length; i++) {
                    hexString.append(hexDigit(digest[i]));
                }
                newValue = hexString.toString();
                crypt.reset();
            } catch (NoSuchAlgorithmException e) {
                System.err.println("jspShop: Could not get instance of MD5 algorithm. Please fix this!" + e.getMessage());
                e.printStackTrace();
                throw new JspTagException("Error crypting password!: " + e.getMessage());
            }
        }
        Properties properties = new Properties(new Long(objectID), userID);
        try {
            Property property =(Property)(Object) properties.create(new Long(propertyID), newValue);
            pageContext.setAttribute(getId(), property);
        } catch (ArithmeticException e) {
            throw new JspTagException("Could not create PropertyValue, CreateException: " + e.getMessage());
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN setAttribute(UNKNOWN o0, Property o1){ return null; }
}

class JspTagException extends Exception{
	public JspTagException(String errorMessage) { super(errorMessage); }
}

class ClassProperty {
	
	ClassProperty(Long o0){}
	ClassProperty(){}
	public UNKNOWN getName(){ return null; }
}

class Properties {
	
	Properties(Long o0, Long o1){}
	public UNKNOWN create(Long o0, String o1){ return null; }
}

class Property {
	
	
}

class CreateException extends Exception{
	public CreateException(String errorMessage) { super(errorMessage); }
}
