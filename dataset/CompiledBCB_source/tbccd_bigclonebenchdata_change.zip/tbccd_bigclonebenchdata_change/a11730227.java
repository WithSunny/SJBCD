import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a11730227 {
    private void copy(File source, File target) throws Throwable, IOException {
        FileChannel in =(FileChannel)(Object) (new FileInputStream(source)).getChannel();
        FileChannel out =(FileChannel)(Object) (new FileOutputStream(target)).getChannel();
        in.transferTo(0, source.length(), out);
        in.close();
        out.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, long o1, FileChannel o2){ return null; }
	public UNKNOWN close(){ return null; }
}
