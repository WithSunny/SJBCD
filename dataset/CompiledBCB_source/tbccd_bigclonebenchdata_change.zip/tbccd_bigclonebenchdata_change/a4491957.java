import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4491957 {
public UNKNOWN getCurrentPath(){ return null; }
	public UNKNOWN reList(){ return null; }
    public void copyToCurrentDir(File _copyFile, String _fileName) throws Throwable, IOException {
        File outputFile = new File(getCurrentPath() + File.separator + _fileName);
        FileReader in;
        FileWriter out;
        if (!outputFile.exists()) {
            outputFile.createNewFile();
        }
        in = new FileReader(_copyFile);
        out = new FileWriter(outputFile);
        int c;
        while ((c = in.read()) != -1) out.write(c);
        in.close();
        out.close();
        reList();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
