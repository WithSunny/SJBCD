import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1235538 {
    public static String encrypt(final String pass)  throws Throwable {
        try {
            final MessageDigest md = MessageDigest.getInstance("SHA");
            md.update(pass.getBytes("UTF-8"));
            return new String((String)(Object)Base64.encodeBase64(md.digest()));
        } catch (final Exception e) {
            throw new RuntimeException("No se pudo encriptar el password.", e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Base64 {
	
	public static UNKNOWN encodeBase64(byte[] o0){ return null; }
}
