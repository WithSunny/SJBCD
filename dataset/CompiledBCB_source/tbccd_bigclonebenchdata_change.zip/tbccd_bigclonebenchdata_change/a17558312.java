import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17558312 {
public UNKNOWN panel;
	public UNKNOWN getLoginId(){ return null; }
	public UNKNOWN getLoginName(){ return null; }
	public UNKNOWN getNewsHTML(){ return null; }
	public UNKNOWN getOnlineInformationHTML(){ return null; }
	public UNKNOWN getLibName(){ return null; }
	public UNKNOWN getOpenCatalogHTMLCode(){ return null; }
	public UNKNOWN getPendingJobsHTMLCode(){ return null; }
	public UNKNOWN getFrequentlyUsedScreensHTMLCode(){ return null; }
	public UNKNOWN getVerusSubscriptionIdHTML(){ return null; }
    public void fillData()  throws Throwable {
        try {
            URL urlhome = OpenerIF.class.getResource("Home.html");
            URLConnection uc = urlhome.openConnection();
            InputStreamReader input = new InputStreamReader(uc.getInputStream());
            BufferedReader in = new BufferedReader(input);
            String inputLine;
            String htmlData = "";
            while ((inputLine = in.readLine()) != null) {
                htmlData += inputLine;
            }
            in.close();
            String[] str = new String[9];
            str[0] =(String)(Object) getLibName();
            str[1] =(String)(Object) getLoginId();
            str[2] =(String)(Object) getLoginName();
            str[3] =(String)(Object) getVerusSubscriptionIdHTML();
            str[4] =(String)(Object) getPendingJobsHTMLCode();
            str[5] =(String)(Object) getFrequentlyUsedScreensHTMLCode();
            str[6] =(String)(Object) getOpenCatalogHTMLCode();
            str[7] =(String)(Object) getNewsHTML();
            str[8] =(String)(Object) getOnlineInformationHTML();
            MessageFormat mf = new MessageFormat(htmlData);
            String htmlContent =(String)(Object) mf.format(htmlData, str);
            PrintWriter fw = new PrintWriter(System.getProperty("user.home") + "/homeNGL.html");
            fw.println(htmlContent);
            fw.flush();
            fw.close();
            new LocalHtmlRendererContext(panel, new SimpleUserAgentContext(), this).navigate("file:" + System.getProperty("user.home") + "/homeNGL.html");
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class OpenerIF {
	
	
}

class MessageFormat {
	
	MessageFormat(String o0){}
	MessageFormat(){}
	public UNKNOWN format(String o0, String[] o1){ return null; }
}

class LocalHtmlRendererContext {
	
	LocalHtmlRendererContext(UNKNOWN o0, SimpleUserAgentContext o1, a17558312 o2){}
	LocalHtmlRendererContext(){}
	public UNKNOWN navigate(String o0){ return null; }
}

class SimpleUserAgentContext {
	
	
}
