import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12847055 {
public UNKNOWN AnnotationElement;
public UNKNOWN defaults;
	public UNKNOWN log;
	public UNKNOWN props;
        public  void MobileAgentProperties(Class declaringClass, String propertyFile) throws Throwable, IOException {
            this.defaults =(UNKNOWN)(Object) (MobileAgent)(MobileAgent)(Object) AnnotationElement.getAnyAnnotation(declaringClass, MobileAgent.class);
            URL url = getClass().getClassLoader().getResource(propertyFile);
            if (url != null) {
                props.load(url.openStream());
                log.info("MobileAgent parameters loaded from file " + url);
            }
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getAnyAnnotation(Class o0, Class o1){ return null; }
	public UNKNOWN load(InputStream o0){ return null; }
	public UNKNOWN info(String o0){ return null; }
}

class MobileAgent {
	
	
}
