import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23677128 {
	public FTPClient sample3a(String ftpserver, int ftpport, String proxyserver, int proxyport, String username, String password) throws Throwable, SocketException, IOException {
		FTPHTTPClient ftpClient = new FTPHTTPClient(proxyserver, proxyport);
		ftpClient.connect(ftpserver, ftpport);
		ftpClient.login(username, password);
		return(FTPClient)(Object) ftpClient;
	}
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FTPClient {
	
	
}

class FTPHTTPClient {
	
	FTPHTTPClient(String o0, int o1){}
	FTPHTTPClient(){}
	public UNKNOWN connect(String o0, int o1){ return null; }
	public UNKNOWN login(String o0, String o1){ return null; }
}
