import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1607809 {
public UNKNOWN NULL;
	public UNKNOWN _key_col;
	public UNKNOWN _table_name;
	public UNKNOWN _ts_col;
	public UNKNOWN _oid_col;
	public UNKNOWN _ds;
	public UNKNOWN getLock(String o0){ return null; }
    public void lock(String oid, String key) throws Throwable, PersisterException {
        String lock =(String)(Object) getLock(oid);
        if (lock == null) {
            throw new PersisterException("Object does not exist: OID = " + oid);
        } else if (!NULL.equals(lock) && (!lock.equals(key))) {
            throw new PersisterException("The object is currently locked with another key: OID = " + oid + ", LOCK = " + lock + ", KEY = " + key);
        }
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn =(Connection)(Object) _ds.getConnection();
            conn.setAutoCommit(true);
            ps =(PreparedStatement)(Object) conn.prepareStatement("update " + _table_name + " set " + _key_col + " = ?, " + _ts_col + " = ? where " + _oid_col + " = ?");
            ps.setString(1, key);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, oid);
            ps.executeUpdate();
        } catch (Throwable th) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (Throwable th2) {
                }
            }
            throw new PersisterException("Failed to lock object: OID = " + oid + ", KEY = " + key, th);
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                } catch (Throwable th) {
                }
            }
            if (conn != null) {
                try {
                    conn.close();
                } catch (Throwable th) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getConnection(){ return null; }
}

class PersisterException extends Exception{
	public PersisterException(String errorMessage) { super(errorMessage); }
	PersisterException(){}
	PersisterException(String o0, Throwable o1){}
}

class Connection {
	
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN close(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN setLong(int o0, long o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN setString(int o0, String o1){ return null; }
	public UNKNOWN close(){ return null; }
}
