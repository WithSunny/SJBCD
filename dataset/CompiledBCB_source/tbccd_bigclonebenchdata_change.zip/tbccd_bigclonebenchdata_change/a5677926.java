import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a5677926 {
    public static void copyFile(File source, File destination) throws Throwable, IOException {
        FileInputStream fis = new FileInputStream(source);
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(destination);
            FileChannel sourceChannel =(FileChannel)(Object) fis.getChannel();
            FileChannel destinationChannel =(FileChannel)(Object) fos.getChannel();
            sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
            destinationChannel.close();
            sourceChannel.close();
        } finally {
            if (fos != null) fos.close();
            fis.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN size(){ return null; }
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
}
