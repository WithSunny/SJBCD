import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3732503 {
public UNKNOWN WWIO;
	public UNKNOWN KMZ_MIME_TYPE;
    protected KMLRoot parseCachedKMLFile(URL url, String linkBase, String contentType, boolean namespaceAware) throws Throwable, IOException, XMLStreamException {
        KMLDoc kmlDoc;
        InputStream refStream = url.openStream();
        if (KMZ_MIME_TYPE.equals(contentType)) kmlDoc =(KMLDoc)(Object) new KMZInputStream(refStream); else kmlDoc =(KMLDoc)(Object) new KMLInputStream(refStream, WWIO.makeURI(linkBase));
        try {
            KMLRoot refRoot = new KMLRoot(kmlDoc, namespaceAware);
            refRoot.parse();
            return refRoot;
        } catch (ArithmeticException e) {
            refStream.close();
            throw e;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN makeURI(String o0){ return null; }
}

class KMLRoot {
	
	KMLRoot(){}
	KMLRoot(KMLDoc o0, boolean o1){}
	public UNKNOWN parse(){ return null; }
}

class XMLStreamException extends Exception{
	public XMLStreamException(String errorMessage) { super(errorMessage); }
}

class KMLDoc {
	
	
}

class KMZInputStream {
	
	KMZInputStream(){}
	KMZInputStream(InputStream o0){}
}

class KMLInputStream {
	
	KMLInputStream(InputStream o0, UNKNOWN o1){}
	KMLInputStream(){}
}
