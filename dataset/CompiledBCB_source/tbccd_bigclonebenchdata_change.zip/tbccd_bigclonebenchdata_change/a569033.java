import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a569033 {
public UNKNOWN load(InputStream o0){ return null; }
    public  void Configuration(URL url)  throws Throwable {
        InputStream in = null;
        try {
            load(in = url.openStream());
        } catch (Exception e) {
            throw new RuntimeException("Could not load configuration from " + url, e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignore) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
