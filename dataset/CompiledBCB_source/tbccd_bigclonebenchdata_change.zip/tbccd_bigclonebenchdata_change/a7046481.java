import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7046481 {
public UNKNOWN ImageIO;
	public UNKNOWN url;
	public UNKNOWN width;
	public UNKNOWN descent;
	public UNKNOWN ascent;
    public  a7046481(URL url)  throws Throwable {
        super();
        this.url =(UNKNOWN)(Object) url;
        try {
            URLConnection urlConn = url.openConnection();
            urlConn.setReadTimeout(15000);
            ImageInputStream iis =(ImageInputStream)(Object) ImageIO.createImageInputStream(urlConn.getInputStream());
            Iterator<ImageReader> readers =(Iterator<ImageReader>)(Object) ImageIO.getImageReaders(iis);
            if (readers.hasNext()) {
                ImageReader reader = readers.next();
                reader.setInput(iis, true);
                this.width = reader.getWidth(0);
                this.ascent = reader.getHeight(0);
                this.descent =(UNKNOWN)(Object) 0;
                reader.dispose();
            } else System.err.println("cannot read width and height of image " + url + " - no suitable reader!");
        } catch (Exception exc) {
            System.err.println("cannot read width and height of image " + url + " due to exception:");
            System.err.println(exc);
            exc.printStackTrace(System.err);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN createImageInputStream(InputStream o0){ return null; }
	public UNKNOWN getImageReaders(ImageInputStream o0){ return null; }
}

class ImageInputStream {
	
	
}

class ImageReader {
	
	public UNKNOWN setInput(ImageInputStream o0, boolean o1){ return null; }
	public UNKNOWN dispose(){ return null; }
	public UNKNOWN getHeight(int o0){ return null; }
	public UNKNOWN getWidth(int o0){ return null; }
}
