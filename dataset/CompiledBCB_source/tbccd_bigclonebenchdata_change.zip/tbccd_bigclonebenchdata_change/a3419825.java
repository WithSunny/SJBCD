import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3419825 {
    public static void copyFile(File sourceFile, File destFile) throws Throwable, IOException {
        if (!destFile.exists()) {
            destFile.createNewFile();
        }
        FileChannel source = null;
        FileChannel destination = null;
        try {
            source = (FileChannel)(Object)new FileInputStream(sourceFile).getChannel();
            destination = (FileChannel)(Object)new FileOutputStream(destFile).getChannel();
            destination.transferFrom(source, 0, source.size());
        } finally {
            if (source != null) {
                source.close();
            }
            if (destination != null) {
                destination.close();
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN transferFrom(FileChannel o0, int o1, UNKNOWN o2){ return null; }
}
