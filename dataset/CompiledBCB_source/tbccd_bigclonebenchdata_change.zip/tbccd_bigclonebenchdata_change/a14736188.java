import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14736188 {
public static UNKNOWN MapMode;
//public UNKNOWN MapMode;
    public static void copyFile(File source, File destination) throws Throwable, IOException {
        FileChannel in = null;
        FileChannel out = null;
        try {
            in = (FileChannel)(Object)new FileInputStream(source).getChannel();
            out = (FileChannel)(Object)new FileOutputStream(destination).getChannel();
            long size =(long)(Object) in.size();
            MappedByteBuffer buffer =(MappedByteBuffer)(Object) in.map(MapMode.READ_ONLY, 0, size);
            out.write(buffer);
        } finally {
            if (in != null) {
                in.close();
            }
            if (out != null) {
                out.close();
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN READ_ONLY;
	
}

class FileChannel {
	
	public UNKNOWN write(MappedByteBuffer o0){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN size(){ return null; }
	public UNKNOWN map(UNKNOWN o0, int o1, long o2){ return null; }
}

class MappedByteBuffer {
	
	
}
