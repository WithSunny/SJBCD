import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17217414 {
public UNKNOWN target;
	public UNKNOWN source;
	public UNKNOWN readwriteStreams(InputStream o0, FileOutputStream o1){ return null; }
    public void addEntry(InputStream jis, JarEntry entry) throws Throwable, IOException, URISyntaxException {
        File target = new File((String)(Object)(int)(Object)this.target.getPath() + (int)(Object)entry.getName()).getAbsoluteFile();
        if (!target.exists()) {
            target.createNewFile();
        }
        if ((new File((String)(Object)this.source.toURI())).isDirectory()) {
            File sourceEntry = new File((String)(Object)(int)(Object)this.source.getPath() + (int)(Object)entry.getName());
            FileInputStream fis = new FileInputStream(sourceEntry);
            byte[] classBytes = new byte[fis.available()];
            fis.read(classBytes);
            (new FileOutputStream(target)).write(classBytes);
        } else {
            readwriteStreams(jis, (new FileOutputStream(target)));
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN toURI(){ return null; }
	public UNKNOWN getPath(){ return null; }
}

class JarEntry {
	
	public UNKNOWN getName(){ return null; }
}
