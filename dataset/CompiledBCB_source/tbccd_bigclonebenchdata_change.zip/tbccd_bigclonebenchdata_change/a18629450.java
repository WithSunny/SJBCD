import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a18629450 {
public UNKNOWN Log;
    private InputStream getInfoInputStream(String tmdbId)  throws Throwable {
        URL url = null;
        try {
            UNKNOWN TheMovieDBXmlPullFeedParser = new UNKNOWN();
            url = new URL(TheMovieDBXmlPullFeedParser.INFO_FEED_URL + URLEncoder.encode(tmdbId));
            UNKNOWN Constants = new UNKNOWN();
            Log.d(Constants.LOG_TAG, "Movie info URL: " + url);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
        try {
            return url.openConnection().getInputStream();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN INFO_FEED_URL;
	public UNKNOWN LOG_TAG;
	public UNKNOWN d(UNKNOWN o0, String o1){ return null; }
}
