import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15333826 {
    public synchronized String encrypt(String password)  throws Throwable {
        try {
            MessageDigest md = null;
            md = MessageDigest.getInstance("SHA-1");
            md.update(password.getBytes("UTF-8"));
            byte raw[] = md.digest();
            byte[] hash =(byte[])(Object) (new Base64()).encode(raw);
            return new String(hash);
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Algorithm SHA-1 is not supported");
            return null;
        } catch (UnsupportedEncodingException e) {
            System.out.println("UTF-8 encoding is not supported");
            return null;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Base64 {
	
	public UNKNOWN encode(byte[] o0){ return null; }
}
