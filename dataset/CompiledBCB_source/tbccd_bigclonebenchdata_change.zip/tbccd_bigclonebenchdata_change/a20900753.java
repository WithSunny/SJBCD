import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20900753 {
    public boolean isServerAlive(String pStrURL)  throws Throwable {
        boolean isAlive;
        long t1 = System.currentTimeMillis();
        try {
            URL url = new URL(pStrURL);
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                UNKNOWN logger = new UNKNOWN();
                logger.fine(inputLine);
            }
            UNKNOWN logger = new UNKNOWN();
            logger.info("**  Connection successful..  **");
            in.close();
            isAlive = true;
        } catch (Exception e) {
            UNKNOWN logger = new UNKNOWN();
            logger.info("**  Connection failed..  **");
            e.printStackTrace();
            isAlive = false;
        }
        long t2 = System.currentTimeMillis();
        UNKNOWN logger = new UNKNOWN();
        logger.info("Time taken to check connection: " + (t2 - t1) + " ms.");
        return isAlive;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN fine(String o0){ return null; }
}
