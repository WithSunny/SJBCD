import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8694461 {
public UNKNOWN getURL(){ return null; }
    public InputStream getFtpInputStream() throws Throwable, IOException {
        try {
            URL url =(URL)(Object) getURL();
            URLConnection urlc = url.openConnection();
            return urlc.getInputStream();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
