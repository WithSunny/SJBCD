import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7704001 {
public UNKNOWN FidoDataSource;
	public UNKNOWN bumpAllRowsUp(Statement o0, int o1, int o2){ return null; }
    public void deleteGroupInstruction(int id, int rank) throws Throwable, FidoDatabaseException, InstructionNotFoundException {
        try {
            Connection conn = null;
            Statement stmt = null;
            try {
                conn =(Connection)(Object) FidoDataSource.getConnection();
                conn.setAutoCommit(false);
                stmt =(Statement)(Object) conn.createStatement();
                String sql = "delete from InstructionGroups " + "where InstructionId = " + id + " and Rank = " + rank;
                stmt.executeUpdate(sql);
                bumpAllRowsUp(stmt, id, rank);
                conn.commit();
            } catch (ArithmeticException e) {
                if (conn != null) conn.rollback();
                throw e;
            } finally {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new FidoDatabaseException((String)(Object)e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getConnection(){ return null; }
}

class FidoDatabaseException extends Exception{
	public FidoDatabaseException(String errorMessage) { super(errorMessage); }
}

class InstructionNotFoundException extends Exception{
	public InstructionNotFoundException(String errorMessage) { super(errorMessage); }
}

class Connection {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN createStatement(){ return null; }
}

class Statement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
