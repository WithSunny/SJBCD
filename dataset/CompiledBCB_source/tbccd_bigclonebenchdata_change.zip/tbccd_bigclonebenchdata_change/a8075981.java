import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8075981 {
public UNKNOWN Charset;
	public UNKNOWN tryOpenConnection(String o0){ return null; }
    public char[] getDataAsCharArray(String url)  throws Throwable {
        try {
            char[] dat = null;
            URLConnection urlc;
            if (!url.toUpperCase().startsWith("HTTP://") && !url.toUpperCase().startsWith("HTTPS://")) {
                urlc =(URLConnection)(Object) tryOpenConnection(url);
            } else {
                urlc = new URL(url).openConnection();
            }
            urlc.setUseCaches(false);
            urlc.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            urlc.setRequestProperty("User-Agent", "Mozilla/5.0 (X11; U; Linux x86_64; en-GB; rv:1.9.1.9) Gecko/20100414 Iceweasel/3.5.9 (like Firefox/3.5.9)");
            urlc.setRequestProperty("Accept-Encoding", "gzip");
            InputStream is = urlc.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is,(String)(Object) Charset.defaultCharset()));
            int len = urlc.getContentLength();
            dat = new char[len];
            int i = 0;
            int c;
            while ((c = reader.read()) != -1) {
                char character = (char) c;
                dat[i] = character;
                i++;
            }
            is.close();
            return dat;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN defaultCharset(){ return null; }
}
