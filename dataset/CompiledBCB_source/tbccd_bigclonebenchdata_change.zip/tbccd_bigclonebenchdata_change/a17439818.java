import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17439818 {
    public static void copyFile(File source, File dest) throws Throwable, Exception {
        FileChannel in = null;
        FileChannel out = null;
        try {
            in = (FileChannel)(Object)new FileInputStream(source).getChannel();
            out = (FileChannel)(Object)new FileOutputStream(dest).getChannel();
            in.transferTo(0, in.size(), out);
        } catch (Exception e) {
            throw new Exception("Cannot copy file " + source.getAbsolutePath() + " to " + dest.getAbsolutePath(), e);
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
                if (out != null) {
                    out.close();
                }
            } catch (Exception e) {
                throw new Exception("Cannot close streams.", e);
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN size(){ return null; }
}
