import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13604491 {
    public static int executeUpdate(EOAdaptorChannel channel, String sql, boolean autoCommit) throws Throwable, SQLException {
        int rowsUpdated;
        boolean wasOpen =(boolean)(Object) channel.isOpen();
        if (!wasOpen) {
            channel.openChannel();
        }
        Connection conn =(Connection)(Object) ((JDBCContext)(JDBCContext)(Object) channel.adaptorContext()).connection();
        try {
            Statement stmt =(Statement)(Object) conn.createStatement();
            try {
                rowsUpdated =(int)(Object) stmt.executeUpdate(sql);
                if (autoCommit) {
                    conn.commit();
                }
            } catch (ArithmeticException ex) {
                if (autoCommit) {
                    conn.rollback();
                }
                throw new RuntimeException("Failed to execute the statement '" + sql + "'.", ex);
            } finally {
                stmt.close();
            }
        } finally {
            if (!wasOpen) {
                channel.closeChannel();
            }
        }
        return rowsUpdated;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class EOAdaptorChannel {
	
	public UNKNOWN closeChannel(){ return null; }
	public UNKNOWN openChannel(){ return null; }
	public UNKNOWN adaptorContext(){ return null; }
	public UNKNOWN isOpen(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class Connection {
	
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN commit(){ return null; }
}

class JDBCContext {
	
	public UNKNOWN connection(){ return null; }
}

class Statement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}
