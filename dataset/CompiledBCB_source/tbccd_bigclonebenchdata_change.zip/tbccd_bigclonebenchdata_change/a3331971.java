import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3331971 {
public UNKNOWN userId;
	public UNKNOWN accessibility;
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN getTags(){ return null; }
	public UNKNOWN getTitle(){ return null; }
	public UNKNOWN getRequestCycle(){ return null; }
	public UNKNOWN getContent(){ return null; }
    protected void onSubmit()  throws Throwable {
        try {
            Connection conn =(Connection)(Object) ((JdbcRequestCycle)(JdbcRequestCycle)(Object) getRequestCycle()).getConnection();
            String sql = "insert into entry (author, accessibility) values(?,?)";
            PreparedStatement pstmt =(PreparedStatement)(Object) conn.prepareStatement(sql);
            pstmt.setInt(1, userId);
            pstmt.setInt(2, accessibility.getId());
            pstmt.executeUpdate();
            ResultSet insertedEntryIdRs =(ResultSet)(Object) pstmt.getGeneratedKeys();
            insertedEntryIdRs.next();
            int insertedEntryId =(int)(Object) insertedEntryIdRs.getInt(1);
            sql = "insert into revisions (title, entry, content, tags," + " revision_remark) values(?,?,?,?,?)";
            PreparedStatement pstmt2 =(PreparedStatement)(Object) conn.prepareStatement(sql);
            pstmt2.setString(1, getTitle());
            pstmt2.setInt(2, insertedEntryId);
            pstmt2.setString(3, getContent());
            pstmt2.setString(4, getTags());
            pstmt2.setString(5, "newly added");
            int insertCount =(int)(Object) pstmt2.executeUpdate();
            if (insertCount > 0) {
                info("Successfully added one new record.");
            } else {
                conn.rollback();
                info("Addition of one new record failed.");
            }
        } catch (ArithmeticException ex) {
            ex.printStackTrace();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getId(){ return null; }
}

class Connection {
	
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN rollback(){ return null; }
}

class JdbcRequestCycle {
	
	public UNKNOWN getConnection(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN setString(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN setString(int o0, String o1){ return null; }
	public UNKNOWN getGeneratedKeys(){ return null; }
	public UNKNOWN setInt(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN setInt(int o0, int o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
}

class ResultSet {
	
	public UNKNOWN getInt(int o0){ return null; }
	public UNKNOWN next(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
