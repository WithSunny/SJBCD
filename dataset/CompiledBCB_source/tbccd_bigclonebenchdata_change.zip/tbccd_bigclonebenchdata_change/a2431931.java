import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2431931 {
    public String encrypt(String pstrPlainText) throws Throwable, Exception {
        if (pstrPlainText == null) {
            return "";
        }
        MessageDigest md = MessageDigest.getInstance("SHA");
        md.update(pstrPlainText.getBytes("UTF-8"));
        byte raw[] = md.digest();
        return(String)(Object) (new BASE64Encoder()).encode(raw);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class BASE64Encoder {
	
	public UNKNOWN encode(byte[] o0){ return null; }
}
