import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a11622990 {
public UNKNOWN terms;
	public UNKNOWN modelMean;
	public UNKNOWN modelStddev;
	public UNKNOWN parseAndAdd(List o0, String o1){ return null; }
    public  void ContourGenerator(URL url, float modelMean, float modelStddev) throws Throwable, IOException {
        this.modelMean =(UNKNOWN)(Object) modelMean;
        this.modelStddev =(UNKNOWN)(Object) modelStddev;
        List termsList = new ArrayList();
        String line;
        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
        line = reader.readLine();
        while (line != null) {
            if (!line.startsWith("***")) {
                parseAndAdd(termsList, line);
            }
            line = reader.readLine();
        }
        terms =(UNKNOWN)(Object) (F0ModelTerm[]) termsList.toArray((Object[])(Object)terms);
        reader.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class F0ModelTerm {
	
	
}
