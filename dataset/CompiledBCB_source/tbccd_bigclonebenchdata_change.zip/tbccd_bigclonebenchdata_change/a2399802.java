import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2399802 {
    public static InputStream getInputStream(String fileName) throws IOException {
        InputStream input;
        if (fileName.startsWith("http:")) {
            URL url = new URL(fileName);
            URLConnection connection = url.openConnection();
            input = connection.getInputStream();
        } else {
            input = new FileInputStream(fileName);
        }
        return input;
    }
}