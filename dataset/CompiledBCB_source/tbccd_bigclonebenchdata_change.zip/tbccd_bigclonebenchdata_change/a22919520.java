import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22919520 {
public static UNKNOWN MapMode;
//public UNKNOWN MapMode;
    public static void copyFile(String sourceFilePath, String destFilePath) throws Throwable, IOException {
        FileChannel in = null;
        FileChannel out = null;
        try {
            in = (FileChannel)(Object)new FileInputStream(sourceFilePath).getChannel();
            out = (FileChannel)(Object)new FileOutputStream(destFilePath).getChannel();
            long inputSize =(long)(Object) in.size();
            in.transferTo(0, inputSize, out);
            MappedByteBuffer buf =(MappedByteBuffer)(Object) in.map(MapMode.READ_ONLY, 0, inputSize);
            out.write(buf);
        } finally {
            if (in != null) in.close();
            if (out != null) out.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN READ_ONLY;
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, long o1, FileChannel o2){ return null; }
	public UNKNOWN map(UNKNOWN o0, int o1, long o2){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN write(MappedByteBuffer o0){ return null; }
	public UNKNOWN size(){ return null; }
}

class MappedByteBuffer {
	
	
}
