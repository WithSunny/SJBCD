import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2451974 {
//    @Override
    public void doHandler(HttpServletRequest request, HttpServletResponse response) throws Throwable, IOException, ServletException {
        if ((int)(Object)request.getRequestURI().indexOf("png") != -1) {
            response.setContentType("image/png");
        } else if ((int)(Object)request.getRequestURI().indexOf("gif") != -1) {
            response.setContentType("image/gif");
        } else {
            response.setContentType("image/x-icon");
        }
        BufferedOutputStream bos = new BufferedOutputStream((OutputStream)(Object)response.getOutputStream());
        try {
            UNKNOWN configCenter = new UNKNOWN();
            URL url = new URL("http://" + configCenter.getUcoolOnlineIp() + request.getRequestURI());
            BufferedInputStream in = new BufferedInputStream(url.openStream());
            byte[] data = new byte[4096];
            int size = in.read(data);
            while (size != -1) {
                bos.write(data, 0, size);
                size = in.read(data);
            }
            in.close();
            bos.flush();
            bos.close();
            in.close();
        } catch (Exception e) {
        }
        bos.flush();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getUcoolOnlineIp(){ return null; }
	public UNKNOWN indexOf(String o0){ return null; }
}

class HttpServletRequest {
	
	public UNKNOWN getRequestURI(){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN setContentType(String o0){ return null; }
	public UNKNOWN getOutputStream(){ return null; }
}

class ServletException extends Exception{
	public ServletException(String errorMessage) { super(errorMessage); }
}
