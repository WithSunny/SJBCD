import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9860858 {
public UNKNOWN getDbServ(){ return null; }
	public UNKNOWN identification(String o0, String o1){ return null; }
	public UNKNOWN getLogger(){ return null; }
//    @Override
    public boolean register(String username, String password)  throws Throwable {
        this.getLogger().info(DbUserServiceImpl.class, ">>>rigister " + username + "<<<");
        try {
            if (this.getDbServ().queryFeelerUser(username) != null) {
                return false;
            }
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(password.getBytes());
            String passwordMd5 = new String(md5.digest());
            this.getDbServ().addFeelerUser(username, passwordMd5);
            return(boolean)(Object) this.identification(username, password);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return false;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN queryFeelerUser(String o0){ return null; }
	public UNKNOWN addFeelerUser(String o0, String o1){ return null; }
	public UNKNOWN info(Class o0, String o1){ return null; }
}

class DbUserServiceImpl {
	
	
}
