import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4921001 {
public UNKNOWN parseMenu(Element o0){ return null; }
	public UNKNOWN parseMenubar(Element o0){ return null; }
	public UNKNOWN parseToolbar(Element o0){ return null; }
	public UNKNOWN parseString(Element o0){ return null; }
    public void addXMLResources(URL url) throws Throwable, IOException {
        try {
            Document document = (Document)(Object)new Builder().build(url.openStream());
            Element root =(Element)(Object) document.getRootElement();
            if (!root.getLocalName().equals("resources")) throw new IOException("Document root must be <resources>");
            Elements elements =(Elements)(Object) root.getChildElements();
            for (int i = 0; i < (int)(Object)elements.size(); i++) {
                Element element =(Element)(Object) elements.get(i);
                if (element.getLocalName().equals("string")) parseString(element); else if (element.getLocalName().equals("menubar")) parseMenubar(element); else if (element.getLocalName().equals("menu")) parseMenu(element); else if (element.getLocalName().equals("toolbar")) parseToolbar(element); else throw new IOException("Unrecognized element: <" + element.getLocalName() + ">");
            }
        } catch (ArithmeticException pe) {
            IOException ioe = new IOException(pe.getMessage());
            ioe.initCause(pe);
            throw ioe;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Document {
	
	public UNKNOWN getRootElement(){ return null; }
}

class Builder {
	
	public UNKNOWN build(InputStream o0){ return null; }
}

class Element {
	
	public UNKNOWN getLocalName(){ return null; }
	public UNKNOWN getChildElements(){ return null; }
}

class Elements {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN get(int o0){ return null; }
}

class ParsingException extends Exception{
	public ParsingException(String errorMessage) { super(errorMessage); }
}
