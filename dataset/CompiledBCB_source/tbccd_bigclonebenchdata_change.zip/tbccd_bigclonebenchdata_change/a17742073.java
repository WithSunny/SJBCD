import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17742073 {
    private HttpURLConnection getRecognizedUrl(SpantusAudioCtx ctx) throws Throwable, URISyntaxException {
        try {
            URL url =(URL)(Object) ctx.getRecognizedUrl();
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("PUT");
            return conn;
        } catch (MalformedURLException e) {
            UNKNOWN LOG = new UNKNOWN();
            LOG.error(e);
        } catch (IOException e) {
            UNKNOWN LOG = new UNKNOWN();
            LOG.error(e);
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(IOException o0){ return null; }
	public UNKNOWN error(MalformedURLException o0){ return null; }
}

class SpantusAudioCtx {
	
	public UNKNOWN getRecognizedUrl(){ return null; }
}
