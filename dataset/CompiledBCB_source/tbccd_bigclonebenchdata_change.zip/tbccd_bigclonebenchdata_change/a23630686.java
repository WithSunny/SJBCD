import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23630686 {
    private boolean copy(File in, File out)  throws Throwable {
        try {
            FileInputStream fis = new FileInputStream(in);
            FileOutputStream fos = new FileOutputStream(out);
            FileChannel readableChannel =(FileChannel)(Object) fis.getChannel();
            FileChannel writableChannel =(FileChannel)(Object) fos.getChannel();
            writableChannel.truncate(0);
            writableChannel.transferFrom(readableChannel, 0, readableChannel.size());
            fis.close();
            fos.close();
            return true;
        } catch (IOException ioe) {
            UNKNOWN guiBuilder = new UNKNOWN();
            guiBuilder.showError("Copy Error", "IOException during copy", ioe.getMessage());
            return false;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN showError(String o0, String o1, String o2){ return null; }
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN truncate(int o0){ return null; }
	public UNKNOWN transferFrom(FileChannel o0, int o1, UNKNOWN o2){ return null; }
}
