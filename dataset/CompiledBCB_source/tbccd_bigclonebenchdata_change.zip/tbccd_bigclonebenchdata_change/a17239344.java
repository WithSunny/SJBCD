import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17239344 {
public UNKNOWN JOptionPane;
	public UNKNOWN fileStatusProvider;
	public UNKNOWN Status;
	public UNKNOWN revert(File o0){ return null; }
	public UNKNOWN delete(File o0){ return null; }
	public UNKNOWN showConfirmation(String o0, String o1){ return null; }
	public UNKNOWN add(File o0){ return null; }
	public UNKNOWN logWarning(a17239344 o0, String o1){ return null; }
//        @Override
        public void doMove(File from, File to) throws Throwable, IOException {
            int res =(int)(Object) showConfirmation("File will be moved in p4, are you sure to move ", from.getAbsolutePath());
            if (res == (int)(Object)JOptionPane.NO_OPTION) {
                return;
            }
            Status status =(Status)(Object) fileStatusProvider.getFileStatusForce(from);
            if (status == null) {
                return;
            }
            if ((boolean)(Object)status.isLocal()) {
                logWarning(this, from.getName() + " is not revisioned. Should not be deleted by p4nb");
                return;
            }
            to.getParentFile().mkdirs();
            BufferedInputStream in = new BufferedInputStream(new FileInputStream(from));
            BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(to));
            byte[] buffer = new byte[8192];
            int read = 0;
            while ((read = in.read(buffer)) >= 0) {
                out.write(buffer, 0, read);
            }
            in.close();
            out.flush();
            out.close();
            if (status != (Status)(Object)Status.NONE) {
                revert(from);
            }
            if (status != (Status)(Object)Status.ADD) {
                delete(from);
            } else {
                from.delete();
            }
            add(to);
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN NONE;
	public UNKNOWN NO_OPTION;
	public UNKNOWN ADD;
	public UNKNOWN getFileStatusForce(File o0){ return null; }
}

class Status {
	
	public UNKNOWN isLocal(){ return null; }
}
