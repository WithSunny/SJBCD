import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2768538 {
public static UNKNOWN isUrl(String o0){ return null; }
//public UNKNOWN isUrl(String o0){ return null; }
    public static InputStream getInputStream(String filepath) throws Throwable, Exception {
        if ((boolean)(Object)isUrl(filepath)) {
            URL url = URI.create(filepath).toURL();
            return url.openStream();
        } else {
            return new FileInputStream(new File(filepath));
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
