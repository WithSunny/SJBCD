import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17874479 {
    public static final void main(String[] args) throws Throwable, Exception {
        HttpClient httpclient =(HttpClient)(Object) new DefaultHttpClient();
        HttpGet httpget = new HttpGet("http://www.apache.org/");
        System.out.println("executing request " + httpget.getURI());
        HttpResponse response =(HttpResponse)(Object) httpclient.execute(httpget);
        HttpEntity entity =(HttpEntity)(Object) response.getEntity();
        System.out.println("----------------------------------------");
        System.out.println(response.getStatusLine());
        if (entity != null) {
            System.out.println("Response content length: " + entity.getContentLength());
        }
        System.out.println("----------------------------------------");
        httpget.abort();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class HttpClient {
	
	public UNKNOWN execute(HttpGet o0){ return null; }
}

class DefaultHttpClient {
	
	
}

class HttpGet {
	
	HttpGet(){}
	HttpGet(String o0){}
	public UNKNOWN abort(){ return null; }
	public UNKNOWN getURI(){ return null; }
}

class HttpResponse {
	
	public UNKNOWN getStatusLine(){ return null; }
	public UNKNOWN getEntity(){ return null; }
}

class HttpEntity {
	
	public UNKNOWN getContentLength(){ return null; }
}
