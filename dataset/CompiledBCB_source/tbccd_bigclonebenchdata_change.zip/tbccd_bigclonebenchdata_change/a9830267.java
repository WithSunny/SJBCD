import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9830267 {
            public void run()  throws Throwable {
                final SimpleMessageListener listener = new SimpleMessageListener() {

                    public final boolean accept(final String from, final String recipient) {
                        return true;
                    }

                    public final void deliver(final String from, final String recipient, final InputStream data) throws TooMuchDataException, IOException {
                        System.out.println("FROM: " + from);
                        System.out.println("TO: " + recipient);
                        final File tmpDir = new File(System.getProperty("java.io.tmpdir"));
                        final File file = new File(tmpDir, recipient);
                        final FileWriter fw = new FileWriter(file);
                        try {
                            UNKNOWN IOUtils = new UNKNOWN();
                            IOUtils.copy(data, fw);
                        } finally {
                            fw.close();
                        }
                    }
                };
                final SMTPServer smtpServer = new SMTPServer(new SimpleMessageListenerAdapter(listener));
                smtpServer.start();
                System.out.println("Started SMTP Server");
            }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(InputStream o0, FileWriter o1){ return null; }
}

class SimpleMessageListener {
	
	
}

class SMTPServer {
	
	SMTPServer(){}
	SMTPServer(SimpleMessageListenerAdapter o0){}
	public UNKNOWN start(){ return null; }
}

class SimpleMessageListenerAdapter {
	
	SimpleMessageListenerAdapter(){}
	SimpleMessageListenerAdapter(SimpleMessageListener o0){}
}

class TooMuchDataException extends Exception{
	public TooMuchDataException(String errorMessage) { super(errorMessage); }
}
