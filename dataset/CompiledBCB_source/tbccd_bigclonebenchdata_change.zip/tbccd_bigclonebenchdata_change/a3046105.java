import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3046105 {
public UNKNOWN errorCheck(HttpResponse o0, int o1){ return null; }
public UNKNOWN URLEncodedUtils;
	public UNKNOWN httpClient;
	public UNKNOWN REST_URL;
	public UNKNOWN key;
	public UNKNOWN JAXB;
    public GGLicenses getLicensesInfo() throws Throwable, IllegalStateException, GGException, Exception {
        List<NameValuePair> qparams = new ArrayList<NameValuePair>();
        qparams.add((NameValuePair)(Object)new BasicNameValuePair("method", "gg.photos.licenses.getInfo"));
        qparams.add((NameValuePair)(Object)new BasicNameValuePair("key", this.key));
        String url = REST_URL + "?" + URLEncodedUtils.format(qparams, "UTF-8");
        URI uri = new URI(url);
        HttpGet httpget = new HttpGet(uri);
        HttpResponse response =(HttpResponse)(Object) httpClient.execute(httpget);
        int status =(int)(Object) response.getStatusLine().getStatusCode();
        errorCheck(response, status);
        InputStream content =(InputStream)(Object) response.getEntity().getContent();
        GGLicenses licenses =(GGLicenses)(Object) JAXB.unmarshal(content, GGLicenses.class);
        return licenses;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getStatusCode(){ return null; }
	public UNKNOWN getContent(){ return null; }
	public UNKNOWN format(List<NameValuePair> o0, String o1){ return null; }
	public UNKNOWN unmarshal(InputStream o0, Class o1){ return null; }
	public UNKNOWN execute(HttpGet o0){ return null; }
}

class GGLicenses {
	
	
}

class GGException extends Exception{
	public GGException(String errorMessage) { super(errorMessage); }
}

class NameValuePair {
	
	
}

class BasicNameValuePair {
	
	BasicNameValuePair(String o0, UNKNOWN o1){}
	BasicNameValuePair(){}
	BasicNameValuePair(String o0, String o1){}
}

class HttpGet {
	
	HttpGet(URI o0){}
	HttpGet(){}
}

class HttpResponse {
	
	public UNKNOWN getStatusLine(){ return null; }
	public UNKNOWN getEntity(){ return null; }
}
