import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a16210657 {
public UNKNOWN path;
	public UNKNOWN Malgn;
	public UNKNOWN encoding;
	public UNKNOWN doc;
	public UNKNOWN DocumentBuilderFactory;
	public UNKNOWN setError(String o0){ return null; }
    public  void SimpleParser(String filepath) throws Throwable, Exception {
        this.path =(UNKNOWN)(Object) filepath;
        InputStream is = null;
        try {
            if ((int)(Object)this.path.indexOf("http") == 0) {
                URL url = new URL((String)(Object)this.path);
                is = url.openStream();
            } else if ((int)(Object)this.path.indexOf("<?xml") == 0) {
                is = new ByteArrayInputStream(filepath.getBytes((String)(Object)encoding));
            } else {
                File f = new File((String)(Object)this.path);
                if (!f.exists()) {
                    setError("File not found : " + this.path);
                } else {
                    is = new FileInputStream(f);
                }
            }
            if (is != null) {
                DocumentBuilderFactory dbFactory =(DocumentBuilderFactory)(Object) DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder =(DocumentBuilder)(Object) dbFactory.newDocumentBuilder();
                doc = dBuilder.parse(is);
                doc.getDocumentElement().normalize();
            }
        } catch (Exception ex) {
            Malgn.errorLog("{SimpleParser.constructor} Path:" + filepath + " " + ex.getMessage());
            setError("Parser Error : " + ex.getMessage());
        } finally {
            if (is != null) is.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN errorLog(String o0){ return null; }
	public UNKNOWN indexOf(String o0){ return null; }
	public UNKNOWN normalize(){ return null; }
	public UNKNOWN getDocumentElement(){ return null; }
	public UNKNOWN newInstance(){ return null; }
}

class DocumentBuilderFactory {
	
	public UNKNOWN newDocumentBuilder(){ return null; }
}

class DocumentBuilder {
	
	public UNKNOWN parse(InputStream o0){ return null; }
}
