import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2069219 {
    public static void copieFichier(File fichier1, File fichier2)  throws Throwable {
        FileChannel in = null;
        FileChannel out = null;
        try {
            in = (FileChannel)(Object)new FileInputStream(fichier1).getChannel();
            out = (FileChannel)(Object)new FileOutputStream(fichier2).getChannel();
            in.transferTo(0, in.size(), out);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (ArithmeticException e) {
                }
            }
            if (out != null) {
                try {
                    out.close();
                } catch (ArrayIndexOutOfBoundsException e) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
	public UNKNOWN close(){ return null; }
}
