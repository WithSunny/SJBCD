import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a11237136 {
public UNKNOWN Logger;
    public String hash(String senha)  throws Throwable {
        String result = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(senha.getBytes());
            byte[] hashMd5 = md.digest();
            for (int i = 0; i < hashMd5.length; i++) result += Integer.toHexString((((hashMd5[i] >> 4) & 0xf) << 4) | (hashMd5[i] & 0xf));
        } catch (NoSuchAlgorithmException ex) {
            UNKNOWN TipoLog = new UNKNOWN();
            Logger.getInstancia().log(TipoLog.ERRO, ex);
        }
        return result;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN ERRO;
	public UNKNOWN log(UNKNOWN o0, NoSuchAlgorithmException o1){ return null; }
	public UNKNOWN getInstancia(){ return null; }
}
