import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a416235 {
public static UNKNOWN getText(String o0, String o1){ return null; }
	public static UNKNOWN isRelativePath(String o0){ return null; }
	public static UNKNOWN readPackageList(InputStream o0, String o1, boolean o2){ return null; }
//public UNKNOWN isRelativePath(String o0){ return null; }
//	public UNKNOWN getText(String o0, String o1){ return null; }
//	public UNKNOWN readPackageList(InputStream o0, String o1, boolean o2){ return null; }
    static String fetchURLComposeExternPackageList(String urlpath, String pkglisturlpath) {
        String link = pkglisturlpath + "package-list";
        try {
            boolean relative =(boolean)(Object) isRelativePath(urlpath);
            readPackageList((new URL(link)).openStream(), urlpath, relative);
        } catch (MalformedURLException exc) {
            return(String)(Object) getText("doclet.MalformedURL", link);
        } catch (IOException exc) {
            return(String)(Object) getText("doclet.URL_error", link);
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
