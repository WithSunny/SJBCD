import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1718146 {
public static UNKNOWN Logger;
//public UNKNOWN Logger;
    public static void main(String[] args)  throws Throwable {
        try {
            String default_uri = "http://www.cs.nmsu.edu/~bchisham/cgi-bin/phylows/tree/Tree3099?format=graphml";
            URL gurl = new URL(default_uri);
            InputStream is = gurl.openStream();
            Scanner iscan = new Scanner(is);
            while (iscan.hasNext()) {
                System.out.println(iscan.next());
            }
        } catch (MalformedURLException ex) {
            UNKNOWN Level = new UNKNOWN();
            Logger.getLogger(GraphUrlLoader.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN SEVERE;
	public UNKNOWN getLogger(String o0){ return null; }
	public UNKNOWN log(UNKNOWN o0, Object o1, MalformedURLException o2){ return null; }
}

class GraphUrlLoader {
	
	
}
