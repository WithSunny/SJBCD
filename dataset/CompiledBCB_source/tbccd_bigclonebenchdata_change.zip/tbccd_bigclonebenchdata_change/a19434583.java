import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19434583 {
public UNKNOWN encodeSkyhookRequest(LocationRequest o0){ return null; }
	public UNKNOWN decodeSkyhookResponse(String o0, LocationResponse o1){ return null; }
public UNKNOWN skyhookServerUri;
    public LocationResponse getResponse(LocationRequest lrq) throws Throwable, UnregisteredComponentException {
        LocationResponse lrs =(LocationResponse)(Object) lrq.createResponse();
        try {
            String rqs, rss;
            rqs =(String)(Object) encodeSkyhookRequest(lrq);
            if (null == rqs) {
                lrs.setError("No authentication was provided.");
                return lrs;
            }
            URL url = new URL((String)(Object)this.skyhookServerUri);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.addRequestProperty("Content-Type", "text/xml");
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(rqs);
            wr.flush();
            BufferedReader rd;
            rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            rss = "";
            String line;
            while ((line = rd.readLine()) != null) rss += line;
            rd.close();
            decodeSkyhookResponse(rss, lrs);
        } catch (Exception e) {
            e.printStackTrace();
            lrs.setError("Error querying Skyhook");
        }
        return lrs;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class LocationRequest {
	
	public UNKNOWN createResponse(){ return null; }
}

class LocationResponse {
	
	public UNKNOWN setError(String o0){ return null; }
}

class UnregisteredComponentException extends Exception{
	public UnregisteredComponentException(String errorMessage) { super(errorMessage); }
}
