import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10441727 {
public UNKNOWN fatalError(String o0, String o1){ return null; }
    private void downloadFile(String url, File destFile)  throws Throwable {
        try {
            System.out.println("Downloading " + url + " to " + destFile + "...");
            destFile.getParentFile().mkdirs();
            OutputStream out = new FileOutputStream(destFile);
            URLConnection conn = new URL(url).openConnection();
            InputStream in = conn.getInputStream();
            int totalSize = conn.getContentLength(), downloadedSize = 0, size;
            byte[] buffer = new byte[32768];
            ProgressMonitor pm = new ProgressMonitor(null, "Downloading " + url, "", 0, totalSize);
            pm.setMillisToDecideToPopup(100);
            pm.setMillisToPopup(500);
            boolean canceled = false;
            while ((size = in.read(buffer)) > 0 && !(canceled =(boolean)(Object) pm.isCanceled())) {
                out.write(buffer, 0, size);
                pm.setProgress(downloadedSize += size);
                pm.setNote((100 * downloadedSize / totalSize) + "% finished");
            }
            in.close();
            out.close();
            if (canceled) {
                destFile.delete();
                fatalError("Starting canceled", "Downloading canceled. Exiting...");
            }
            pm.close();
        } catch (IOException ex) {
            ex.printStackTrace();
            destFile.delete();
            fatalError("Download Error", "Couldn't download file " + url + ": " + ex);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ProgressMonitor {
	
	ProgressMonitor(){}
	ProgressMonitor(Object o0, String o1, String o2, int o3, int o4){}
	public UNKNOWN close(){ return null; }
	public UNKNOWN setProgress(int o0){ return null; }
	public UNKNOWN setNote(String o0){ return null; }
	public UNKNOWN setMillisToPopup(int o0){ return null; }
	public UNKNOWN isCanceled(){ return null; }
	public UNKNOWN setMillisToDecideToPopup(int o0){ return null; }
}
