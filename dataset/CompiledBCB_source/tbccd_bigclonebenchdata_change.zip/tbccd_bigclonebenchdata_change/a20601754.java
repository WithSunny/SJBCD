import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20601754 {
    public static File copyFile(File file, String dirName)  throws Throwable {
        File destDir = new File(dirName);
        if (!destDir.exists() || !destDir.isDirectory()) {
            destDir.mkdirs();
        }
        File src = file;
        File dest = new File(dirName, src.getName());
        try {
            if (!dest.exists()) {
                dest.createNewFile();
            }
            FileChannel source = (FileChannel)(Object)new FileInputStream(src).getChannel();
            FileChannel destination = (FileChannel)(Object)new FileOutputStream(dest).getChannel();
            destination.transferFrom(source, 0, source.size());
            source.close();
            destination.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dest;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferFrom(FileChannel o0, int o1, UNKNOWN o2){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN size(){ return null; }
}
