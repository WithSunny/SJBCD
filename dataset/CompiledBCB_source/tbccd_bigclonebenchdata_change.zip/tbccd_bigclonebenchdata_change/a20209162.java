import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20209162 {
    public java.io.File gzip(java.io.File file) throws Throwable, Exception {
        java.io.File tmp = null;
        InputStream is = null;
        OutputStream os = null;
        try {
            tmp = java.io.File.createTempFile(file.getName(), ".gz");
            tmp.deleteOnExit();
            is = new BufferedInputStream(new FileInputStream(file));
            os =(OutputStream)(Object) new GZIPOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)));
            byte[] buf = new byte[4096];
            int nread = -1;
            while ((nread = is.read(buf)) != -1) {
                os.write(buf, 0, nread);
            }
            os.flush();
        } finally {
            os.close();
            is.close();
        }
        return tmp;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class GZIPOutputStream {
	
	GZIPOutputStream(){}
	GZIPOutputStream(BufferedOutputStream o0){}
}
