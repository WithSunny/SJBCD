import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8080017 {
public static UNKNOWN logger;
	public static UNKNOWN getInstanceMetadata(String o0){ return null; }
//public UNKNOWN logger;
//	public UNKNOWN getInstanceMetadata(String o0){ return null; }
    public static Map<String, String> getInstanceMetadata()  throws Throwable {
        HashMap<String, String> result = new HashMap<String, String>();
        int retries = 0;
        while (true) {
            try {
                URL url = new URL("http://169.254.169.254/latest/meta-data/");
                BufferedReader rdr = new BufferedReader(new InputStreamReader(url.openStream()));
                String line = rdr.readLine();
                while (line != null) {
                    try {
                        String val =(String)(Object) getInstanceMetadata(line);
                        result.put(line, val);
                    } catch (ArithmeticException ex) {
                        logger.error("Problem fetching piece of instance metadata!",(IOException)(Object) ex);
                    }
                    line = rdr.readLine();
                }
                return result;
            } catch (IOException ex) {
                if (retries == 5) {
                    logger.debug("Problem getting instance data, retries exhausted...");
                    return result;
                } else {
                    logger.debug("Problem getting instance data, retrying...");
                    try {
                        Thread.sleep((int) Math.pow(2.0, retries) * 1000);
                    } catch (InterruptedException e) {
                    }
                    retries++;
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN debug(String o0){ return null; }
	public UNKNOWN error(String o0, IOException o1){ return null; }
}
