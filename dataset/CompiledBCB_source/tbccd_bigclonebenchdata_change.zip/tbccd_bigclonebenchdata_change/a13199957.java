import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13199957 {
    private File copyFile(String fileInClassPath, String systemPath) throws Throwable, Exception {
        InputStream is = getClass().getResourceAsStream(fileInClassPath);
        OutputStream os = new FileOutputStream(systemPath);
        UNKNOWN IOUtils = new UNKNOWN();
        IOUtils.copy(is, os);
        is.close();
        os.close();
        return new File(systemPath);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(InputStream o0, OutputStream o1){ return null; }
}
