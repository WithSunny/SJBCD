import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13955716 {
    public static void copier(final File pFichierSource, final File pFichierDest)  throws Throwable {
        FileChannel vIn = null;
        FileChannel vOut = null;
        try {
            vIn = (FileChannel)(Object)new FileInputStream(pFichierSource).getChannel();
            vOut = (FileChannel)(Object)new FileOutputStream(pFichierDest).getChannel();
            vIn.transferTo(0, vIn.size(), vOut);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (vIn != null) {
                try {
                    vIn.close();
                } catch (ArithmeticException e) {
                }
            }
            if (vOut != null) {
                try {
                    vOut.close();
                } catch (ArrayIndexOutOfBoundsException e) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
}
