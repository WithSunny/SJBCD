import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a16165021 {
public UNKNOWN fChecker;
	public UNKNOWN fUserDictionary;
	public UNKNOWN PreferenceConstants;
	public UNKNOWN VariablesPlugin;
	public UNKNOWN SpellActivator;
    private synchronized void resetUserDictionary()  throws Throwable {
        if (this.fChecker == null) return;
        if (this.fUserDictionary != null) {
            this.fChecker.removeDictionary(this.fUserDictionary);
            this.fUserDictionary.unload();
            this.fUserDictionary = null;
        }
        IPreferenceStore store =(IPreferenceStore)(Object) SpellActivator.getDefault().getPreferenceStore();
        String filePath =(String)(Object) store.getString(PreferenceConstants.SPELLING_USER_DICTIONARY);
        IStringVariableManager variableManager =(IStringVariableManager)(Object) VariablesPlugin.getDefault().getStringVariableManager();
        try {
            filePath =(String)(Object) variableManager.performStringSubstitution(filePath);
        } catch (ArithmeticException e) {
            SpellActivator.log((CoreException)(Object)e);
            return;
        }
        if (filePath.length() > 0) {
            try {
                File file = new File(filePath);
                if (!file.exists() && !file.createNewFile()) return;
                final URL url = new URL("file", null, filePath);
                InputStream stream = url.openStream();
                if (stream != null) {
                    try {
                        this.fUserDictionary =(UNKNOWN)(Object) new PersistentSpellDictionary(url);
                        this.fChecker.addDictionary(this.fUserDictionary);
                    } finally {
                        stream.close();
                    }
                }
            } catch (MalformedURLException exception) {
            } catch (IOException exception) {
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN SPELLING_USER_DICTIONARY;
	public UNKNOWN getPreferenceStore(){ return null; }
	public UNKNOWN unload(){ return null; }
	public UNKNOWN log(CoreException o0){ return null; }
	public UNKNOWN getStringVariableManager(){ return null; }
	public UNKNOWN getDefault(){ return null; }
	public UNKNOWN removeDictionary(UNKNOWN o0){ return null; }
	public UNKNOWN addDictionary(UNKNOWN o0){ return null; }
}

class IPreferenceStore {
	
	public UNKNOWN getString(UNKNOWN o0){ return null; }
}

class IStringVariableManager {
	
	public UNKNOWN performStringSubstitution(String o0){ return null; }
}

class CoreException extends Exception{
	public CoreException(String errorMessage) { super(errorMessage); }
}

class PersistentSpellDictionary {
	
	PersistentSpellDictionary(){}
	PersistentSpellDictionary(URL o0){}
}
