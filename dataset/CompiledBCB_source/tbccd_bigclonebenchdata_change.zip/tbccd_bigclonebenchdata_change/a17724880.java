import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17724880 {
    public byte[] getDigest(OMText text, String digestAlgorithm) throws Throwable, OMException {
        byte[] digest = new byte[0];
        try {
            MessageDigest md = MessageDigest.getInstance(digestAlgorithm);
            md.update((byte) 0);
            md.update((byte) 0);
            md.update((byte) 0);
            md.update((byte) 3);
            md.update((byte)(Object)text.getText().getBytes("UnicodeBigUnmarked"));
            digest = md.digest();
        } catch (NoSuchAlgorithmException e) {
            throw new OMException((String)(Object)e);
        } catch (ArithmeticException e) {
            throw new OMException((String)(Object)e);
        }
        return digest;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getBytes(String o0){ return null; }
}

class OMText {
	
	public UNKNOWN getText(){ return null; }
}

class OMException extends Exception{
	public OMException(String errorMessage) { super(errorMessage); }
}
