import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15856337 {
    public BigInteger calculateMd5(String input) throws Throwable, FileSystemException {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(input.getBytes());
            byte[] messageDigest = digest.digest();
            BigInteger bigInt = new BigInteger(1, messageDigest);
            return bigInt;
        } catch (Exception e) {
            throw new FileSystemException((String)(Object)e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileSystemException extends Exception{
	public FileSystemException(String errorMessage) { super(errorMessage); }
}
