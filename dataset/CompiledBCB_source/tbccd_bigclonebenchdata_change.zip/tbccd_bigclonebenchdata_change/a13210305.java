import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13210305 {
public static UNKNOWN hashToHex(byte[] o0){ return null; }
//public UNKNOWN hashToHex(byte[] o0){ return null; }
    public static final String encryptMD5(String decrypted)  throws Throwable {
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(decrypted.getBytes());
            byte hash[] = md5.digest();
            md5.reset();
            return(String)(Object) hashToHex(hash);
        } catch (NoSuchAlgorithmException _ex) {
            return null;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
