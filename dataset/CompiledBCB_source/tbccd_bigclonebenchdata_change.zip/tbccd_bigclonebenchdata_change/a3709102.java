import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3709102 {
public UNKNOWN connection;
	public UNKNOWN fechaConexao(){ return null; }
	public UNKNOWN criaConexao(boolean o0){ return null; }
    public void removerTopicos(Topicos topicos) throws Throwable, ClassNotFoundException, SQLException {
        this.criaConexao(false);
        String sql = "DELETE FROM \"Topicos\"    " + "      WHERE \"id_Topicos\" =  ?";
        PreparedStatement stmt = null;
        try {
            stmt =(PreparedStatement)(Object) connection.prepareStatement(sql);
            stmt.setString(1, topicos.getIdTopicos());
            stmt.executeUpdate();
            connection.commit();
        } catch (ArithmeticException e) {
            connection.rollback();
            throw e;
        } finally {
            try {
                stmt.close();
                this.fechaConexao();
            } catch (ArrayIndexOutOfBoundsException e) {
                throw e;
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN rollback(){ return null; }
}

class Topicos {
	
	public UNKNOWN getIdTopicos(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class PreparedStatement {
	
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN setString(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN close(){ return null; }
}
