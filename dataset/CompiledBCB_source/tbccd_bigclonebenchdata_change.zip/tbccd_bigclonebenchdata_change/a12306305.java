import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12306305 {
    private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws Throwable, IOException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new IOException("Destination '" + destFile + "' exists but is a directory");
        }
        FileChannel input = (FileChannel)(Object)new FileInputStream(srcFile).getChannel();
        try {
            FileChannel output = (FileChannel)(Object)new FileOutputStream(destFile).getChannel();
            try {
                output.transferFrom(input, 0, input.size());
            } finally {
                UNKNOWN IOUtil = new UNKNOWN();
                IOUtil.closeQuietly(output);
            }
        } finally {
            UNKNOWN IOUtil = new UNKNOWN();
            IOUtil.closeQuietly(input);
        }
        if (srcFile.length() != destFile.length()) {
            throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "'");
        }
        if (preserveFileDate) {
            destFile.setLastModified(srcFile.lastModified());
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN closeQuietly(FileChannel o0){ return null; }
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN transferFrom(FileChannel o0, int o1, UNKNOWN o2){ return null; }
}
