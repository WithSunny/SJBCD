import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12728214 {
public UNKNOWN getEditorInput(){ return null; }
public UNKNOWN getEditDomain(){ return null; }
	public UNKNOWN getCommonKeyHandler(){ return null; }
	public UNKNOWN getActionRegistry(){ return null; }
	public UNKNOWN getSite(){ return null; }
	public UNKNOWN getContent(){ return null; }
	public UNKNOWN getEditPartFactory(){ return null; }
    protected GraphicalViewer createGraphicalViewer(Composite parent)  throws Throwable {
        GraphicalViewer viewer =(GraphicalViewer)(Object) new ScrollingGraphicalViewer();
        viewer.createControl(parent);
        viewer.getControl().setBackground(parent.getBackground());
        viewer.setRootEditPart(new ScalableFreeformRootEditPart());
        GraphicalViewerKeyHandler graphicalViewerKeyHandler = new GraphicalViewerKeyHandler(viewer);
        KeyHandler parentKeyHandler =(KeyHandler)(Object) graphicalViewerKeyHandler.setParent(getCommonKeyHandler());
        viewer.setKeyHandler(parentKeyHandler);
        getEditDomain().addViewer(viewer);
        getSite().setSelectionProvider(viewer);
        ContextMenuProvider provider =(ContextMenuProvider)(Object) new TestContextMenuProvider(viewer, getActionRegistry());
        viewer.setContextMenu(provider);
        getSite().registerContextMenu("cubicTestPlugin.editor.contextmenu", provider, viewer);
        viewer.addDropTargetListener((FileTransferDropTargetListener)(Object)new DataEditDropTargetListner(((IFileEditorInput)(IFileEditorInput)(Object) getEditorInput()).getFile().getProject(), viewer));
        viewer.addDropTargetListener(new FileTransferDropTargetListener(viewer));
        viewer.setEditPartFactory(getEditPartFactory());
        viewer.setContents(getContent());
        return viewer;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN addViewer(GraphicalViewer o0){ return null; }
	public UNKNOWN setSelectionProvider(GraphicalViewer o0){ return null; }
	public UNKNOWN setBackground(UNKNOWN o0){ return null; }
	public UNKNOWN registerContextMenu(String o0, ContextMenuProvider o1, GraphicalViewer o2){ return null; }
	public UNKNOWN getProject(){ return null; }
}

class Composite {
	
	public UNKNOWN getBackground(){ return null; }
}

class GraphicalViewer {
	
	public UNKNOWN createControl(Composite o0){ return null; }
	public UNKNOWN setEditPartFactory(UNKNOWN o0){ return null; }
	public UNKNOWN setRootEditPart(ScalableFreeformRootEditPart o0){ return null; }
	public UNKNOWN setContextMenu(ContextMenuProvider o0){ return null; }
	public UNKNOWN addDropTargetListener(FileTransferDropTargetListener o0){ return null; }
	public UNKNOWN setKeyHandler(KeyHandler o0){ return null; }
	public UNKNOWN setContents(UNKNOWN o0){ return null; }
	public UNKNOWN getControl(){ return null; }
}

class ScrollingGraphicalViewer {
	
	
}

class ScalableFreeformRootEditPart {
	
	
}

class GraphicalViewerKeyHandler {
	
	GraphicalViewerKeyHandler(){}
	GraphicalViewerKeyHandler(GraphicalViewer o0){}
	public UNKNOWN setParent(UNKNOWN o0){ return null; }
}

class KeyHandler {
	
	
}

class ContextMenuProvider {
	
	
}

class TestContextMenuProvider {
	
	TestContextMenuProvider(GraphicalViewer o0, UNKNOWN o1){}
	TestContextMenuProvider(){}
}

class DataEditDropTargetListner {
	
	DataEditDropTargetListner(){}
	DataEditDropTargetListner(UNKNOWN o0, GraphicalViewer o1){}
}

class FileTransferDropTargetListener {
	
	FileTransferDropTargetListener(){}
	FileTransferDropTargetListener(GraphicalViewer o0){}
}

class IFileEditorInput {
	
	public UNKNOWN getFile(){ return null; }
}
