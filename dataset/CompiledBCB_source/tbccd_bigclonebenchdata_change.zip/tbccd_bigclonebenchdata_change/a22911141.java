import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22911141 {
    public synchronized String encrypt(String plaintext) throws Throwable, ServiceUnavailableException {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new ServiceUnavailableException(e.getMessage());
        }
        try {
            md.reset();
            md.update(plaintext.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            throw new ServiceUnavailableException(e.getMessage());
        }
        byte raw[] = md.digest();
        String hash =(String)(Object) (new BASE64Encoder()).encode(raw);
        return hash;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ServiceUnavailableException extends Exception{
	public ServiceUnavailableException(String errorMessage) { super(errorMessage); }
}

class BASE64Encoder {
	
	public UNKNOWN encode(byte[] o0){ return null; }
}
