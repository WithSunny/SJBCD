import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1913136 {
    private void copyFile(File in, File out) throws Throwable, Exception {
        FileChannel sourceChannel = (FileChannel)(Object)new FileInputStream(in).getChannel();
        FileChannel destinationChannel = (FileChannel)(Object)new FileOutputStream(out).getChannel();
        sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
        sourceChannel.close();
        destinationChannel.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
}
