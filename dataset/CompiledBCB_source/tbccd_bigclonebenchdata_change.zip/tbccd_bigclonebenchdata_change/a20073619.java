import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20073619 {
    public static String getPagina(String strurl)  throws Throwable {
        String resp = "";
        Authenticator.setDefault((Authenticator)(Object)new Autenticador());
        try {
            URL url = new URL(strurl);
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String str;
            while ((str = in.readLine()) != null) {
                resp += str;
            }
            in.close();
        } catch (MalformedURLException e) {
            resp = e.toString();
        } catch (IOException e) {
            resp = e.toString();
        } catch (Exception e) {
            resp = e.toString();
        }
        return resp;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Autenticador {
	
	
}
