import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2980810 {
public UNKNOWN logRequest(HttpServletRequest o0){ return null; }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws Throwable, ServletException, IOException {
        String url =(String)(Object) request.getParameter("proxyurl");
        URLConnection conn = new URL(url).openConnection();
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setUseCaches(false);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
        Enumeration params =(Enumeration)(Object) request.getParameterNames();
        boolean first = true;
        while (params.hasMoreElements()) {
            String param = (String) params.nextElement();
            if (!param.equals("proxyurl")) {
                if (first) {
                    first = false;
                } else {
                    dos.writeBytes("&");
                }
                dos.writeBytes(URLEncoder.encode(param));
                dos.writeBytes("=");
                dos.writeBytes(URLEncoder.encode((String)(Object)request.getParameter(param)));
            }
        }
        dos.close();
        Reader in = new InputStreamReader(conn.getInputStream(),(String)(Object) response.getCharacterEncoding());
        response.setContentType(conn.getContentType());
        response.setContentLength(conn.getContentLength());
        Writer out =(Writer)(Object) response.getWriter();
        char[] buf = new char[256];
        int len;
        while ((len = in.read(buf)) != -1) {
            out.write(buf, 0, len);
        }
        in.close();
        out.close();
        String log =(String)(Object) request.getParameter("logging");
        if (log != null && log.toLowerCase().equals("true")) logRequest(request);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class HttpServletRequest {
	
	public UNKNOWN getParameter(String o0){ return null; }
	public UNKNOWN getParameterNames(){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN setContentType(String o0){ return null; }
	public UNKNOWN getWriter(){ return null; }
	public UNKNOWN setContentLength(int o0){ return null; }
	public UNKNOWN getCharacterEncoding(){ return null; }
}

class ServletException extends Exception{
	public ServletException(String errorMessage) { super(errorMessage); }
}
