import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7631407 {
public static UNKNOWN getNotCacheResource(String o0){ return null; }
//public UNKNOWN getNotCacheResource(String o0){ return null; }
    public static InputStream getNotCacheResourceAsStream(final String fileName)  throws Throwable {
        if ((fileName.indexOf("file:") >= 0) || (fileName.indexOf(":/") > 0)) {
            try {
                URL url = new URL(fileName);
                return new BufferedInputStream(url.openStream());
            } catch (Exception e) {
                return null;
            }
        }
        return new ByteArrayInputStream((byte[])(Object)getNotCacheResource(fileName).getData());
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getData(){ return null; }
}
