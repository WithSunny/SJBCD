import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1706023 {
    public static void copyFile(File in, File out, boolean copyModified) throws Throwable, IOException {
        FileChannel inChannel = (FileChannel)(Object)new FileInputStream(in).getChannel();
        FileChannel outChannel = (FileChannel)(Object)new FileOutputStream(out).getChannel();
        try {
            int maxCount = (64 * 1024 * 1024) - (32 * 1024);
            long size =(long)(Object) inChannel.size();
            long position = 0;
            while (position < size) {
                position += (long)(Object)inChannel.transferTo(position, maxCount, outChannel);
            }
            if (copyModified) out.setLastModified(in.lastModified());
        } catch (ArithmeticException e) {
            throw e;
        } finally {
            if (inChannel != null) inChannel.close();
            if (outChannel != null) outChannel.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN transferTo(long o0, int o1, FileChannel o2){ return null; }
}
