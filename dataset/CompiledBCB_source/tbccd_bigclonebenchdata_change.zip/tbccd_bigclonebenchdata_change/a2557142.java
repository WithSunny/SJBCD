import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2557142 {
public UNKNOWN ftpClient;
	public UNKNOWN FTPReply;
	public UNKNOWN logout(){ return null; }
    public void login(LoginData loginData) throws Throwable, ConnectionEstablishException, AccessDeniedException {
        try {
            int reply;
            this.ftpClient.connect(loginData.getFtpServer());
            reply =(int)(Object) this.ftpClient.getReplyCode();
            if (!(Boolean)(Object)FTPReply.isPositiveCompletion(reply)) {
                this.ftpClient.disconnect();
                throw (new ConnectionEstablishException("FTP server refused connection."));
            }
        } catch (ArithmeticException e) {
            if ((boolean)(Object)this.ftpClient.isConnected()) {
                try {
                    this.ftpClient.disconnect();
                } catch (ArrayIndexOutOfBoundsException f) {
                }
            }
            e.printStackTrace();
            throw (new ConnectionEstablishException("Could not connect to server.",(IOException)(Object) e));
        }
        try {
            if (!(Boolean)(Object)this.ftpClient.login(loginData.getFtpBenutzer(), loginData.getFtpPasswort())) {
                this.logout();
                throw (new AccessDeniedException("Could not login into server."));
            }
        } catch (ArrayStoreException ioe) {
            ioe.printStackTrace();
            throw (new AccessDeniedException("Could not login into server.",(IOException)(Object) ioe));
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN isConnected(){ return null; }
	public UNKNOWN disconnect(){ return null; }
	public UNKNOWN getReplyCode(){ return null; }
	public UNKNOWN isPositiveCompletion(int o0){ return null; }
	public UNKNOWN connect(UNKNOWN o0){ return null; }
	public UNKNOWN login(UNKNOWN o0, UNKNOWN o1){ return null; }
}

class LoginData {
	
	public UNKNOWN getFtpPasswort(){ return null; }
	public UNKNOWN getFtpBenutzer(){ return null; }
	public UNKNOWN getFtpServer(){ return null; }
}

class ConnectionEstablishException extends Exception{
	public ConnectionEstablishException(String errorMessage) { super(errorMessage); }
	ConnectionEstablishException(String o0, IOException o1){}
	ConnectionEstablishException(){}
}

class AccessDeniedException extends Exception{
	public AccessDeniedException(String errorMessage) { super(errorMessage); }
	AccessDeniedException(String o0, IOException o1){}
	AccessDeniedException(){}
}
