import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14483804 {
public UNKNOWN sourceInfo;
	public UNKNOWN contentType;
	public UNKNOWN url;
	public UNKNOWN name;
	public UNKNOWN conn;
	public UNKNOWN size;
        public  void URLStream(URL url) throws Throwable, IOException {
            this.url =(UNKNOWN)(Object) url;
            this.conn = this.url.openConnection();
            contentType = conn.getContentType();
            name =(UNKNOWN)(Object) url.toExternalForm();
            size =(UNKNOWN)(Object) new Long((long)(Object)conn.getContentLength());
            sourceInfo =(UNKNOWN)(Object) "url";
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN openConnection(){ return null; }
	public UNKNOWN getContentLength(){ return null; }
	public UNKNOWN getContentType(){ return null; }
}
