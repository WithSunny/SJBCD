import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19685311 {
    public static void copyFile(File inputFile, File outputFile) throws Throwable, IOException {
        FileChannel srcChannel = (FileChannel)(Object)new FileInputStream(inputFile).getChannel();
        FileChannel dstChannel = (FileChannel)(Object)new FileOutputStream(outputFile).getChannel();
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
        srcChannel.close();
        dstChannel.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferFrom(FileChannel o0, int o1, UNKNOWN o2){ return null; }
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
}
