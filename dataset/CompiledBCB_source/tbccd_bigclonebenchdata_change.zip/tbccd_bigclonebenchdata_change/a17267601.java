import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17267601 {
public UNKNOWN bckImg;
	public UNKNOWN drawPanel;
	public UNKNOWN LogHandler;
	public UNKNOWN JOptionPane;
	public UNKNOWN Level;
	public UNKNOWN setPath(String o0){ return null; }
	public UNKNOWN getPath(){ return null; }
	public UNKNOWN isLoggingEnabled(){ return null; }
    public void setBckImg(String newPath)  throws Throwable {
        try {
            File inputFile = new File((String)(Object)getPath());
            File outputFile = new File(newPath);
            if (!inputFile.getCanonicalPath().equals(outputFile.getCanonicalPath())) {
                FileInputStream in = new FileInputStream(inputFile);
                FileOutputStream out = null;
                try {
                    out = new FileOutputStream(outputFile);
                } catch (FileNotFoundException ex1) {
                    ex1.printStackTrace();
                    JOptionPane.showMessageDialog(null, ex1.getMessage().substring(0, Math.min(ex1.getMessage().length(),(int)(Object) drawPanel.MAX_DIALOG_MSG_SZ)) + "-" + getClass(), "Set Bck Img", JOptionPane.ERROR_MESSAGE);
                }
                int c;
                if (out != null) {
                    while ((c = in.read()) != -1) out.write(c);
                    out.close();
                }
                in.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            LogHandler.log(ex.getMessage(), Level.INFO, "LOG_MSG", isLoggingEnabled());
            JOptionPane.showMessageDialog(null, ex.getMessage().substring(0, Math.min(ex.getMessage().length(),(int)(Object) drawPanel.MAX_DIALOG_MSG_SZ)) + "-" + getClass(), "Set Bck Img", JOptionPane.ERROR_MESSAGE);
        }
        setPath(newPath);
        bckImg =(UNKNOWN)(Object) new ImageIcon(getPath());
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN INFO;
	public UNKNOWN MAX_DIALOG_MSG_SZ;
	public UNKNOWN ERROR_MESSAGE;
	public UNKNOWN log(String o0, UNKNOWN o1, String o2, UNKNOWN o3){ return null; }
	public UNKNOWN showMessageDialog(Object o0, String o1, String o2, UNKNOWN o3){ return null; }
}

class ImageIcon {
	
	ImageIcon(){}
	ImageIcon(UNKNOWN o0){}
}
