import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10131427 {
    public static void copyFile(File in, File out) throws Throwable, IOException {
        FileChannel sourceChannel = (FileChannel)(Object)new FileInputStream(in).getChannel();
        FileChannel destinationChannel = (FileChannel)(Object)new FileOutputStream(out).getChannel();
        sourceChannel.transferTo(0, sourceChannel.size(), destinationChannel);
        sourceChannel.close();
        destinationChannel.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN size(){ return null; }
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
}
