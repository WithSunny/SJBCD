import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a18492103 {
public UNKNOWN OutputMode;
	public UNKNOWN IOUtils;
	public UNKNOWN fileSystem;
	public UNKNOWN _(String o0){ return null; }
    public void shouldAllowClosingInputStreamTwice() throws Throwable, IOException {
        OutputStream outputStream =(OutputStream)(Object) fileSystem.createOutputStream(_("hello"), OutputMode.OVERWRITE);
        outputStream.write(new byte[] { 1, 2, 3 });
        outputStream.close();
        InputStream inputStream =(InputStream)(Object) fileSystem.createInputStream(_("hello"));
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        IOUtils.copy(inputStream, buffer);
        inputStream.close();
        inputStream.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN OVERWRITE;
	public UNKNOWN copy(InputStream o0, ByteArrayOutputStream o1){ return null; }
	public UNKNOWN createOutputStream(UNKNOWN o0, UNKNOWN o1){ return null; }
	public UNKNOWN createInputStream(UNKNOWN o0){ return null; }
}
