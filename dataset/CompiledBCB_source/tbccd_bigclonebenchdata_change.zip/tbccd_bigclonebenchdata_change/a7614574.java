import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7614574 {
public UNKNOWN getInitParameter(String o0){ return null; }
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws Throwable, ServletException, IOException {
        String zOntoJsonApiUrl =(String)(Object) getInitParameter("zOntoJsonApiServletUrl");
        URL url = new URL(zOntoJsonApiUrl + "?" + req.getQueryString());
        resp.setContentType("text/html");
        InputStreamReader bf = new InputStreamReader(url.openStream());
        BufferedReader bbf = new BufferedReader(bf);
        String response = "";
        String line = bbf.readLine();
        PrintWriter out =(PrintWriter)(Object) resp.getWriter();
        while (line != null) {
            response += line;
            line = bbf.readLine();
        }
        out.print(response);
        out.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class HttpServletRequest {
	
	public UNKNOWN getQueryString(){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN setContentType(String o0){ return null; }
	public UNKNOWN getWriter(){ return null; }
}

class ServletException extends Exception{
	public ServletException(String errorMessage) { super(errorMessage); }
}
