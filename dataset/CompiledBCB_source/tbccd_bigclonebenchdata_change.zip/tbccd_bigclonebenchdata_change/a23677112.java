import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23677112 {
	public static String downloadWebpage2(String address) throws Throwable, MalformedURLException, IOException {
		URL url = new URL(address);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		HttpURLConnection.setFollowRedirects(true);
		String encoding = conn.getContentEncoding();
		InputStream is = null;
		if(encoding != null && encoding.equalsIgnoreCase("gzip")) {
			is =(InputStream)(Object) new GZIPInputStream(conn.getInputStream());
		} else if (encoding != null && encoding.equalsIgnoreCase("deflate")) {
			is =(InputStream)(Object) new InflaterInputStream(conn.getInputStream());
		} else {
			is = conn.getInputStream();
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String line;
		String page = "";
		while((line = br.readLine()) != null) {
			page += line + "\n";
		}
		br.close();
		return page;
	}
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class GZIPInputStream {
	
	GZIPInputStream(){}
	GZIPInputStream(InputStream o0){}
}

class InflaterInputStream {
	
	InflaterInputStream(){}
	InflaterInputStream(InputStream o0){}
}
