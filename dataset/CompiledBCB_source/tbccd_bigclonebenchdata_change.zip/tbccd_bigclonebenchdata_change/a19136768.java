import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19136768 {
    public static void main(String[] args)  throws Throwable {
        CookieManager cm = new CookieManager();
        try {
            URL url = new URL("http://www.hccp.org/test/cookieTest.jsp");
            URLConnection conn = url.openConnection();
            conn.connect();
            cm.storeCookies(conn);
            System.out.println(cm);
            cm.setCookies(url.openConnection());
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class CookieManager {
	
	public UNKNOWN setCookies(URLConnection o0){ return null; }
	public UNKNOWN storeCookies(URLConnection o0){ return null; }
}
