import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14303294 {
public UNKNOWN bytesToHex(byte[] o0){ return null; }
    public String getServerHash(String passwordHash, String PasswordSalt) throws Throwable, PasswordHashingException {
        byte[] hash;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.reset();
            digest.update(PasswordSalt.getBytes("UTF-16"));
            hash = digest.digest(passwordHash.getBytes("UTF-16"));
            return(String)(Object) bytesToHex(hash);
        } catch (NoSuchAlgorithmException ex) {
            throw new PasswordHashingException("Current environment does not supply needed security algorithms. Please update Java");
        } catch (UnsupportedEncodingException ex) {
            throw new PasswordHashingException("Current environment does not supply needed character encoding. Please update Java");
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class PasswordHashingException extends Exception{
	public PasswordHashingException(String errorMessage) { super(errorMessage); }
}
