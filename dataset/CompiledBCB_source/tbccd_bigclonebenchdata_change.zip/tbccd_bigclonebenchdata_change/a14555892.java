import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14555892 {
public UNKNOWN encoding;
	public UNKNOWN IOUtils;
	public UNKNOWN getInputStream(){ return null; }
    public String getText() throws Throwable, IOException {
        InputStreamReader r = new InputStreamReader((InputStream)(Object)getInputStream(),(String)(Object) encoding);
        StringWriter w = new StringWriter(256 * 128);
        try {
            IOUtils.copy(r, w);
        } finally {
            IOUtils.closeQuietly(w);
            IOUtils.closeQuietly(r);
        }
        return w.toString();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN closeQuietly(InputStreamReader o0){ return null; }
	public UNKNOWN copy(InputStreamReader o0, StringWriter o1){ return null; }
	public UNKNOWN closeQuietly(StringWriter o0){ return null; }
}
