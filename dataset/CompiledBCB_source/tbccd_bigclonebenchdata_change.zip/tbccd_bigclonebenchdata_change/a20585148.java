import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20585148 {
    public static void main(String[] args)  throws Throwable {
        FTPClient client = new FTPClient();
        try {
            client.connect("ftp.domain.com");
            client.login("admin", "secret");
            String filename = "/testing/data.txt";
            boolean deleted =(boolean)(Object) client.deleteFile(filename);
            if (deleted) {
                System.out.println("File deleted...");
            }
            client.logout();
        } catch (ArithmeticException e) {
            e.printStackTrace();
        } finally {
            try {
                client.disconnect();
            } catch (ArrayIndexOutOfBoundsException e) {
                e.printStackTrace();
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FTPClient {
	
	public UNKNOWN login(String o0, String o1){ return null; }
	public UNKNOWN connect(String o0){ return null; }
	public UNKNOWN logout(){ return null; }
	public UNKNOWN deleteFile(String o0){ return null; }
	public UNKNOWN disconnect(){ return null; }
}
