import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4281604 {
public UNKNOWN parsePOIResponse(String o0, DirectoryParams o1){ return null; }
	public UNKNOWN makePOIRequest(QueryFilter o0){ return null; }
    private void executeRequest(OperationContext context) throws Throwable, java.lang.Throwable {
        long t1 = System.currentTimeMillis();
        DirectoryParams params =(DirectoryParams)(Object) context.getRequestOptions().getDirectoryOptions();
        try {
            String srvCfg =(String)(Object) context.getRequestContext().getApplicationConfiguration().getCatalogConfiguration().getParameters().getValue("openls.directory");
            HashMap<String, String> poiProperties =(HashMap<String,String>)(Object) params.getPoiProperties();
            Set<String> keys = poiProperties.keySet();
            Iterator<String> iter = keys.iterator();
            StringBuffer filter = new StringBuffer();
            while (iter.hasNext()) {
                String key = iter.next();
                QueryFilter queryFilter = new QueryFilter(key, poiProperties.get(key));
                filter.append(makePOIRequest(queryFilter));
            }
            String sUrl = srvCfg + "/query?" + filter.toString();
            UNKNOWN LOGGER = new UNKNOWN();
            LOGGER.info("REQUEST=\n" + sUrl);
            URL url = new URL(sUrl);
            URLConnection conn = url.openConnection();
            String line = "";
            String sResponse = "";
            InputStream is = conn.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader rd = new BufferedReader(isr);
            while ((line = rd.readLine()) != null) {
                sResponse += line;
            }
            rd.close();
            url = null;
            parsePOIResponse(sResponse, params);
        } catch (Exception p_e) {
            UNKNOWN LOGGER = new UNKNOWN();
            LOGGER.severe("Throwing exception" + p_e.getMessage());
            throw p_e;
        } finally {
            long t2 = System.currentTimeMillis();
            UNKNOWN LOGGER = new UNKNOWN();
            LOGGER.info("PERFORMANCE: " + (t2 - t1) + " ms spent performing service");
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getParameters(){ return null; }
	public UNKNOWN getDirectoryOptions(){ return null; }
	public UNKNOWN getCatalogConfiguration(){ return null; }
	public UNKNOWN severe(String o0){ return null; }
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN getValue(String o0){ return null; }
	public UNKNOWN getApplicationConfiguration(){ return null; }
}

class OperationContext {
	
	public UNKNOWN getRequestContext(){ return null; }
	public UNKNOWN getRequestOptions(){ return null; }
}

class DirectoryParams {
	
	public UNKNOWN getPoiProperties(){ return null; }
}

class QueryFilter {
	
	QueryFilter(String o0, String o1){}
	QueryFilter(){}
}
