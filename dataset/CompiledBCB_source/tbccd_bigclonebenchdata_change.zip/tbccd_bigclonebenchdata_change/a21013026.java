import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21013026 {
    private InputStream getPageStream(String query) throws Throwable, MalformedURLException, IOException {
        UNKNOWN baseUrl = new UNKNOWN();
        URL url = new URL(baseUrl + query + "&rhtml=no");
        URLConnection connection = url.openConnection();
        connection.connect();
        InputStream in = connection.getInputStream();
        BufferedInputStream bis = new BufferedInputStream(in);
        return bis;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
