import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7981027 {
public static UNKNOWN SALT_LENGTH;
	public static UNKNOWN hexStringToByte(String o0){ return null; }
//public UNKNOWN SALT_LENGTH;
//	public UNKNOWN hexStringToByte(String o0){ return null; }
    public static boolean validPassword(String password, String passwordInDb) throws Throwable, NoSuchAlgorithmException, UnsupportedEncodingException {
        byte[] pwdInDb =(byte[])(Object) hexStringToByte(passwordInDb);
        byte[] salt = new byte[(int)(Object)SALT_LENGTH];
        System.arraycopy(pwdInDb, 0, salt, 0,(int)(Object) SALT_LENGTH);
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(salt);
        md.update(password.getBytes("UTF-8"));
        byte[] digest = md.digest();
        byte[] digestInDb = new byte[pwdInDb.length - (int)(Object)SALT_LENGTH];
        System.arraycopy(pwdInDb,(int)(Object) SALT_LENGTH, digestInDb, 0, digestInDb.length);
        if (Arrays.equals(digest, digestInDb)) {
            return true;
        } else {
            return false;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
