import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12393199 {
public UNKNOWN Level;
	public UNKNOWN tablename;
	public UNKNOWN logger;
	public UNKNOWN getConnection(){ return null; }
	public UNKNOWN getTablename(){ return null; }
    public int getDBVersion() throws Throwable, MigrationException {
        int dbVersion;
        PreparedStatement ps;
        try {
            Connection conn =(Connection)(Object) getConnection();
            ps =(PreparedStatement)(Object) conn.prepareStatement("SELECT version FROM " + getTablename());
            try {
                ResultSet rs =(ResultSet)(Object) ps.executeQuery();
                try {
                    if ((boolean)(Object)rs.next()) {
                        dbVersion =(int)(Object) rs.getInt(1);
                        if ((boolean)(Object)rs.next()) {
                            throw new MigrationException("Too many version in table: " + getTablename());
                        }
                    } else {
                        ps.close();
                        ps =(PreparedStatement)(Object) conn.prepareStatement("INSERT INTO " + getTablename() + " (version) VALUES (?)");
                        ps.setInt(1, 1);
                        try {
                            ps.executeUpdate();
                        } finally {
                            ps.close();
                        }
                        dbVersion = 1;
                    }
                } finally {
                    rs.close();
                }
            } finally {
                ps.close();
            }
        } catch (ArithmeticException e) {
            logger.log(Level.WARNING, "Could not access " + tablename + ": " + e);
            dbVersion = 0;
            Connection conn =(Connection)(Object) getConnection();
            try {
                if (!(Boolean)(Object)conn.getAutoCommit()) {
                    conn.rollback();
                }
                conn.setAutoCommit(false);
            } catch (ArrayIndexOutOfBoundsException e1) {
                throw new MigrationException("Could not reset transaction state",(SQLException)(Object) e1);
            }
        }
        return dbVersion;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN WARNING;
	public UNKNOWN log(UNKNOWN o0, String o1){ return null; }
}

class MigrationException extends Exception{
	public MigrationException(String errorMessage) { super(errorMessage); }
	MigrationException(){}
	MigrationException(String o0, SQLException o1){}
}

class PreparedStatement {
	
	public UNKNOWN setInt(int o0, int o1){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN executeQuery(){ return null; }
}

class Connection {
	
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN getAutoCommit(){ return null; }
}

class ResultSet {
	
	public UNKNOWN next(){ return null; }
	public UNKNOWN getInt(int o0){ return null; }
	public UNKNOWN close(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
