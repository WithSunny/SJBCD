import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13506128 {
public static UNKNOWN converterBytesEmHexa(byte[] o0){ return null; }
//public UNKNOWN converterBytesEmHexa(byte[] o0){ return null; }
    public static String gerarDigest(String mensagem)  throws Throwable {
        String mensagemCriptografada = null;
        try {
            MessageDigest md = MessageDigest.getInstance("SHA");
            System.out.println("Mensagem original: " + mensagem);
            md.update(mensagem.getBytes());
            byte[] digest = md.digest();
            mensagemCriptografada =(String)(Object) converterBytesEmHexa(digest);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mensagemCriptografada;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
