import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1172494 {
public static UNKNOWN toHexString(byte[] o0){ return null; }
//public UNKNOWN toHexString(byte[] o0){ return null; }
    public static String encrypt(String input)  throws Throwable {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            md.update(input.getBytes("UTF-8"));
            return(String)(Object) toHexString(md.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
