import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17347053 {
public UNKNOWN BUFFRE_SIZE;
	public UNKNOWN destFile;
	public UNKNOWN url;
	public UNKNOWN checkAbortFlag(){ return null; }
	public UNKNOWN cancelled(){ return null; }
	public UNKNOWN started(long o0){ return null; }
	public UNKNOWN finished(){ return null; }
	public UNKNOWN progress(long o0){ return null; }
	public UNKNOWN checkState(){ return null; }
//    @Override
    public HttpResponse makeRequest() throws Throwable, RequestCancelledException, IllegalStateException, IOException {
        checkState();
        OutputStream out = null;
        InputStream in = null;
        try {
            out = new BufferedOutputStream(new FileOutputStream((String)(Object)destFile));
            URLConnection conn =(URLConnection)(Object) url.openConnection();
            in = conn.getInputStream();
            byte[] buffer = new byte[(int)(Object)BUFFRE_SIZE];
            int numRead;
            long totalSize = conn.getContentLength();
            long transferred = 0;
            started(totalSize);
            while (!(Boolean)(Object)checkAbortFlag() && (numRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, numRead);
                out.flush();
                transferred += numRead;
                progress(transferred);
            }
            if ((boolean)(Object)checkAbortFlag()) {
                cancelled();
            } else {
                finished();
            }
            if ((boolean)(Object)checkAbortFlag()) {
                throw new RequestCancelledException();
            }
        } finally {
            if (out != null) {
                out.close();
            }
            if (in != null) {
                in.close();
            }
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN openConnection(){ return null; }
}

class HttpResponse {
	
	
}

class RequestCancelledException extends Exception{
	public RequestCancelledException(String errorMessage) { super(errorMessage); }
	RequestCancelledException(){}
}
