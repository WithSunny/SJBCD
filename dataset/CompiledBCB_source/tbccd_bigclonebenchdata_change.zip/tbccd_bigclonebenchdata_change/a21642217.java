import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21642217 {
public UNKNOWN Logger;
    private String searchMetabolite(String name)  throws Throwable {
        {
            BufferedReader in = null;
            try {
                String urlName = name;
                URL url = new URL(urlName);
                in = new BufferedReader(new InputStreamReader(url.openStream()));
                String inputLine;
                Boolean isMetabolite = false;
                while ((inputLine = in.readLine()) != null) {
                    if (inputLine.contains("Metabolite</h1>")) {
                        isMetabolite = true;
                    }
                    if (inputLine.contains("<td><a href=\"/Metabolites/") && isMetabolite) {
                        String metName = inputLine.substring(inputLine.indexOf("/Metabolites/") + 13, inputLine.indexOf("aspx\" target") + 4);
                        return "http://gmd.mpimp-golm.mpg.de/Metabolites/" + metName;
                    }
                }
                in.close();
                return name;
            } catch (IOException ex) {
                UNKNOWN Level = new UNKNOWN();
                Logger.getLogger(GetGolmIDsTask.class.getName()).log(Level.SEVERE, null, ex);
                return null;
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN SEVERE;
	public UNKNOWN getLogger(String o0){ return null; }
	public UNKNOWN log(UNKNOWN o0, Object o1, IOException o2){ return null; }
}

class GetGolmIDsTask {
	
	
}
