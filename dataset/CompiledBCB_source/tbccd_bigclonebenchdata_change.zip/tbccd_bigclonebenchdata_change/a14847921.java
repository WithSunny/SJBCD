import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14847921 {
    protected static void copyFile(File from, File to) throws Throwable, IOException {
        if (!from.isFile() || !to.isFile()) {
            throw new IOException("Both parameters must be files. from is " + from.isFile() + ", to is " + to.isFile());
        }
        FileChannel in =(FileChannel)(Object) (new FileInputStream(from)).getChannel();
        FileChannel out =(FileChannel)(Object) (new FileOutputStream(to)).getChannel();
        in.transferTo(0, from.length(), out);
        in.close();
        out.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, long o1, FileChannel o2){ return null; }
	public UNKNOWN close(){ return null; }
}
