import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8119563 {
    protected boolean checkLink(URL url)  throws Throwable {
        try {
            URLConnection connection = url.openConnection();
            connection.connect();
            return true;
        } catch (IOException e) {
            UNKNOWN MsgLog = new UNKNOWN();
            MsgLog.error("DapParser.checkLink(): IOException: " + e.toString());
            return false;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0){ return null; }
}
