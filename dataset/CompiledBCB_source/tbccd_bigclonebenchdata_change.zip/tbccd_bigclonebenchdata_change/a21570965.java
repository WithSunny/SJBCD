import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21570965 {
public static UNKNOWN getLongProperty(FileInputStream o0, UNKNOWN o1){ return null; }
//public UNKNOWN getLongProperty(FileInputStream o0, UNKNOWN o1){ return null; }
    public static void main(String[] args) throws Throwable, FileNotFoundException, IOException {
        String filePath = "/Users/francisbaril/Downloads/test-1.pdf";
        String testFilePath = "/Users/francisbaril/Desktop/testpdfbox/test.pdf";
        File file = new File(filePath);
        final File testFile = new File(testFilePath);
        if (testFile.exists()) {
            testFile.delete();
        }
        UNKNOWN IOUtils = new UNKNOWN();
        IOUtils.copy(new FileInputStream(file), new FileOutputStream(testFile));
        UNKNOWN PROPRIETE_ID_IGID = new UNKNOWN();
        System.out.println(getLongProperty(new FileInputStream(testFile), PROPRIETE_ID_IGID));
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(FileInputStream o0, FileOutputStream o1){ return null; }
}
