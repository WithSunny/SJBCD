import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22347366 {
    private static BufferedReader createReaderConnection(String urlString) throws Throwable, SiteNotFoundException {
        BufferedReader reader = null;
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("User-agent", "Mozilla/4.5");
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                UNKNOWN Logger = new UNKNOWN();
                Logger.logln("Response code for url [" + urlString + "] was " + conn.getResponseCode() + " [" + conn.getResponseMessage() + "]");
                throw new SiteNotFoundException(urlString);
            }
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        } catch (IOException ex) {
            UNKNOWN Logger = new UNKNOWN();
            Logger.logln("" + ex);
        }
        return reader;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN logln(String o0){ return null; }
}

class SiteNotFoundException extends Exception{
	public SiteNotFoundException(String errorMessage) { super(errorMessage); }
}
