import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13946197 {
    public String transformByMD5(String password) throws Throwable, XSServiceException {
        MessageDigest md5;
        byte[] output;
        StringBuffer bufferPass;
        try {
            md5 = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            UNKNOWN logger = new UNKNOWN();
            logger.warn("DataAccessException thrown while getting MD5 algorithm:" + e.getMessage(), e);
            throw new XSServiceException("Database error while saving user");
        }
        md5.reset();
        md5.update(password.getBytes());
        output = md5.digest();
        bufferPass = new StringBuffer();
        for (byte b : output) {
            bufferPass.append(Integer.toHexString(0xff & b).length() == 1 ? "0" + Integer.toHexString(0xff & b) : Integer.toHexString(0xff & b));
        }
        return bufferPass.toString();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN warn(String o0, NoSuchAlgorithmException o1){ return null; }
}

class XSServiceException extends Exception{
	public XSServiceException(String errorMessage) { super(errorMessage); }
}
