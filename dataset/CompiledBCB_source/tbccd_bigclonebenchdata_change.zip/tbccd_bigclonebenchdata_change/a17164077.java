import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17164077 {
public UNKNOWN InputOutput;
public UNKNOWN config;
	public UNKNOWN initMessages(){ return null; }
	public UNKNOWN paramsInfo(){ return null; }
	public UNKNOWN initParms(){ return null; }
	public UNKNOWN log(String o0){ return null; }
	public UNKNOWN messagesInfo(){ return null; }
	public UNKNOWN checkMessageId(){ return null; }
    public void readConfig(String urlString) throws Throwable, Exception {
        try {
            URL url = new URL(urlString);
            InputStream in = url.openStream();
            XmlDoc xml = (XmlDoc)(Object)new Parser().parse(new InputSource(in), true, true);
            UNKNOWN SCHEMA = new UNKNOWN();
            Verifier v = new Verifier(InputOutput.create(SCHEMA), null);
            v.verify(xml.getDocument());
            this.config = xml.getDocument();
        } catch (Exception e) {
            log("Can't read " + urlString + ": " + e.toString());
            throw e;
        }
        initParms();
        log("Got parameters: \n" + paramsInfo());
        initMessages();
        log("Got messages: \n" + messagesInfo());
        checkMessageId();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN create(UNKNOWN o0){ return null; }
}

class XmlDoc {
	
	public UNKNOWN getDocument(){ return null; }
}

class InputSource {
	
	InputSource(InputStream o0){}
	InputSource(){}
}

class Parser {
	
	public UNKNOWN parse(InputSource o0, boolean o1, boolean o2){ return null; }
}

class Verifier {
	
	Verifier(UNKNOWN o0, Object o1){}
	Verifier(){}
	public UNKNOWN verify(UNKNOWN o0){ return null; }
}
