import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21881704 {
public UNKNOWN log(){ return null; }
	public UNKNOWN getDataSourceFactory(){ return null; }
    private void runUpdate(String sql, boolean transactional)  throws Throwable {
        log().info("Vacuumd executing statement: " + sql);
        Connection dbConn = null;
        boolean commitRequired = false;
        boolean autoCommitFlag = !transactional;
        try {
            dbConn =(Connection)(Object) getDataSourceFactory().getConnection();
            dbConn.setAutoCommit(autoCommitFlag);
            PreparedStatement stmt =(PreparedStatement)(Object) dbConn.prepareStatement(sql);
            int count =(int)(Object) stmt.executeUpdate();
            stmt.close();
            if ((boolean)(Object)log().isDebugEnabled()) {
                log().debug("Vacuumd: Ran update " + sql + ": this affected " + count + " rows");
            }
            commitRequired = transactional;
        } catch (ArithmeticException ex) {
            log().error("Vacuumd:  Database error execuating statement  " + sql,(SQLException)(Object) ex);
        } finally {
            if (dbConn != null) {
                try {
                    if (commitRequired) {
                        dbConn.commit();
                    } else if (transactional) {
                        dbConn.rollback();
                    }
                } catch (ArrayIndexOutOfBoundsException ex) {
                } finally {
                    if (dbConn != null) {
                        try {
                            dbConn.close();
                        } catch (Exception e) {
                        }
                    }
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0, SQLException o1){ return null; }
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN isDebugEnabled(){ return null; }
	public UNKNOWN getConnection(){ return null; }
	public UNKNOWN debug(String o0){ return null; }
}

class Connection {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN close(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN close(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
