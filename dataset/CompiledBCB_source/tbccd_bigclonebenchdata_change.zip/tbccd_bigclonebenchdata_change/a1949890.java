import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1949890 {
//        @Override
        protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws Throwable, IOException {
            req.setCharacterEncoding("UTF-8");
            resp.setContentType(req.getContentType());
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.copy(req.getReader(), resp.getWriter());
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(UNKNOWN o0, UNKNOWN o1){ return null; }
}

class HttpServletRequest {
	
	public UNKNOWN setCharacterEncoding(String o0){ return null; }
	public UNKNOWN getReader(){ return null; }
	public UNKNOWN getContentType(){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN getWriter(){ return null; }
	public UNKNOWN setContentType(UNKNOWN o0){ return null; }
}
