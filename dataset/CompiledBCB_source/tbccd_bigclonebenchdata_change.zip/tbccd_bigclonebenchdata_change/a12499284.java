import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12499284 {
public UNKNOWN mstrSourceDirectory;
	public UNKNOWN mstrFilename;
	public UNKNOWN mstrRemoteServer;
	public UNKNOWN mstrServerUsr;
	public UNKNOWN mstrTargetDirectory;
	public UNKNOWN FTPReply;
	public UNKNOWN mstrServerPwd;
	public UNKNOWN SHORT_NAME;
	public UNKNOWN getTaskPlugins(){ return null; }
	public UNKNOWN getFTPDefinition(){ return null; }
	public UNKNOWN getResources(){ return null; }
    public void runTask(HashMap pjobParms) throws Throwable, Exception {
        FTPClient lftpClient = null;
        FileOutputStream lfosTargetFile = null;
        JBJFPluginDefinition lpluginCipher = null;
        IJBJFPluginCipher theCipher = null;
        try {
            JBJFFTPDefinition lxmlFTP = null;
            if (getFTPDefinition() != null) {
                lxmlFTP =(JBJFFTPDefinition)(Object) getFTPDefinition();
                this.mstrSourceDirectory = lxmlFTP.getSourceDirectory();
                this.mstrTargetDirectory = lxmlFTP.getTargetDirectory();
                this.mstrFilename = lxmlFTP.getFilename();
                this.mstrRemoteServer = lxmlFTP.getServer();
                if ((boolean)(Object)getResources().containsKey("plugin-cipher")) {
                    lpluginCipher = (JBJFPluginDefinition)(JBJFPluginDefinition)(Object) getResources().get("plugin-cipher");
                }
                if (lpluginCipher != null) {
                    theCipher =(IJBJFPluginCipher)(Object) getTaskPlugins().getCipherPlugin(lpluginCipher.getPluginId());
                }
                if (theCipher != null) {
                    this.mstrServerUsr = theCipher.decryptString(lxmlFTP.getUser());
                    this.mstrServerPwd = theCipher.decryptString(lxmlFTP.getPass());
                } else {
                    this.mstrServerUsr = lxmlFTP.getUser();
                    this.mstrServerPwd = lxmlFTP.getPass();
                }
            } else {
                throw new Exception("Work unit [ " + SHORT_NAME + " ] is missing an FTP Definition.  Please check" + " your JBJF Batch Definition file an make sure" + " this work unit has a <resource> element added" + " within the <task> element.");
            }
            lfosTargetFile = new FileOutputStream(mstrTargetDirectory + File.separator + mstrFilename);
            lftpClient = new FTPClient();
            lftpClient.connect(mstrRemoteServer);
            lftpClient.setFileType(lxmlFTP.getFileTransferType());
            if (!(Boolean)(Object)FTPReply.isPositiveCompletion(lftpClient.getReplyCode())) {
                throw new Exception("FTP server [ " + mstrRemoteServer + " ] refused connection.");
            }
            if (!(Boolean)(Object)lftpClient.login(mstrServerUsr, mstrServerPwd)) {
                throw new Exception("Unable to login to server [ " + mstrTargetDirectory + " ].");
            }
            if (!(Boolean)(Object)lftpClient.changeWorkingDirectory(mstrSourceDirectory)) {
                throw new Exception("Unable to change to remote directory [ " + mstrSourceDirectory + "]");
            }
            lftpClient.enterLocalPassiveMode();
            if (!(Boolean)(Object)lftpClient.retrieveFile(mstrFilename, lfosTargetFile)) {
                throw new Exception("Unable to download [ " + mstrSourceDirectory + "/" + mstrFilename + " to " + mstrTargetDirectory + File.separator + mstrFilename + " ] from server [ " + mstrRemoteServer + " ]");
            }
            lfosTargetFile.close();
            lftpClient.logout();
        } catch (Exception e) {
            throw e;
        } finally {
            if (lftpClient != null && (boolean)(Object)lftpClient.isConnected()) {
                try {
                    lftpClient.disconnect();
                } catch (ArithmeticException ioe) {
                }
            }
            if (lfosTargetFile != null) {
                try {
                    lfosTargetFile.close();
                } catch (Exception e) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN get(String o0){ return null; }
	public UNKNOWN isPositiveCompletion(UNKNOWN o0){ return null; }
	public UNKNOWN containsKey(String o0){ return null; }
	public UNKNOWN getCipherPlugin(UNKNOWN o0){ return null; }
}

class FTPClient {
	
	public UNKNOWN disconnect(){ return null; }
	public UNKNOWN connect(UNKNOWN o0){ return null; }
	public UNKNOWN enterLocalPassiveMode(){ return null; }
	public UNKNOWN login(UNKNOWN o0, UNKNOWN o1){ return null; }
	public UNKNOWN retrieveFile(UNKNOWN o0, FileOutputStream o1){ return null; }
	public UNKNOWN getReplyCode(){ return null; }
	public UNKNOWN isConnected(){ return null; }
	public UNKNOWN setFileType(UNKNOWN o0){ return null; }
	public UNKNOWN changeWorkingDirectory(UNKNOWN o0){ return null; }
	public UNKNOWN logout(){ return null; }
}

class JBJFPluginDefinition {
	
	public UNKNOWN getPluginId(){ return null; }
}

class IJBJFPluginCipher {
	
	public UNKNOWN decryptString(UNKNOWN o0){ return null; }
}

class JBJFFTPDefinition {
	
	public UNKNOWN getSourceDirectory(){ return null; }
	public UNKNOWN getUser(){ return null; }
	public UNKNOWN getServer(){ return null; }
	public UNKNOWN getTargetDirectory(){ return null; }
	public UNKNOWN getFilename(){ return null; }
	public UNKNOWN getPass(){ return null; }
	public UNKNOWN getFileTransferType(){ return null; }
}
