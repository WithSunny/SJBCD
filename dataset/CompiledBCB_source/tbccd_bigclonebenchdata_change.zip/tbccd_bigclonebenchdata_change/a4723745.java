import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4723745 {
    public static String encodePassword(String password)  throws Throwable {
        try {
            MessageDigest messageDiegest = MessageDigest.getInstance("SHA-1");
            messageDiegest.update(password.getBytes("UTF-8"));
            return(String)(Object) Base64.encodeToString(messageDiegest.digest(), false);
        } catch (NoSuchAlgorithmException e) {
            UNKNOWN log = new UNKNOWN();
            log.error("Exception while encoding password");
            throw new Error(e);
        } catch (UnsupportedEncodingException e) {
            UNKNOWN log = new UNKNOWN();
            log.error("Exception while encoding password");
            throw new Error(e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0){ return null; }
}

class Base64 {
	
	public static UNKNOWN encodeToString(byte[] o0, boolean o1){ return null; }
}
