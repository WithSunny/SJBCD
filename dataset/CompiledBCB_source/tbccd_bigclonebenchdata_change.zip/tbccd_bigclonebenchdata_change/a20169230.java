import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20169230 {
public UNKNOWN INSERT_IDENTITY_STATEMENT;
	public UNKNOWN LOGGER;
	public UNKNOWN USER_IDENTITY_VALUE;
	public UNKNOWN closeConnection(){ return null; }
	public UNKNOWN getConnection(){ return null; }
//    @Override
    public String addUserIdentity(OpenIDItem identity, long userId) throws Throwable, DatabaseException {
        if (identity == null) throw new NullPointerException("identity");
        if (identity.getIdentity() == null || "".equals(identity.getIdentity())) throw new NullPointerException("identity.getIdentity()");
        try {
            getConnection().setAutoCommit(false);
        } catch (ArithmeticException e) {
            LOGGER.warn("Unable to set autocommit off",(SQLException)(Object) e);
        }
        String retID = "exist";
        PreparedStatement insSt = null, seqSt = null;
        try {
            int modified = 0;
            insSt =(PreparedStatement)(Object) getConnection().prepareStatement(INSERT_IDENTITY_STATEMENT);
            insSt.setLong(1, userId);
            insSt.setString(2, identity.getIdentity());
            modified =(int)(Object) insSt.executeUpdate();
            seqSt =(PreparedStatement)(Object) getConnection().prepareStatement(USER_IDENTITY_VALUE);
            ResultSet rs =(ResultSet)(Object) seqSt.executeQuery();
            while ((boolean)(Object)rs.next()) {
                retID =(String)(Object) rs.getString(1);
            }
            if (modified == 1) {
                getConnection().commit();
                LOGGER.debug("DB has been updated. Queries: \"" + seqSt + "\" and \"" + insSt + "\"");
            } else {
                getConnection().rollback();
                LOGGER.debug("DB has not been updated -> rollback! Queries: \"" + seqSt + "\" and \"" + insSt + "\"");
                retID = "error";
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            LOGGER.error((SQLException)(Object)e);
            retID = "error";
        } finally {
            closeConnection();
        }
        return retID;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(SQLException o0){ return null; }
	public UNKNOWN warn(String o0, SQLException o1){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN prepareStatement(UNKNOWN o0){ return null; }
	public UNKNOWN debug(String o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
}

class OpenIDItem {
	
	public UNKNOWN getIdentity(){ return null; }
}

class DatabaseException extends Exception{
	public DatabaseException(String errorMessage) { super(errorMessage); }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class PreparedStatement {
	
	public UNKNOWN setLong(int o0, long o1){ return null; }
	public UNKNOWN setString(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN executeQuery(){ return null; }
}

class ResultSet {
	
	public UNKNOWN next(){ return null; }
	public UNKNOWN getString(int o0){ return null; }
}
