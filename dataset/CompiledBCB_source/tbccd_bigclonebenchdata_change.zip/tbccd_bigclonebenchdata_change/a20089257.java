import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20089257 {
public UNKNOWN IOUtils;
	public UNKNOWN zipOutput;
	public UNKNOWN toIgnore;
	public UNKNOWN normalizePath(String o0){ return null; }
    public void store(String path, InputStream stream) throws Throwable, IOException {
        toIgnore.add(normalizePath(path));
        ZipEntry entry = new ZipEntry(path);
        zipOutput.putNextEntry(entry);
        IOUtils.copy(stream, zipOutput);
        zipOutput.closeEntry();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN putNextEntry(ZipEntry o0){ return null; }
	public UNKNOWN copy(InputStream o0, UNKNOWN o1){ return null; }
	public UNKNOWN closeEntry(){ return null; }
	public UNKNOWN add(UNKNOWN o0){ return null; }
}

class ZipEntry {
	
	ZipEntry(String o0){}
	ZipEntry(){}
}
