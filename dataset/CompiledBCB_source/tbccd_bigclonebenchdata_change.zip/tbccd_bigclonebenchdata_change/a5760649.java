import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a5760649 {
public UNKNOWN fileResourceManager;
public UNKNOWN LOGGER;
	public UNKNOWN IOUtils;
	public UNKNOWN txId;
    public void createFile(File src, String filename) throws Throwable, IOException {
        try {
            FileInputStream fis = new FileInputStream(src);
            OutputStream fos =(OutputStream)(Object) this.fileResourceManager.writeResource(this.txId, filename);
            IOUtils.copy(fis, fos);
            fos.close();
            fis.close();
        } catch (ArithmeticException e) {
            LOGGER.error((ResourceManagerException)(Object)e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN writeResource(UNKNOWN o0, String o1){ return null; }
	public UNKNOWN copy(FileInputStream o0, OutputStream o1){ return null; }
	public UNKNOWN error(ResourceManagerException o0){ return null; }
}

class ResourceManagerException extends Exception{
	public ResourceManagerException(String errorMessage) { super(errorMessage); }
}
