import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14259991 {
public UNKNOWN quotaBeans;
	public UNKNOWN storageUrlString;
	public UNKNOWN validParameters(){ return null; }
    private void sendLocal() throws Throwable, Exception {
        if ((boolean)(Object)validParameters()) {
            URL url = new URL((String)(Object)storageUrlString);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            RequestUtils requestUtils = new RequestUtils();
            requestUtils.preRequestAddParameter("senderObj", "QuotaSender");
            requestUtils.preRequestAddParameter("beanNumbers", new String().valueOf(quotaBeans.size()));
            for (int vPos = 0; vPos < (int)(Object)quotaBeans.size(); vPos++) {
                QuotaBean bean = (QuotaBean)(QuotaBean)(Object) quotaBeans.get(vPos);
                requestUtils.preRequestAddParameter("" + vPos + "#portalID",(String)(Object) bean.getPortalID());
                requestUtils.preRequestAddParameter("" + vPos + "#userID",(String)(Object) bean.getUserID());
                requestUtils.preRequestAddParameter("" + vPos + "#workflowID",(String)(Object) bean.getWorkflowID());
                requestUtils.preRequestAddParameter("" + vPos + "#runtimeID",(String)(Object) bean.getRuntimeID());
                requestUtils.preRequestAddParameter("" + vPos + "#plussQuotaSize", bean.getPlussQuotaSize().toString());
            }
            requestUtils.preRequestAddFile("zipFileName", "dummyZipFileName.zip");
            requestUtils.createPostRequest();
            httpURLConnection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + requestUtils.getBoundary());
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            try {
                httpURLConnection.connect();
                OutputStream out = httpURLConnection.getOutputStream();
                byte[] preBytes =(byte[])(Object) requestUtils.getPreRequestStringBytes();
                out.write(preBytes);
                out.flush();
                out.write(new String("dummyFile").getBytes());
                byte[] postBytes =(byte[])(Object) requestUtils.getPostRequestStringBytes();
                out.write(postBytes);
                out.flush();
                out.close();
                BufferedReader in = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream()));
                in.readLine();
                in.close();
                if (HttpURLConnection.HTTP_OK != httpURLConnection.getResponseCode()) {
                    throw new Exception("response not HTTP_OK !");
                }
            } catch (Exception e) {
                e.printStackTrace();
                throw new Exception("Cannot connect to: " + storageUrlString, e);
            }
        } else {
            throw new Exception("Not valid parameters: quotaBeans !");
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN get(int o0){ return null; }
}

class RequestUtils {
	
	public UNKNOWN getBoundary(){ return null; }
	public UNKNOWN createPostRequest(){ return null; }
	public UNKNOWN preRequestAddParameter(String o0, String o1){ return null; }
	public UNKNOWN getPostRequestStringBytes(){ return null; }
	public UNKNOWN getPreRequestStringBytes(){ return null; }
	public UNKNOWN preRequestAddFile(String o0, String o1){ return null; }
}

class QuotaBean {
	
	public UNKNOWN getWorkflowID(){ return null; }
	public UNKNOWN getUserID(){ return null; }
	public UNKNOWN getRuntimeID(){ return null; }
	public UNKNOWN getPlussQuotaSize(){ return null; }
	public UNKNOWN getPortalID(){ return null; }
}
