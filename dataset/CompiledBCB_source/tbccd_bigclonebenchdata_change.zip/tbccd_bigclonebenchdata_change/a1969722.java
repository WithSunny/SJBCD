import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1969722 {
public UNKNOWN url;
//    @Override
    public long getLastModifiedOn()  throws Throwable {
        try {
            final URLConnection uc =(URLConnection)(Object) this.url.openConnection();
            uc.connect();
            final long res = uc.getLastModified();
            try {
                uc.getInputStream().close();
            } catch (final Exception ignore) {
            }
            return res;
        } catch (final IOException e) {
            return 0;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN openConnection(){ return null; }
}
