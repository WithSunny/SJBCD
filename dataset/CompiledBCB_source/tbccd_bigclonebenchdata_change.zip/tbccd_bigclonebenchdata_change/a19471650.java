import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19471650 {
public static UNKNOWN base64Encode(byte[] o0){ return null; }
//public UNKNOWN base64Encode(byte[] o0){ return null; }
//    @SuppressWarnings({ "DLS", "REC" })
    public static String md5Encode(String val)  throws Throwable {
        String output = null;
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(val.getBytes());
            byte[] digest = md.digest();
            output =(String)(Object) base64Encode(digest);
        } catch (Exception e) {
        }
        return output;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
