import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17386977 {
public UNKNOWN assertEquals(UNKNOWN o0, String o1){ return null; }
public UNKNOWN assertNotNull(InputStream o0){ return null; }
    private void checkUrl(URL url) throws Throwable, IOException {
        File urlFile = new File(url.getFile());
        UNKNOWN file = new UNKNOWN();
        assertEquals(file.getCanonicalPath(), urlFile.getCanonicalPath());
        System.out.println("Using url " + url);
        InputStream openStream = url.openStream();
        assertNotNull(openStream);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getCanonicalPath(){ return null; }
}
