import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7194282 {
public static UNKNOWN createNormalizedDescriptor(JarFile2 o0){ return null; }
//public UNKNOWN createNormalizedDescriptor(JarFile2 o0){ return null; }
    public static String createNormalizedJarDescriptorDigest(String path) throws Throwable, Exception {
        String descriptor =(String)(Object) createNormalizedDescriptor(new JarFile2(path));
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(descriptor.getBytes());
            byte[] messageDigest = digest.digest();
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < messageDigest.length; i++) {
                hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class JarFile2 {
	
	JarFile2(String o0){}
	JarFile2(){}
}
