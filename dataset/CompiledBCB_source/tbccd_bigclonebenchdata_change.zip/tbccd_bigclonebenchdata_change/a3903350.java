import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3903350 {
    private static String getSummaryText(File packageFile)  throws Throwable {
        String retVal = null;
        Reader in = null;
        try {
            in = new FileReader(packageFile);
            StringWriter out = new StringWriter();
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.copy(in, out);
            StringBuffer buf = out.getBuffer();
            int pos1 = buf.indexOf("<body>");
            int pos2 = buf.lastIndexOf("</body>");
            if (pos1 >= 0 && pos1 < pos2) {
                retVal = buf.substring(pos1 + 6, pos2);
            } else {
                retVal = "";
            }
        } catch (FileNotFoundException e) {
            UNKNOWN LOG = new UNKNOWN();
            LOG.error(e.getMessage(), e);
        } catch (IOException e) {
            UNKNOWN LOG = new UNKNOWN();
            LOG.error(e.getMessage(), e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    UNKNOWN LOG = new UNKNOWN();
                    LOG.error(e.getMessage(), e);
                }
            }
        }
        return retVal;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(Reader o0, StringWriter o1){ return null; }
	public UNKNOWN error(String o0, FileNotFoundException o1){ return null; }
	public UNKNOWN error(String o0, IOException o1){ return null; }
}
