import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8983517 {
    public User getUser(String userlogin)  throws Throwable {
        UserDAO userDAO = new UserDAO();
        User user = null;
        try {
            user =(User)(Object) userDAO.load(userlogin);
            if (user == null) {
                URL url = Thread.currentThread().getContextClassLoader().getResource("users.cfg");
                BufferedReader br = new BufferedReader(new InputStreamReader(url.openStream()));
                String linea = br.readLine();
                while (linea != null) {
                    StringTokenizer st = new StringTokenizer(linea, ":");
                    if (st.countTokens() == 3) {
                        String login = st.nextToken();
                        String password = st.nextToken();
                        String profile = st.nextToken();
                        if (login.equals(userlogin)) {
                            user = new User(login, password, profile);
                            userDAO.save(user);
                        }
                    } else {
                    }
                    linea = br.readLine();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class User {
	
	User(String o0, String o1, String o2){}
	User(){}
}

class UserDAO {
	
	public UNKNOWN save(User o0){ return null; }
	public UNKNOWN load(String o0){ return null; }
}
