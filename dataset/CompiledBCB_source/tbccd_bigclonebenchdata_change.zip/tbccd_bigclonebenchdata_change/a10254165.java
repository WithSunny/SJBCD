import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10254165 {
public UNKNOWN CryptionControl;
	public UNKNOWN BUFFER;
	public UNKNOWN rootKey;
	public UNKNOWN encrypLength;
	public UNKNOWN stopZipFile;
	public UNKNOWN getSubFiles(File o0){ return null; }
	public UNKNOWN getAbsFileName(String o0, File o1){ return null; }
    public void zipFile(String baseDir, String fileName, boolean encrypt) throws Throwable, Exception {
        List fileList =(List)(Object) getSubFiles(new File(baseDir));
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(fileName + ".temp"));
        ZipEntry ze = null;
        byte[] buf = new byte[(int)(Object)BUFFER];
        byte[] encrypByte = new byte[(int)(Object)encrypLength];
        int readLen = 0;
        for (int i = 0; i < fileList.size(); i++) {
            if ((boolean)(Object)stopZipFile) {
                zos.close();
                File zipFile = new File(fileName + ".temp");
                if (zipFile.exists()) zipFile.delete();
                break;
            }
            File f = (File) fileList.get(i);
            if (f.getAbsoluteFile().equals(fileName + ".temp")) continue;
            ze = new ZipEntry(getAbsFileName(baseDir, f));
            ze.setSize(f.length());
            ze.setTime(f.lastModified());
            zos.putNextEntry(ze);
            InputStream is = new BufferedInputStream(new FileInputStream(f));
            readLen = is.read(buf, 0,(int)(Object) BUFFER);
            if (encrypt) {
                if (readLen >= (int)(Object)encrypLength) {
                    System.arraycopy(buf, 0, encrypByte, 0,(int)(Object) encrypLength);
                } else if (readLen > 0) {
                    Arrays.fill(encrypByte, (byte) 0);
                    System.arraycopy(buf, 0, encrypByte, 0, readLen);
                    readLen =(int)(Object) encrypLength;
                }
                byte[] temp =(byte[])(Object) CryptionControl.getInstance().encryptoECB(encrypByte, rootKey);
                System.arraycopy(temp, 0, buf, 0,(int)(Object) encrypLength);
            }
            while (readLen != -1) {
                zos.write(buf, 0, readLen);
                readLen = is.read(buf, 0,(int)(Object) BUFFER);
            }
            is.close();
        }
        zos.close();
        File zipFile = new File(fileName + ".temp");
        if (zipFile.exists()) zipFile.renameTo(new File(fileName + ".zip"));
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN encryptoECB(byte[] o0, UNKNOWN o1){ return null; }
	public UNKNOWN getInstance(){ return null; }
}

class ZipOutputStream {
	
	ZipOutputStream(FileOutputStream o0){}
	ZipOutputStream(){}
	public UNKNOWN write(byte[] o0, int o1, int o2){ return null; }
	public UNKNOWN putNextEntry(ZipEntry o0){ return null; }
	public UNKNOWN close(){ return null; }
}

class ZipEntry {
	
	ZipEntry(){}
	ZipEntry(UNKNOWN o0){}
	public UNKNOWN setTime(long o0){ return null; }
	public UNKNOWN setSize(long o0){ return null; }
}
