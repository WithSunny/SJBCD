import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21110104 {
    public static SimpleDataTable loadDataFromFile(URL urlMetadata, URL urlData) throws Throwable, IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(urlMetadata.openStream()));
        List<String> columnNamesList = new ArrayList<String>();
        String[] lineParts = null;
        String line;
        in.readLine();
        while ((line = in.readLine()) != null) {
            lineParts = line.split(",");
            columnNamesList.add(lineParts[0]);
        }
        String[] columnNamesArray = new String[columnNamesList.size()];
        int index = 0;
        for (String s : columnNamesList) {
            columnNamesArray[index] = s;
            index++;
        }
        SimpleDataTable table = new SimpleDataTable("tabulka s daty", columnNamesArray);
        in = new BufferedReader(new InputStreamReader(urlData.openStream()));
        lineParts = null;
        line = null;
        SimpleDataTableRow tableRow;
        double[] rowData;
        while ((line = in.readLine()) != null) {
            lineParts = line.split(",");
            rowData = new double[columnNamesList.size()];
            for (int i = 0; i < columnNamesArray.length; i++) {
                rowData[i] = Double.parseDouble(lineParts[i + 1]);
            }
            tableRow = new SimpleDataTableRow(rowData, lineParts[0]);
            table.add(tableRow);
        }
        return table;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class SimpleDataTable {
	
	SimpleDataTable(){}
	SimpleDataTable(String o0, String[] o1){}
	public UNKNOWN add(SimpleDataTableRow o0){ return null; }
}

class SimpleDataTableRow {
	
	SimpleDataTableRow(){}
	SimpleDataTableRow(double[] o0, String o1){}
}
