import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a16825824 {
public UNKNOWN toResourceName(String o0, String o1){ return null; }
	public UNKNOWN toBundleName(String o0, Locale o1){ return null; }
        public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload) throws Throwable, IllegalAccessException, InstantiationException, IOException {
            String bundleName =(String)(Object) toBundleName(baseName, locale);
            String resourceName =(String)(Object) toResourceName(bundleName, "properties");
            ResourceBundle bundle = null;
            InputStream stream = null;
            if (reload) {
                URL url = loader.getResource(resourceName);
                if (url != null) {
                    URLConnection connection = url.openConnection();
                    if (connection != null) {
                        connection.setUseCaches(false);
                        stream = connection.getInputStream();
                    }
                }
            } else {
                stream = loader.getResourceAsStream(resourceName);
            }
            if (stream != null) {
                try {
                    bundle = new PropertyResourceBundle(new InputStreamReader(stream, "UTF-8"));
                } finally {
                    stream.close();
                }
            }
            return bundle;
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
