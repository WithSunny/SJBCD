import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8132219 {
    public static void copyFile(String inFile, String outFile)  throws Throwable {
        File in = new File(inFile);
        File out = new File(outFile);
        try {
            FileChannel inChannel = (FileChannel)(Object)new FileInputStream(in).getChannel();
            FileChannel outChannel = (FileChannel)(Object)new FileOutputStream(out).getChannel();
            try {
                inChannel.transferTo(0, inChannel.size(), outChannel);
            } finally {
                if (inChannel != null) inChannel.close();
                if (outChannel != null) outChannel.close();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
}
