import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4973095 {
public UNKNOWN by;
	public UNKNOWN leerHttp(HttpURLConnection o0){ return null; }
    public  void Wget2(URL url, File f) throws Throwable, IOException {
        System.out.println("bajando: " + url);
        if (f == null) {
            by =(UNKNOWN)(Object) new ByteArrayOutputStream();
        } else {
            by =(UNKNOWN)(Object) new FileOutputStream(f);
        }
        URLConnection uc = url.openConnection();
        if (uc instanceof HttpURLConnection) {
            leerHttp((HttpURLConnection) uc);
        } else {
            throw new IOException("solo se pueden descargar url http");
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
