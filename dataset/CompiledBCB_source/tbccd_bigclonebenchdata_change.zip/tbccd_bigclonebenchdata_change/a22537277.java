import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22537277 {
public UNKNOWN DriverManager;
	public UNKNOWN log(String o0){ return null; }
//    @Test
    public void testSQLite()  throws Throwable {
        log("trying SQLite..");
        for (int i = 0; i < 10; i++) {
            Connection c = null;
            try {
                Class.forName("SQLite.JDBCDriver");
                c =(Connection)(Object) DriverManager.getConnection("jdbc:sqlite:/C:/Source/SRFSurvey/app/src/org/speakright/srfsurvey/results.db", "", "");
                c.setAutoCommit(false);
                Statement st =(Statement)(Object) c.createStatement();
                int rc =(int)(Object) st.executeUpdate("INSERT INTO tblAnswers(fQID,fQNAME) VALUES('q1','zoo')");
                st.close();
                c.commit();
                c.close();
            } catch (Exception e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
                System.exit(1);
                try {
                    if (c != null && !(Boolean)(Object)c.isClosed()) {
                        c.rollback();
                        c.close();
                    }
                } catch (ArithmeticException sql) {
                }
            }
        }
        log("end");
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getConnection(String o0, String o1, String o2){ return null; }
}

class Test {
	
	
}

class Connection {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN isClosed(){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN close(){ return null; }
}

class Statement {
	
	public UNKNOWN executeUpdate(String o0){ return null; }
	public UNKNOWN close(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
