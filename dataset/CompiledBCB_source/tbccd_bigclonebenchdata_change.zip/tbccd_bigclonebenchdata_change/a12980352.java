import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12980352 {
public UNKNOWN Log;
	public UNKNOWN Modifier;
	public UNKNOWN FileFunctions;
	public UNKNOWN getAddedURLs(){ return null; }
	public UNKNOWN getURLs(){ return null; }
	public UNKNOWN loadClass(String o0){ return null; }
    public List<Class<?>> getImplementingClasses(Class<?> ancestor, boolean searchAllClasspath) throws Throwable, MutableClassLoaderException {
        List<Class<?>> classes = new LinkedList<Class<?>>();
        for (URL url :(URL[])(Object) (Object[])(Object)(searchAllClasspath ? getURLs() : getAddedURLs())) {
            Log.verbose("Checking classpath item " + url);
            if (!url.getPath().toLowerCase().endsWith("/")) {
                try {
                    JarInputStream jis = new JarInputStream(url.openStream());
                    JarEntry je;
                    while ((je =(JarEntry)(Object) jis.getNextJarEntry()) != null) {
                        Log.verbose("Checking resource " + je.getName());
                        try {
                            if ((boolean)(Object)je.getName().endsWith(".class")) {
                                Class<?> c =(Class<?>)(Object) this.loadClass((String)(Object)je.getName().replaceAll("/", ".").replaceAll(".class$", ""));
                                if (!(Boolean)(Object)Modifier.isAbstract(c.getModifiers()) && !(Boolean)(Object)Modifier.isInterface(c.getModifiers()) && ancestor.isAssignableFrom(c)) {
                                    Log.verbose("Found class " + c.getCanonicalName() + " which implements class " + ancestor.getCanonicalName());
                                    classes.add(c);
                                }
                            }
                        } catch (Error e) {
                        } catch (RuntimeException re) {
                        } catch (Exception e) {
                        }
                    }
                } catch (Exception e) {
                    Log.error(e);
                }
            } else if (url.getPath().endsWith("/")) {
                File root = new File(url.getPath());
                for (File file :(File[])(Object) (Object[])(Object)FileFunctions.getFileTree(root)) {
                    try {
                        if (file.getName().toLowerCase().endsWith(".class")) {
                            Class<?> c =(Class<?>)(Object) this.loadClass(file.getAbsolutePath().replaceAll("^" + root.getAbsolutePath() + "/", "").replaceAll("/", ".").replaceAll(".class$", ""));
                            if (!(Boolean)(Object)Modifier.isAbstract(c.getModifiers()) && !(Boolean)(Object)Modifier.isInterface(c.getModifiers()) && ancestor.isAssignableFrom(c)) {
                                Log.verbose("Found class " + c.getCanonicalName() + " which implements class " + ancestor.getCanonicalName());
                                classes.add(c);
                            }
                        }
                    } catch (Exception e) {
                        Log.error(e);
                    }
                }
            }
        }
        return classes;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN endsWith(String o0){ return null; }
	public UNKNOWN verbose(String o0){ return null; }
	public UNKNOWN isInterface(int o0){ return null; }
	public UNKNOWN isAbstract(int o0){ return null; }
	public UNKNOWN replaceAll(String o0, String o1){ return null; }
	public UNKNOWN error(Exception o0){ return null; }
	public UNKNOWN getFileTree(File o0){ return null; }
}

class MutableClassLoaderException extends Exception{
	public MutableClassLoaderException(String errorMessage) { super(errorMessage); }
}

class JarInputStream {
	
	JarInputStream(InputStream o0){}
	JarInputStream(){}
	public UNKNOWN getNextJarEntry(){ return null; }
}

class JarEntry {
	
	public UNKNOWN getName(){ return null; }
}
