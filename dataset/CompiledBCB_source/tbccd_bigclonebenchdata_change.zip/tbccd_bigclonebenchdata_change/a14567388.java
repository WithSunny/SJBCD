import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14567388 {
public UNKNOWN lengthDatabases;
	public UNKNOWN clustersMaps;
	public UNKNOWN frequencyMaps;
	public UNKNOWN clustersDatabases;
	public UNKNOWN readOnly;
	public UNKNOWN Logger;
	public UNKNOWN folder;
	public UNKNOWN pathDatabases;
	public UNKNOWN frequencyDatabases;
	public UNKNOWN lengthMaps;
	public UNKNOWN pathMaps;
	public UNKNOWN env;
	public UNKNOWN logger;
	public UNKNOWN properties;
	public UNKNOWN getNamespaces(){ return null; }
	public UNKNOWN getPaths(){ return null; }
	public UNKNOWN getTree(){ return null; }
    private  void Dataset(File f, Properties p, boolean ro) throws Throwable, DatabaseException {
        folder =(UNKNOWN)(Object) f;
        logger.debug("Opening dataset [" + ((ro) ? "readOnly" : "read/write") + " mode]");
        readOnly =(UNKNOWN)(Object) ro;
        logger = Logger.getLogger(Dataset.class);
        logger.debug("Opening environment: " + f);
        EnvironmentConfig envConfig = new EnvironmentConfig();
        envConfig.setTransactional(false);
        envConfig.setAllowCreate(!(Boolean)(Object)readOnly);
        envConfig.setReadOnly(readOnly);
        env =(UNKNOWN)(Object) new Environment(f, envConfig);
        File props = new File((String)(Object)folder, "dataset.properties");
        if (!ro && p != null) {
            this.properties =(UNKNOWN)(Object) p;
            try {
                FileOutputStream fos = new FileOutputStream(props);
                p.store(fos, null);
                fos.close();
            } catch (IOException e) {
                logger.warn("Error saving dataset properties", e);
            }
        } else {
            if (props.exists()) {
                try {
                    Properties pr = new Properties();
                    FileInputStream fis = new FileInputStream(props);
                    pr.load(fis);
                    fis.close();
                    this.properties =(UNKNOWN)(Object) pr;
                } catch (IOException e) {
                    logger.warn("Error reading dataset properties", e);
                }
            }
        }
        getPaths();
        getNamespaces();
        getTree();
        pathDatabases =(UNKNOWN)(Object) new HashMap();
        frequencyDatabases =(UNKNOWN)(Object) new HashMap();
        lengthDatabases =(UNKNOWN)(Object) new HashMap();
        clustersDatabases =(UNKNOWN)(Object) new HashMap();
        pathMaps =(UNKNOWN)(Object) new HashMap();
        frequencyMaps =(UNKNOWN)(Object) new HashMap();
        lengthMaps =(UNKNOWN)(Object) new HashMap();
        clustersMaps =(UNKNOWN)(Object) new HashMap();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getLogger(Class o0){ return null; }
	public UNKNOWN warn(String o0, IOException o1){ return null; }
	public UNKNOWN debug(String o0){ return null; }
}

class DatabaseException extends Exception{
	public DatabaseException(String errorMessage) { super(errorMessage); }
}

class Dataset {
	
	
}

class EnvironmentConfig {
	
	public UNKNOWN setReadOnly(UNKNOWN o0){ return null; }
	public UNKNOWN setAllowCreate(boolean o0){ return null; }
	public UNKNOWN setTransactional(boolean o0){ return null; }
}

class Environment {
	
	Environment(File o0, EnvironmentConfig o1){}
	Environment(){}
}
