import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19322907 {
public UNKNOWN assertThat(int o0, UNKNOWN o1){ return null; }
public UNKNOWN equalTo(int o0){ return null; }
//    @Test
    public void test_baseMaterialsForTypeID_StringInsteadOfID() throws Throwable, Exception {
        UNKNOWN baseUrl = new UNKNOWN();
        URL url = new URL(baseUrl + "/baseMaterialsForTypeID/blah-blah");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/json");
        assertThat(connection.getResponseCode(), equalTo(400));
        connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/xml");
        assertThat(connection.getResponseCode(), equalTo(400));
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Test {
	
	
}
