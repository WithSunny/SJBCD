import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23370621 {
public UNKNOWN cipher;
	public UNKNOWN IOUtils;
	public UNKNOWN FileUtils;
	public UNKNOWN downloadData(String o0){ return null; }
	public UNKNOWN fetchStream(InputStream o0){ return null; }
	public UNKNOWN getDataEncryptionKey(){ return null; }
    private void downloadFile(File target, String s3key) throws Throwable, IOException, S3ServiceException {
        InputStream in =(InputStream)(Object) downloadData(s3key);
        if (in == null) {
            throw new IOException("No data found");
        }
        in =(InputStream)(Object) new InflaterInputStream(new CryptInputStream(in, cipher, getDataEncryptionKey()));
        File temp = File.createTempFile("dirsync", null);
        FileOutputStream fout = new FileOutputStream(temp);
        try {
            IOUtils.copy(in, fout);
            if (target.exists()) {
                target.delete();
            }
            IOUtils.closeQuietly(fout);
            IOUtils.closeQuietly(in);
            FileUtils.moveFile(temp, target);
        } catch (ArithmeticException e) {
            fetchStream(in);
            throw e;
        } finally {
            IOUtils.closeQuietly(fout);
            IOUtils.closeQuietly(in);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(InputStream o0, FileOutputStream o1){ return null; }
	public UNKNOWN closeQuietly(FileOutputStream o0){ return null; }
	public UNKNOWN closeQuietly(InputStream o0){ return null; }
	public UNKNOWN moveFile(File o0, File o1){ return null; }
}

class S3ServiceException extends Exception{
	public S3ServiceException(String errorMessage) { super(errorMessage); }
}

class InflaterInputStream {
	
	InflaterInputStream(){}
	InflaterInputStream(CryptInputStream o0){}
}

class CryptInputStream {
	
	CryptInputStream(){}
	CryptInputStream(InputStream o0, UNKNOWN o1, UNKNOWN o2){}
}
