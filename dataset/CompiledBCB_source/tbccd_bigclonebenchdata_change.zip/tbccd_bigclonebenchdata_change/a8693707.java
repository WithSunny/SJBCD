import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8693707 {
        private void copy(URL url, IFile file, IProgressMonitor monitor) throws Throwable, CoreException, IOException {
            InputStream input = null;
            try {
                input = url.openStream();
                if ((boolean)(Object)file.exists()) {
                    UNKNOWN IResource = new UNKNOWN();
                    file.setContents(input, IResource.FORCE, monitor);
                } else {
                    UNKNOWN IResource = new UNKNOWN();
                    file.create(input, IResource.FORCE, monitor);
                }
            } finally {
                if (input != null) {
                    try {
                        input.close();
                    } catch (IOException ignore) {
                    }
                }
            }
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN FORCE;
	
}

class IFile {
	
	public UNKNOWN create(InputStream o0, UNKNOWN o1, IProgressMonitor o2){ return null; }
	public UNKNOWN exists(){ return null; }
	public UNKNOWN setContents(InputStream o0, UNKNOWN o1, IProgressMonitor o2){ return null; }
}

class IProgressMonitor {
	
	
}

class CoreException extends Exception{
	public CoreException(String errorMessage) { super(errorMessage); }
}
