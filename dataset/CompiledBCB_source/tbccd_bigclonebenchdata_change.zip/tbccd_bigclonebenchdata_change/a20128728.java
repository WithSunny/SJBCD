import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20128728 {
    void copyFile(File src, File dst) throws IOException {
        FileChannel inChannel = (FileChannel)(Object)new FileInputStream(src).getChannel();
        FileChannel outChannel = (FileChannel)(Object)new FileOutputStream(dst).getChannel();
        try {
            inChannel.transferTo(0, inChannel.size(), outChannel);
        } finally {
            if (inChannel != null) inChannel.close();
            if (outChannel != null) outChannel.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN transferTo(int o0, UNKNOWN o1, FileChannel o2){ return null; }
	public UNKNOWN close(){ return null; }
}
