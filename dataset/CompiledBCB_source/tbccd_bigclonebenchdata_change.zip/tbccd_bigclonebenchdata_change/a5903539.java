import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a5903539 {
public UNKNOWN Search;
	public UNKNOWN sequenceName;
	public UNKNOWN sequenceTable;
	public UNKNOWN dbi;
	public UNKNOWN current(){ return null; }
    public int next()  throws Throwable {
        int sequenceValue =(int)(Object) current();
        try {
            Update update =(Update)(Object) dbi.getUpdate();
            update.setTableName(sequenceTable);
            update.assignValue("SEQUENCE_VALUE", --sequenceValue);
            Search search = new Search();
            search.addAttributeCriteria(sequenceTable, "SEQUENCE_NAME", Search.EQUAL, sequenceName);
            update.where(search);
            int affectedRows =(int)(Object) dbi.getConnection().createStatement().executeUpdate(update.toString());
            if (affectedRows == 1) {
                dbi.getConnection().commit();
            } else {
                dbi.getConnection().rollback();
            }
        } catch (ArithmeticException sqle) {
            System.err.println("SQLException occurred in current(): " + sqle.getMessage());
        }
        return sequenceValue;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN EQUAL;
	public UNKNOWN getConnection(){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN getUpdate(){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}

class Update {
	
	public UNKNOWN where(Search o0){ return null; }
	public UNKNOWN setTableName(UNKNOWN o0){ return null; }
	public UNKNOWN assignValue(String o0, int o1){ return null; }
}

class Search {
	
	public UNKNOWN addAttributeCriteria(UNKNOWN o0, String o1, UNKNOWN o2, UNKNOWN o3){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
