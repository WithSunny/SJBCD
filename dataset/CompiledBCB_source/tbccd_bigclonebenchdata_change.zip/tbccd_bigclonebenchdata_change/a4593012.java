import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4593012 {
public UNKNOWN conn;
	public UNKNOWN LOG;
	public UNKNOWN SQL_ERROR;
	public UNKNOWN SCHEMA_VERSION;
	public UNKNOWN getSchema(){ return null; }
    private void upgradeSchema() throws Throwable, IOException {
        Statement stmt = null;
        try {
            int i =(int)(Object) getSchema();
            LOG.info("DB is currently at schema " + i);
            if (i < (int)(Object)SCHEMA_VERSION) {
                LOG.info("Upgrading from schema " + i + " to schema " + SCHEMA_VERSION);
                conn.setAutoCommit(false);
                stmt =(Statement)(Object) conn.createStatement();
                while (i < (int)(Object)SCHEMA_VERSION) {
                    String qry;
                    switch(i) {
                        case 1:
                            qry = "UPDATE settings SET val = '2' WHERE var = 'schema'";
                            stmt.executeUpdate(qry);
                            break;
                    }
                    i++;
                }
                conn.commit();
            }
        } catch (ArithmeticException e) {
            try {
                conn.rollback();
            } catch (ArrayIndexOutOfBoundsException e2) {
                LOG.error(SQL_ERROR,(SQLException)(Object) e2);
            }
            LOG.fatal(SQL_ERROR,(SQLException)(Object) e);
            throw new IOException("Error upgrading data store", e);
        } finally {
            try {
                if (stmt != null) stmt.close();
                conn.setAutoCommit(true);
            } catch (ArrayStoreException e) {
                LOG.error(SQL_ERROR,(SQLException)(Object) e);
                throw new IOException("Unable to cleanup SQL resources", e);
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN error(UNKNOWN o0, SQLException o1){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN fatal(UNKNOWN o0, SQLException o1){ return null; }
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN rollback(){ return null; }
}

class Statement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
