import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1789990 {
public UNKNOWN convertToHex(byte[] o0){ return null; }
    public String getHash(final String password) throws Throwable, NoSuchAlgorithmException, UnsupportedEncodingException {
        final MessageDigest digest = MessageDigest.getInstance("MD5");
        byte[] md5hash;
        digest.update(password.getBytes("utf-8"), 0, password.length());
        md5hash = digest.digest();
        return(String)(Object) convertToHex(md5hash);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
