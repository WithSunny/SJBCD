import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a16022035 {
public UNKNOWN setPsParams(PreparedStatement o0, Object o1){ return null; }
	public UNKNOWN closeConnectWithTransaction(Connection o0){ return null; }
public UNKNOWN result;
	public UNKNOWN ConnectUtil;
	public UNKNOWN SqlUtil;
	public UNKNOWN getCls(){ return null; }
    public boolean save(Object obj)  throws Throwable {
        boolean bool = false;
        this.result = null;
        if (obj == null) return bool;
        Connection conn = null;
        try {
            conn =(Connection)(Object) ConnectUtil.getConnect();
            conn.setAutoCommit(false);
            String sql =(String)(Object) SqlUtil.getInsertSql(this.getCls());
            PreparedStatement ps =(PreparedStatement)(Object) conn.prepareStatement(sql);
            setPsParams(ps, obj);
            ps.executeUpdate();
            ps.close();
            conn.commit();
            bool = true;
        } catch (Exception e) {
            try {
                conn.rollback();
            } catch (ArithmeticException e1) {
            }
            this.result =(UNKNOWN)(Object) e.getMessage();
        } finally {
            this.closeConnectWithTransaction(conn);
        }
        return bool;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getConnect(){ return null; }
	public UNKNOWN getInsertSql(UNKNOWN o0){ return null; }
}

class Connection {
	
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN commit(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN close(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
