import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14900316 {
public UNKNOWN getUserById(UNKNOWN o0){ return null; }
public UNKNOWN createProperties(User o0, Connection o1){ return null; }
	public UNKNOWN closeConnection(Connection o0){ return null; }
public UNKNOWN User;
	public UNKNOWN ds;
	public UNKNOWN jdbcStoreResource;
	public UNKNOWN checkUser(){ return null; }
//    @Override
    public User createUser(User bean) throws Throwable, SitoolsException {
        checkUser();
        if (!(Boolean)(Object)User.isValid(bean)) {
            throw new SitoolsException("CREATE_USER_MALFORMED");
        }
        Connection cx = null;
        try {
            cx =(Connection)(Object) ds.getConnection();
            cx.setAutoCommit(false);
            PreparedStatement st =(PreparedStatement)(Object) cx.prepareStatement(jdbcStoreResource.CREATE_USER);
            int i = 1;
            st.setString(i++, bean.getIdentifier());
            st.setString(i++, bean.getFirstName());
            st.setString(i++, bean.getLastName());
            st.setString(i++, bean.getSecret());
            st.setString(i++, bean.getEmail());
            st.executeUpdate();
            st.close();
            createProperties(bean, cx);
            if (!(Boolean)(Object)cx.getAutoCommit()) {
                cx.commit();
            }
        } catch (ArithmeticException e) {
            try {
                cx.rollback();
            } catch (ArrayIndexOutOfBoundsException e1) {
                e1.printStackTrace();
                throw new SitoolsException("CREATE_USER ROLLBACK" + e1.getMessage(),(SQLException)(Object) e1);
            }
            e.printStackTrace();
            throw new SitoolsException("CREATE_USER " + e.getMessage(),(SQLException)(Object) e);
        } finally {
            closeConnection(cx);
        }
        return(User)(Object) getUserById(bean.getIdentifier());
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN CREATE_USER;
	public UNKNOWN isValid(User o0){ return null; }
	public UNKNOWN getConnection(){ return null; }
}

class User {
	
	public UNKNOWN getEmail(){ return null; }
	public UNKNOWN getIdentifier(){ return null; }
	public UNKNOWN getFirstName(){ return null; }
	public UNKNOWN getLastName(){ return null; }
	public UNKNOWN getSecret(){ return null; }
}

class SitoolsException extends Exception{
	public SitoolsException(String errorMessage) { super(errorMessage); }
	SitoolsException(String o0, SQLException o1){}
	SitoolsException(){}
}

class Connection {
	
	public UNKNOWN prepareStatement(UNKNOWN o0){ return null; }
	public UNKNOWN getAutoCommit(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN commit(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN setString(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
