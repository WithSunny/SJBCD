import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3533516 {
public UNKNOWN FTPReply;
	public UNKNOWN FTP;
	public UNKNOWN getSeminarID(){ return null; }
	public UNKNOWN getId(){ return null; }
	public UNKNOWN getWebserver(){ return null; }
    public boolean saveLecturerecordingsXMLOnWebserver()  throws Throwable {
        boolean error = false;
        FTPClient ftp = new FTPClient();
        String lecture = "";
        try {
            URL url = new URL("http://localhost:8080/virtPresenterVerwalter/lecturerecordings.jsp?seminarid=" + this.getSeminarID());
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            String zeile = "";
            while ((zeile = in.readLine()) != null) {
                lecture += zeile + "\n";
            }
            in.close();
            http.disconnect();
        } catch (Exception e) {
            System.err.println("Konnte lecturerecordings.xml nicht lesen.");
        }
        try {
            int reply;
            ftp.connect(this.getWebserver().getUrl());
            System.out.println("Connected to " + this.getWebserver().getUrl() + ".");
            System.out.print(ftp.getReplyString());
            reply =(int)(Object) ftp.getReplyCode();
            if (!(Boolean)(Object)FTPReply.isPositiveCompletion(reply)) {
                ftp.disconnect();
                System.err.println("FTP server refused connection.");
                return false;
            }
            if (!(Boolean)(Object)ftp.login(this.getWebserver().getFtpBenutzer(), this.getWebserver().getFtpPasswort())) {
                System.err.println("FTP server: Login incorrect");
            }
            String tmpSeminarID =(String)(Object) this.getSeminarID();
            if (tmpSeminarID == null) tmpSeminarID = "unbekannt";
            try {
                ftp.changeWorkingDirectory(this.getWebserver().getDefaultPath() + "/" + tmpSeminarID + "/lectures/");
            } catch (Exception e) {
                ftp.makeDirectory(this.getWebserver().getDefaultPath() + "/" + tmpSeminarID + "/lectures/");
                ftp.changeWorkingDirectory(this.getWebserver().getDefaultPath() + "/" + tmpSeminarID + "/lectures/");
            }
            ftp.setFileType(FTP.BINARY_FILE_TYPE);
            ByteArrayInputStream lectureIn = new ByteArrayInputStream(lecture.getBytes());
            System.err.println("FTP Verzeichnis: " + ftp.printWorkingDirectory());
            ftp.storeFile("lecturerecordings.xml", lectureIn);
            lectureIn.close();
            ftp.logout();
            ftp.disconnect();
        } catch (IOException e) {
            System.err.println("Job " + this.getId() + ": Datei lecturerecordings.xml konnte nicht auf Webserver kopiert werden.");
            error = true;
            e.printStackTrace();
        } catch (NullPointerException e) {
            System.err.println("Job " + this.getId() + ": Datei lecturerecordings.xml konnte nicht auf Webserver kopiert werden. (Kein Webserver zugewiesen)");
            error = true;
        } finally {
            if ((boolean)(Object)ftp.isConnected()) {
                try {
                    ftp.disconnect();
                } catch (ArithmeticException ioe) {
                }
            }
        }
        return error;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN BINARY_FILE_TYPE;
	public UNKNOWN isPositiveCompletion(int o0){ return null; }
	public UNKNOWN getFtpPasswort(){ return null; }
	public UNKNOWN getFtpBenutzer(){ return null; }
	public UNKNOWN getDefaultPath(){ return null; }
	public UNKNOWN getUrl(){ return null; }
}

class FTPClient {
	
	public UNKNOWN makeDirectory(String o0){ return null; }
	public UNKNOWN disconnect(){ return null; }
	public UNKNOWN isConnected(){ return null; }
	public UNKNOWN printWorkingDirectory(){ return null; }
	public UNKNOWN storeFile(String o0, ByteArrayInputStream o1){ return null; }
	public UNKNOWN login(UNKNOWN o0, UNKNOWN o1){ return null; }
	public UNKNOWN connect(UNKNOWN o0){ return null; }
	public UNKNOWN changeWorkingDirectory(String o0){ return null; }
	public UNKNOWN getReplyString(){ return null; }
	public UNKNOWN setFileType(UNKNOWN o0){ return null; }
	public UNKNOWN logout(){ return null; }
	public UNKNOWN getReplyCode(){ return null; }
}
