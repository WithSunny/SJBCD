import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a5442020 {
public static UNKNOWN convertToHex(byte[] o0){ return null; }
//public UNKNOWN convertToHex(byte[] o0){ return null; }
    public static String hash(String text)  throws Throwable {
        try {
            MessageDigest md;
            md = MessageDigest.getInstance("SHA-1");
            md.update(text.getBytes("UTF-8"), 0, text.length());
            byte[] md5hash = md.digest();
            return(String)(Object) convertToHex(md5hash);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
