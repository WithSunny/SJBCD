import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9261777 {
    public static void main(String[] args)  throws Throwable {
        String source, destination;
        if (args[0].toLowerCase().endsWith(".gz")) {
            source = args[0];
            destination = source.substring(0, source.length() - 3);
        } else {
            source = args[0] + ".gz";
            destination = args[0];
        }
        InputStream is = null;
        OutputStream os = null;
        try {
            is =(InputStream)(Object) new GZIPInputStream(new FileInputStream(source));
            os = new FileOutputStream(destination);
            byte[] buffer = new byte[8192];
            for (int length; (length = is.read(buffer)) != -1; ) os.write(buffer, 0, length);
        } catch (IOException e) {
            System.err.println("Fehler: Kann nicht entpacken " + args[0]);
        } finally {
            if (os != null) try {
                os.close();
            } catch (IOException e) {
            }
            if (is != null) try {
                is.close();
            } catch (IOException e) {
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class GZIPInputStream {
	
	GZIPInputStream(FileInputStream o0){}
	GZIPInputStream(){}
}
