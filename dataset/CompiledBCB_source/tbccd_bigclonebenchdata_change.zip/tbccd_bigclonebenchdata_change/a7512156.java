import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7512156 {
public UNKNOWN CMD_LINE_SRC_PLUGIN_VERSION_OPTION;
	public UNKNOWN DEFAULT_DEST_VERSION;
	public UNKNOWN CMD_LINE_SRC_REPOSITORYURL_OPTION;
	public UNKNOWN CMD_LINE_DEST_PLUGIN_VERSION_OPTION;
	public UNKNOWN FileUtils;
	public UNKNOWN IOUtils;
	public UNKNOWN TolvenPlugin;
	public UNKNOWN RepositoryMetadata;
	public UNKNOWN CMD_LINE_SRC_PLUGIN_ID_OPTION;
	public UNKNOWN TolvenZip;
	public UNKNOWN CMD_LINE_DEST_PLUGIN_ID_OPTION;
	public UNKNOWN CMD_LINE_DEST_DIR_OPTION;
	public UNKNOWN getPluginTmpDir(){ return null; }
	public UNKNOWN getCommandOptions(){ return null; }
//    @Override
    public void execute(String[] args) throws Throwable, Exception {
        Options cmdLineOptions =(Options)(Object) getCommandOptions();
        try {
            GnuParser parser = new GnuParser();
            CommandLine commandLine =(CommandLine)(Object) parser.parse(cmdLineOptions, TolvenPlugin.getInitArgs());
            String srcRepositoryURLString =(String)(Object) commandLine.getOptionValue(CMD_LINE_SRC_REPOSITORYURL_OPTION);
            Plugins libraryPlugins =(Plugins)(Object) RepositoryMetadata.getRepositoryPlugins(new URL(srcRepositoryURLString));
            String srcPluginId =(String)(Object) commandLine.getOptionValue(CMD_LINE_SRC_PLUGIN_ID_OPTION);
            PluginDetail plugin =(PluginDetail)(Object) RepositoryMetadata.getPluginDetail(srcPluginId, libraryPlugins);
            if (plugin == null) {
                throw new RuntimeException("Could not locate plugin: " + srcPluginId + " in repository: " + srcRepositoryURLString);
            }
            String srcPluginVersionString =(String)(Object) commandLine.getOptionValue(CMD_LINE_SRC_PLUGIN_VERSION_OPTION);
            PluginVersionDetail srcPluginVersion = null;
            if (srcPluginVersion == null) {
                srcPluginVersion =(PluginVersionDetail)(Object) RepositoryMetadata.getLatestVersion(plugin);
            } else {
                srcPluginVersion =(PluginVersionDetail)(Object) RepositoryMetadata.getPluginVersionDetail(srcPluginVersionString, plugin);
            }
            if (plugin == null) {
                throw new RuntimeException("Could not find a plugin version for: " + srcPluginId + " in repository: " + srcRepositoryURLString);
            }
            String destPluginId =(String)(Object) commandLine.getOptionValue(CMD_LINE_DEST_PLUGIN_ID_OPTION);
            FileUtils.deleteDirectory(getPluginTmpDir());
            URL srcURL = new URL((String)(Object)srcPluginVersion.getUri());
            File newPluginDir = new File((String)(Object)getPluginTmpDir(), destPluginId);
            try {
                InputStream in = null;
                FileOutputStream out = null;
                File tmpZip = new File((String)(Object)getPluginTmpDir(), new File(srcURL.getFile()).getName());
                try {
                    in = srcURL.openStream();
                    out = new FileOutputStream(tmpZip);
                    IOUtils.copy(in, out);
                    TolvenZip.unzip(tmpZip, newPluginDir);
                } finally {
                    if (in != null) {
                        in.close();
                    }
                    if (out != null) {
                        out.close();
                    }
                    if (tmpZip != null) {
                        tmpZip.delete();
                    }
                }
                File pluginManifestFile = new File(newPluginDir, "tolven-plugin.xml");
                if (!pluginManifestFile.exists()) {
                    throw new RuntimeException(srcURL.toExternalForm() + "has no plugin manifest");
                }
                Plugin pluginManifest =(Plugin)(Object) RepositoryMetadata.getPlugin(pluginManifestFile.toURI().toURL());
                pluginManifest.setId(destPluginId);
                String destPluginVersion =(String)(Object) commandLine.getOptionValue(CMD_LINE_DEST_PLUGIN_VERSION_OPTION);
                if (destPluginVersion == null) {
                    destPluginVersion =(String)(Object) DEFAULT_DEST_VERSION;
                }
                pluginManifest.setVersion(destPluginVersion);
                String pluginManifestXML =(String)(Object) RepositoryMetadata.getPluginManifest(pluginManifest);
                FileUtils.writeStringToFile(pluginManifestFile, pluginManifestXML);
                File pluginFragmentManifestFile = new File(newPluginDir, "tolven-plugin-fragment.xml");
                if (pluginFragmentManifestFile.exists()) {
                    PluginFragment pluginManifestFragment =(PluginFragment)(Object) RepositoryMetadata.getPluginFragment(pluginFragmentManifestFile.toURI().toURL());
                    Requires requires =(Requires)(Object) pluginManifestFragment.getRequires();
                    if (requires == null) {
                        throw new RuntimeException("No <requires> detected for plugin fragment in: " + srcURL.toExternalForm());
                    }
                    if ((int)(Object)requires.getImport().size() != 1) {
                        throw new RuntimeException("There should be only one import for plugin fragment in: " + srcURL.toExternalForm());
                    }
                    requires.getImport().get(0).setPluginId(destPluginId);
                    requires.getImport().get(0).setPluginVersion(destPluginVersion);
                    String pluginFragmentManifestXML =(String)(Object) RepositoryMetadata.getPluginFragmentManifest(pluginManifestFragment);
                    FileUtils.writeStringToFile(pluginFragmentManifestFile, pluginFragmentManifestXML);
                }
                String destDirname =(String)(Object) commandLine.getOptionValue(CMD_LINE_DEST_DIR_OPTION);
                File destDir = new File(destDirname);
                File destZip = new File(destDir, destPluginId + "-" + destPluginVersion + ".zip");
                destDir.mkdirs();
                TolvenZip.zip(newPluginDir, destZip);
            } finally {
                if (newPluginDir != null) {
                    FileUtils.deleteDirectory(newPluginDir);
                }
            }
        } catch (ArithmeticException ex) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.printHelp(getClass().getName(), cmdLineOptions);
            throw new RuntimeException("Could not parse command line for: " + getClass().getName(), ex);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN unzip(File o0, File o1){ return null; }
	public UNKNOWN size(){ return null; }
	public UNKNOWN deleteDirectory(UNKNOWN o0){ return null; }
	public UNKNOWN getPluginDetail(String o0, Plugins o1){ return null; }
	public UNKNOWN getRepositoryPlugins(URL o0){ return null; }
	public UNKNOWN getPlugin(URL o0){ return null; }
	public UNKNOWN setPluginId(String o0){ return null; }
	public UNKNOWN writeStringToFile(File o0, String o1){ return null; }
	public UNKNOWN getPluginFragment(URL o0){ return null; }
	public UNKNOWN zip(File o0, File o1){ return null; }
	public UNKNOWN getPluginManifest(Plugin o0){ return null; }
	public UNKNOWN deleteDirectory(File o0){ return null; }
	public UNKNOWN get(int o0){ return null; }
	public UNKNOWN getLatestVersion(PluginDetail o0){ return null; }
	public UNKNOWN getInitArgs(){ return null; }
	public UNKNOWN setPluginVersion(String o0){ return null; }
	public UNKNOWN getPluginVersionDetail(String o0, PluginDetail o1){ return null; }
	public UNKNOWN getPluginFragmentManifest(PluginFragment o0){ return null; }
	public UNKNOWN copy(InputStream o0, FileOutputStream o1){ return null; }
}

class Options {
	
	
}

class GnuParser {
	
	public UNKNOWN parse(Options o0, UNKNOWN o1){ return null; }
}

class CommandLine {
	
	public UNKNOWN getOptionValue(UNKNOWN o0){ return null; }
}

class Plugins {
	
	
}

class PluginDetail {
	
	
}

class PluginVersionDetail {
	
	public UNKNOWN getUri(){ return null; }
}

class Plugin {
	
	public UNKNOWN setId(String o0){ return null; }
	public UNKNOWN setVersion(String o0){ return null; }
}

class PluginFragment {
	
	public UNKNOWN getRequires(){ return null; }
}

class Requires {
	
	public UNKNOWN getImport(){ return null; }
}

class ParseException extends Exception{
	public ParseException(String errorMessage) { super(errorMessage); }
}

class HelpFormatter {
	
	public UNKNOWN printHelp(String o0, Options o1){ return null; }
}
