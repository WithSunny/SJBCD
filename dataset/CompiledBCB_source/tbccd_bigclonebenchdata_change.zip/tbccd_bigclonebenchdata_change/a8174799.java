import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8174799 {
//    @Override
    public String getFeedFeed(String sUrl)  throws Throwable {
        try {
            URL url = new URL(sUrl);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            String result = "";
            String line;
            for (; (line = reader.readLine()) != null; result += line) {
            }
            reader.close();
            return result;
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
