import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2381663 {
public UNKNOWN expect(UNKNOWN o0){ return null; }
public UNKNOWN createContext(UNKNOWN o0, boolean o1){ return null; }
	public UNKNOWN replay(UNKNOWN o0){ return null; }
public UNKNOWN SPEC_URL;
	public UNKNOWN specFactory;
	public UNKNOWN pipeline;
	public UNKNOWN createCacheableRequest(){ return null; }
	public UNKNOWN fail(String o0){ return null; }
//    @Test(expected = GadgetException.class)
    public void malformedGadgetSpecIsCachedAndThrows() throws Throwable, Exception {
        HttpRequest request =(HttpRequest)(Object) createCacheableRequest();
        expect(pipeline.execute(request)).andReturn(new HttpResponse("malformed junk")).once();
        replay(pipeline);
        try {
            specFactory.getGadgetSpec(createContext(SPEC_URL, false));
            fail("No exception thrown on bad parse");
        } catch (ArithmeticException e) {
        }
        specFactory.getGadgetSpec(createContext(SPEC_URL, false));
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getGadgetSpec(UNKNOWN o0){ return null; }
	public UNKNOWN once(){ return null; }
	public UNKNOWN execute(HttpRequest o0){ return null; }
	public UNKNOWN andReturn(HttpResponse o0){ return null; }
}

class Test {
	
	
}

class HttpRequest {
	
	
}

class HttpResponse {
	
	HttpResponse(){}
	HttpResponse(String o0){}
}

class GadgetException extends Exception{
	public GadgetException(String errorMessage) { super(errorMessage); }
}
