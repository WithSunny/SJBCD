import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7682331 {
//    @Test
    public void testReadWrite() throws Throwable, Exception {
        final String reference = "testString";
        final Reader reader = new StringReader(reference);
        final StringWriter osString = new StringWriter();
        final Reader teeStream =(Reader)(Object) new TeeReaderWriter(reader, osString);
        UNKNOWN IOUtils = new UNKNOWN();
        IOUtils.copy(teeStream, new NullWriter());
        teeStream.close();
        osString.toString();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(Reader o0, NullWriter o1){ return null; }
}

class TeeReaderWriter {
	
	TeeReaderWriter(){}
	TeeReaderWriter(Reader o0, StringWriter o1){}
}

class NullWriter {
	
	
}
