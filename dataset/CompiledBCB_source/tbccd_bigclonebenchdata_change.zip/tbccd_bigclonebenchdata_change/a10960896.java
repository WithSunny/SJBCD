import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10960896 {
public static UNKNOWN closeConnection(Connection o0){ return null; }
	public static UNKNOWN getConnection(Database o0){ return null; }
	public static UNKNOWN closeStatement(Statement o0){ return null; }
//public UNKNOWN closeConnection(Connection o0){ return null; }
//	public UNKNOWN closeStatement(Statement o0){ return null; }
//	public UNKNOWN getConnection(Database o0){ return null; }
    public static void executeUpdate(Database db, String... statements) throws Throwable, SQLException {
        Connection con = null;
        Statement stmt = null;
        try {
            con =(Connection)(Object) getConnection(db);
            con.setAutoCommit(false);
            stmt =(Statement)(Object) con.createStatement();
            for (String statement : statements) {
                stmt.executeUpdate(statement);
            }
            con.commit();
        } catch (ArithmeticException e) {
            try {
                con.rollback();
            } catch (ArrayIndexOutOfBoundsException e1) {
            }
            throw e;
        } finally {
            closeStatement(stmt);
            closeConnection(con);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Database {
	
	
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class Connection {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
}

class Statement {
	
	public UNKNOWN executeUpdate(String o0){ return null; }
}
