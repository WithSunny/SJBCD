import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22327409 {
public UNKNOWN log(String o0){ return null; }
//    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws Throwable, ServletException {
        PrintWriter writer = null;
        InputStream is = null;
        FileOutputStream fos = null;
        try {
            writer =(PrintWriter)(Object) response.getWriter();
        } catch (ArithmeticException ex) {
            log(OctetStreamReader.class.getName() + "has thrown an exception: " + ex.getMessage());
        }
        String filename =(String)(Object) request.getHeader("X-File-Name");
        try {
            is =(InputStream)(Object) request.getInputStream();
            UNKNOWN targetPath = new UNKNOWN();
            fos = new FileOutputStream(new File(targetPath + filename));
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.copy(is, fos);
            UNKNOWN HttpServletResponse = new UNKNOWN();
            response.setStatus(HttpServletResponse.SC_OK);
            writer.print("{success: true}");
        } catch (FileNotFoundException ex) {
            UNKNOWN HttpServletResponse = new UNKNOWN();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            writer.print("{success: false}");
            log(OctetStreamReader.class.getName() + "has thrown an exception: " + ex.getMessage());
        } catch (IOException ex) {
            UNKNOWN HttpServletResponse = new UNKNOWN();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            writer.print("{success: false}");
            log(OctetStreamReader.class.getName() + "has thrown an exception: " + ex.getMessage());
        } finally {
            try {
                fos.close();
                is.close();
            } catch (IOException ignored) {
            }
        }
        writer.flush();
        writer.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN SC_INTERNAL_SERVER_ERROR;
	public UNKNOWN SC_OK;
	public UNKNOWN copy(InputStream o0, FileOutputStream o1){ return null; }
}

class HttpServletRequest {
	
	public UNKNOWN getHeader(String o0){ return null; }
	public UNKNOWN getInputStream(){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN setStatus(UNKNOWN o0){ return null; }
	public UNKNOWN getWriter(){ return null; }
}

class ServletException extends Exception{
	public ServletException(String errorMessage) { super(errorMessage); }
}

class OctetStreamReader {
	
	
}
