import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19344618 {
    private void zipdir(File base, String zipname) throws Throwable, IOException {
        FilenameFilter ff =(FilenameFilter)(Object) new ExporterFileNameFilter();
        String[] files = base.list(ff);
        File zipfile = new File(base, zipname + ".zip");
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipfile));
        byte[] buf = new byte[10240];
        for (int i = 0; i < files.length; i++) {
            File f = new File(base, files[i]);
            FileInputStream fis = new FileInputStream(f);
            zos.putNextEntry(new ZipEntry(f.getName()));
            int len;
            while ((len = fis.read(buf)) > 0) zos.write(buf, 0, len);
            zos.closeEntry();
            fis.close();
            f.delete();
        }
        zos.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ExporterFileNameFilter {
	
	
}

class ZipOutputStream {
	
	ZipOutputStream(FileOutputStream o0){}
	ZipOutputStream(){}
	public UNKNOWN close(){ return null; }
	public UNKNOWN write(byte[] o0, int o1, int o2){ return null; }
	public UNKNOWN putNextEntry(ZipEntry o0){ return null; }
	public UNKNOWN closeEntry(){ return null; }
}

class ZipEntry {
	
	ZipEntry(){}
	ZipEntry(String o0){}
}
