import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12859344 {
    private void sendFile(File file, HttpServletResponse response) throws Throwable, IOException {
        response.setContentLength((int) file.length());
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.copy(inputStream, response.getOutputStream());
        } finally {
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.closeQuietly(inputStream);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN closeQuietly(InputStream o0){ return null; }
	public UNKNOWN copy(InputStream o0, UNKNOWN o1){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN getOutputStream(){ return null; }
	public UNKNOWN setContentLength(int o0){ return null; }
}
