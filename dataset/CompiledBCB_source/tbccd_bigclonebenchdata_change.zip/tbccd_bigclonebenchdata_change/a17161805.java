import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17161805 {
    private String encode(String plaintext)  throws Throwable {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA");
            md.update(plaintext.getBytes("UTF-8"));
            byte raw[] = md.digest();
            return(String)(Object) (new BASE64Encoder()).encode(raw);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Error encoding: " + e);
        } catch (UnsupportedEncodingException e) {
            throw new IllegalStateException("Error encoding: " + e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class BASE64Encoder {
	
	public UNKNOWN encode(byte[] o0){ return null; }
}
