import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1771590 {
    public static String buildUserPassword(String password)  throws Throwable {
        String result = "";
        MessageDigest md;
        try {
            md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes("UTF8"));
            byte[] hash = md.digest();
            for (int i = 0; i < hash.length; i++) {
                int hexValue = hash[i] & 0xFF;
                if (hexValue < 16) {
                    result = result + "0";
                }
                result = result + Integer.toString(hexValue, 16);
            }
            UNKNOWN logger = new UNKNOWN();
            logger.debug("Users'password MD5 Digest: " + result);
        } catch (NoSuchAlgorithmException ex) {
            UNKNOWN logger = new UNKNOWN();
            logger.error(ex.getMessage());
            ex.printStackTrace();
        } catch (UnsupportedEncodingException ex) {
            UNKNOWN logger = new UNKNOWN();
            logger.error(ex.getMessage());
            ex.printStackTrace();
        }
        return result;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN debug(String o0){ return null; }
	public UNKNOWN error(String o0){ return null; }
}
