import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8209783 {
    List<String> HttpGet(URL url) throws IOException {
        List<String> responseList = new ArrayList<String>();
        UNKNOWN Logger = new UNKNOWN();
        Logger.getInstance().logInfo("HTTP GET: " + url, null, null);
        URLConnection con = url.openConnection();
        con.setAllowUserInteraction(false);
        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        String inputLine;
        while ((inputLine = in.readLine()) != null) responseList.add(inputLine);
        in.close();
        return responseList;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getInstance(){ return null; }
	public UNKNOWN logInfo(String o0, Object o1, Object o2){ return null; }
}
