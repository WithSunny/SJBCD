import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2829981 {
public UNKNOWN println(String o0){ return null; }
    public void copyFile() throws Throwable, Exception {
        SmbFile file = new SmbFile("smb://elsa:elsa@elsa/Elsa/Desktop/Ficheiros2/04-04-2066/How To Make a Flash Preloader.doc");
        println("length: " + file.length());
        SmbFileInputStream in = new SmbFileInputStream(file);
        println("available: " + in.available());
        File dest = new File("C:\\Documents and Settings\\Carlos\\Desktop\\Flash Preloader.doc");
        FileOutputStream out = new FileOutputStream(dest);
        int buffer_length = 1024;
        byte[] buffer = new byte[buffer_length];
        while (true) {
            int bytes_read =(int)(Object) in.read(buffer, 0, buffer_length);
            if (bytes_read <= 0) {
                break;
            }
            out.write(buffer, 0, bytes_read);
        }
        in.close();
        out.close();
        println("done.");
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class SmbFile {
	
	SmbFile(){}
	SmbFile(String o0){}
	public UNKNOWN length(){ return null; }
}

class SmbFileInputStream {
	
	SmbFileInputStream(SmbFile o0){}
	SmbFileInputStream(){}
	public UNKNOWN read(byte[] o0, int o1, int o2){ return null; }
	public UNKNOWN available(){ return null; }
	public UNKNOWN close(){ return null; }
}
