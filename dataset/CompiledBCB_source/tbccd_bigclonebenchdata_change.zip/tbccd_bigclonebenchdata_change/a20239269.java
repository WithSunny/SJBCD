import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20239269 {
public static UNKNOWN JOptionPane;
//public UNKNOWN JOptionPane;
    public static void joinFiles(FileValidator validator, File target, File[] sources)  throws Throwable {
        FileOutputStream fos = null;
        try {
            if (!(Boolean)(Object)validator.verifyFile(target)) return;
            fos = new FileOutputStream(target);
            FileInputStream fis = null;
            byte[] bytes = new byte[512];
            for (int i = 0; i < sources.length; i++) {
                fis = new FileInputStream(sources[i]);
                int nbread = 0;
                try {
                    while ((nbread = fis.read(bytes)) > -1) {
                        fos.write(bytes, 0, nbread);
                    }
                } catch (IOException ioe) {
                    UNKNOWN i18n = new UNKNOWN();
                    JOptionPane.showMessageDialog(null, ioe, i18n.getString("Failure"), JOptionPane.ERROR_MESSAGE);
                } finally {
                    fis.close();
                }
            }
        } catch (Exception e) {
            UNKNOWN i18n = new UNKNOWN();
            JOptionPane.showMessageDialog(null, e, i18n.getString("Failure"), JOptionPane.ERROR_MESSAGE);
        } finally {
            try {
                if (fos != null) fos.close();
            } catch (IOException e) {
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN ERROR_MESSAGE;
	public UNKNOWN showMessageDialog(Object o0, Exception o1, UNKNOWN o2, UNKNOWN o3){ return null; }
	public UNKNOWN getString(String o0){ return null; }
	public UNKNOWN showMessageDialog(Object o0, IOException o1, UNKNOWN o2, UNKNOWN o3){ return null; }
}

class FileValidator {
	
	public UNKNOWN verifyFile(File o0){ return null; }
}
