import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15660054 {
public static UNKNOWN Logger;
//public UNKNOWN Logger;
    public static List<PluginInfo> getPluginInfos(String urlRepo) throws Throwable, MalformedURLException, IOException {
        XStream xStream = new XStream();
        xStream.alias("plugin", PluginInfo.class);
        xStream.alias("plugins", List.class);
        List<PluginInfo> infos = null;
        URL url;
        BufferedReader in = null;
        StringBuilder buffer = new StringBuilder();
        try {
            url = new URL(urlRepo);
            in = new BufferedReader(new InputStreamReader(url.openStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                buffer.append(inputLine);
            }
        } finally {
            try {
                if (in != null) {
                    in.close();
                }
            } catch (IOException ex) {
                UNKNOWN Level = new UNKNOWN();
                Logger.getLogger(RemotePluginsManager.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        infos = (List<PluginInfo>) xStream.fromXML(buffer.toString());
        return infos;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN SEVERE;
	public UNKNOWN log(UNKNOWN o0, Object o1, IOException o2){ return null; }
	public UNKNOWN getLogger(String o0){ return null; }
}

class PluginInfo {
	
	
}

class XStream {
	
	public UNKNOWN fromXML(String o0){ return null; }
	public UNKNOWN alias(String o0, Class o1){ return null; }
}

class RemotePluginsManager {
	
	
}
