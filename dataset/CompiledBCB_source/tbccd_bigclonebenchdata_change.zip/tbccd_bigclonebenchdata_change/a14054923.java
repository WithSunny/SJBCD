import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a14054923 {
    protected Document getRawResults(String urlString, Map args) throws Throwable, Exception {
        int count = 0;
        Iterator keys = args.keySet().iterator();
        while (keys.hasNext()) {
            String sep = count++ == 0 ? "?" : "&";
            String name = (String) keys.next();
            if (args.get(name) != null) {
                urlString += sep + name + "=" + args.get(name);
            }
        }
        URL url = new URL(urlString);
        URLConnection conn = url.openConnection();
        conn.connect();
        SAXBuilder builder = new SAXBuilder();
        return(Document)(Object) builder.build(conn.getInputStream());
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Document {
	
	
}

class SAXBuilder {
	
	public UNKNOWN build(InputStream o0){ return null; }
}
