import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a7474020 {
public UNKNOWN ByteBuffer;
	public UNKNOWN fileExistAsChild(File o0, String o1){ return null; }
    protected void copyClassFiles(File initFile, File destFile)  throws Throwable {
        if (initFile != null && destFile != null) {
            File[] children = initFile.listFiles();
            File childDestinationDirectory = null, destChild = null;
            FileInputStream in = null;
            FileOutputStream out = null;
            FileChannel cin = null, cout = null;
            for (File child : children) {
                if (child != null) {
                    if (child.isDirectory()) {
                        childDestinationDirectory =(File)(Object) fileExistAsChild(destFile, child.getName());
                        if (childDestinationDirectory == null) {
                            try {
                                childDestinationDirectory = new File(destFile, child.getName());
                                childDestinationDirectory.mkdir();
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        copyClassFiles(child, childDestinationDirectory);
                    } else {
                        try {
                            destChild = new File(destFile, child.getName());
                            in = new FileInputStream(child);
                            out = new FileOutputStream(destChild);
                            cin =(FileChannel)(Object) in.getChannel();
                            cout =(FileChannel)(Object) out.getChannel();
                            ByteBuffer buffer =(ByteBuffer)(Object) ByteBuffer.allocate(1000);
                            int pos = 0;
                            while ((int)(Object)cin.position() < (int)(Object)cin.size()) {
                                pos =(int)(Object) cin.read(buffer);
                                if (pos > 0) {
                                    cout.write(buffer);
                                }
                            }
                            cin.close();
                            cout.close();
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN allocate(int o0){ return null; }
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN position(){ return null; }
	public UNKNOWN write(ByteBuffer o0){ return null; }
	public UNKNOWN read(ByteBuffer o0){ return null; }
}

class ByteBuffer {
	
	
}
