import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a18631594 {
    public static synchronized String getMD5_Base64(String input)  throws Throwable {
        MessageDigest msgDigest = null;
        try {
            msgDigest = MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("System doesn't support MD5 algorithm.");
        }
        try {
            msgDigest.update(input.getBytes("UTF-8"));
        } catch (java.io.UnsupportedEncodingException ex) {
            throw new IllegalStateException("System doesn't support your  EncodingException.");
        }
        byte[] rawData = msgDigest.digest();
        byte[] encoded =(byte[])(Object) Base64.encode(rawData);
        String retValue = new String(encoded);
        return retValue;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Base64 {
	
	public static UNKNOWN encode(byte[] o0){ return null; }
}
