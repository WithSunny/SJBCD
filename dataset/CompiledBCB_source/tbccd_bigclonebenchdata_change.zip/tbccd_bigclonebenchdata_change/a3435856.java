import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3435856 {
    public static byte[] encrypt(String string)  throws Throwable {
        java.security.MessageDigest messageDigest = null;
        try {
            messageDigest = java.security.MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException exc) {
            UNKNOWN logger = new UNKNOWN();
            logger.fatal(exc);
            throw new RuntimeException();
        }
        messageDigest.reset();
        messageDigest.update(string.getBytes());
        return messageDigest.digest();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN fatal(NoSuchAlgorithmException o0){ return null; }
}
