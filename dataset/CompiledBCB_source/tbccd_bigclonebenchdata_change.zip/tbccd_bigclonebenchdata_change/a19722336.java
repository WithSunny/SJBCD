import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19722336 {
//        @Override
        public String entryToObject(TupleInput input)  throws Throwable {
            boolean zipped =(boolean)(Object) input.readBoolean();
            if (!zipped) {
                return(String)(Object) input.readString();
            }
            int len =(int)(Object) input.readInt();
            try {
                byte array[] = new byte[len];
                input.read(array);
                GZIPInputStream in = new GZIPInputStream(new ByteArrayInputStream(array));
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                UNKNOWN IOUtils = new UNKNOWN();
                IOUtils.copyTo(in, out);
                in.close();
                out.close();
                return new String(out.toByteArray());
            } catch (IOException err) {
                throw new RuntimeException(err);
            }
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copyTo(GZIPInputStream o0, ByteArrayOutputStream o1){ return null; }
}

class TupleInput {
	
	public UNKNOWN read(byte[] o0){ return null; }
	public UNKNOWN readInt(){ return null; }
	public UNKNOWN readString(){ return null; }
	public UNKNOWN readBoolean(){ return null; }
}

class GZIPInputStream {
	
	GZIPInputStream(ByteArrayInputStream o0){}
	GZIPInputStream(){}
	public UNKNOWN close(){ return null; }
}
