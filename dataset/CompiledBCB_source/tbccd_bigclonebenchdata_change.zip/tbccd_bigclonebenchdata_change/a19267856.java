import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19267856 {
    public static void updateTableData(Connection dest, TableMetaData tableMetaData, Row r) throws Throwable, Exception {
        PreparedStatement ps = null;
        try {
            dest.setAutoCommit(false);
            String sql = "UPDATE " + tableMetaData.getSchema() + "." + tableMetaData.getTableName() + " SET ";
            for (String columnName :(String[])(Object) (Object[])(Object)tableMetaData.getColumnsNames()) {
                sql += columnName + " = ? ,";
            }
            sql = sql.substring(0, sql.length() - 1);
            sql += " WHERE ";
            for (String pkColumnName :(String[])(Object) (Object[])(Object)tableMetaData.getPkColumns()) {
                sql += pkColumnName + " = ? AND ";
            }
            sql = sql.substring(0, sql.length() - 4);
            System.out.println("UPDATE: " + sql);
            ps =(PreparedStatement)(Object) dest.prepareStatement(sql);
            int param = 1;
            for (String columnName :(String[])(Object) (Object[])(Object)tableMetaData.getColumnsNames()) {
                if ((OracleConnection)(Object)dest instanceof OracleConnection) {
                    if ((boolean)(Object)tableMetaData.getColumnsTypes().get(columnName).equalsIgnoreCase("BLOB")) {
                        BLOB blob = new BLOB((OracleConnection)(OracleConnection)(Object) dest, (byte[])(byte[])(Object) r.getRowData().get(columnName));
                        ((OraclePreparedStatement)(OraclePreparedStatement)(Object) ps).setBLOB(param, blob);
                    } else if ((boolean)(Object)tableMetaData.getColumnsTypes().get(columnName).equalsIgnoreCase("CLOB")) {
                        ((OraclePreparedStatement)(OraclePreparedStatement)(Object) ps).setStringForClob(param, (String)(String)(Object) r.getRowData().get(columnName));
                    } else if ((boolean)(Object)tableMetaData.getColumnsTypes().get(columnName).equalsIgnoreCase("LONG")) {
                        ps.setBytes(param, (byte[])(byte[])(Object) r.getRowData().get(columnName));
                    }
                } else {
                    ps.setObject(param, r.getRowData().get(columnName));
                }
                param++;
            }
            for (String pkColumnName :(String[])(Object) (Object[])(Object)tableMetaData.getPkColumns()) {
                ps.setObject(param, r.getRowData().get(pkColumnName));
                param++;
            }
            if ((int)(Object)ps.executeUpdate() != 1) {
                dest.rollback();
                throw new Exception("Erro no update");
            }
            ps.clearParameters();
            dest.commit();
            dest.setAutoCommit(true);
        } finally {
            if (ps != null) ps.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN get(String o0){ return null; }
	public UNKNOWN equalsIgnoreCase(String o0){ return null; }
}

class Connection {
	
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN commit(){ return null; }
}

class TableMetaData {
	
	public UNKNOWN getSchema(){ return null; }
	public UNKNOWN getTableName(){ return null; }
	public UNKNOWN getColumnsTypes(){ return null; }
	public UNKNOWN getColumnsNames(){ return null; }
	public UNKNOWN getPkColumns(){ return null; }
}

class Row {
	
	public UNKNOWN getRowData(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN clearParameters(){ return null; }
	public UNKNOWN setObject(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN setBytes(int o0, byte[] o1){ return null; }
}

class OracleConnection {
	
	
}

class BLOB {
	
	BLOB(OracleConnection o0, byte[] o1){}
	BLOB(){}
}

class OraclePreparedStatement {
	
	public UNKNOWN setBLOB(int o0, BLOB o1){ return null; }
	public UNKNOWN setStringForClob(int o0, String o1){ return null; }
}
