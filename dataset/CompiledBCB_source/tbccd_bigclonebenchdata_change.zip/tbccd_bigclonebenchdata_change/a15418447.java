import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15418447 {
    public static boolean isImageLinkReachable(WebImage image)  throws Throwable {
        if (image.getUrl() == null) return false;
        try {
            URL url = new URL((String)(Object)image.getUrl());
            url.openStream().close();
        } catch (MalformedURLException e) {
            return false;
        } catch (IOException e) {
            return false;
        }
        return true;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class WebImage {
	
	public UNKNOWN getUrl(){ return null; }
}
