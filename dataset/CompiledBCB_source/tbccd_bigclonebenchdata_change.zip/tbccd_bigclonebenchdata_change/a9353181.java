import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9353181 {
public UNKNOWN request;
    JSONResponse execute() throws ServerException, RtmApiException, IOException {
        HttpClient httpclient =(HttpClient)(Object) new DefaultHttpClient();
        URI uri;
        try {
            uri = new URI((String)(Object)this.request.getUrl());
            HttpPost httppost = new HttpPost(uri);
            HttpResponse response =(HttpResponse)(Object) httpclient.execute(httppost);
            InputStream is =(InputStream)(Object) response.getEntity().getContent();
            try {
                StringBuilder sb = new StringBuilder();
                BufferedReader r = new BufferedReader(new InputStreamReader((InputStream)(Object)new DoneHandlerInputStream(is)));
                for (String line = r.readLine(); line != null; line = r.readLine()) {
                    sb.append(line);
                }
                return new JSONResponse(sb.toString());
            } finally {
                is.close();
            }
        } catch (URISyntaxException e) {
            throw new RtmApiException(e.getMessage());
        } catch (ArithmeticException e) {
            throw new RtmApiException(e.getMessage());
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getUrl(){ return null; }
	public UNKNOWN getContent(){ return null; }
}

class JSONResponse {
	
	JSONResponse(String o0){}
	JSONResponse(){}
}

class ServerException extends Exception{
	public ServerException(String errorMessage) { super(errorMessage); }
}

class RtmApiException extends Exception{
	public RtmApiException(String errorMessage) { super(errorMessage); }
}

class HttpClient {
	
	public UNKNOWN execute(HttpPost o0){ return null; }
}

class DefaultHttpClient {
	
	
}

class HttpPost {
	
	HttpPost(URI o0){}
	HttpPost(){}
}

class HttpResponse {
	
	public UNKNOWN getEntity(){ return null; }
}

class DoneHandlerInputStream {
	
	DoneHandlerInputStream(InputStream o0){}
	DoneHandlerInputStream(){}
}

class ClientProtocolException extends Exception{
	public ClientProtocolException(String errorMessage) { super(errorMessage); }
}
