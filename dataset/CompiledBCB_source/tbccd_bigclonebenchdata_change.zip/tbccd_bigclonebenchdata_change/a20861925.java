import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20861925 {
public static UNKNOWN LOG;
//public UNKNOWN LOG;
    public static boolean isMatchingAsPassword(final String password, final String amd5Password)  throws Throwable {
        boolean response = false;
        try {
            final MessageDigest algorithm = MessageDigest.getInstance("MD5");
            algorithm.reset();
            algorithm.update(password.getBytes());
            final byte[] md5Byte = algorithm.digest();
            final StringBuffer buffer = new StringBuffer();
            for (final byte b : md5Byte) {
                if ((b <= 15) && (b >= 0)) {
                    buffer.append("0");
                }
                buffer.append(Integer.toHexString(0xFF & b));
            }
            response = (amd5Password != null) && amd5Password.equals(buffer.toString());
        } catch (final NoSuchAlgorithmException e) {
            LOG.error("No digester MD5 found in classpath!", e);
        }
        return response;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0, NoSuchAlgorithmException o1){ return null; }
}
