import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a11149084 {
public UNKNOWN SUNTCP_LIST;
	public UNKNOWN htmlFooter(PrintWriter o0){ return null; }
	public UNKNOWN htmlHeader(PrintWriter o0, String o1, String o2){ return null; }
    private void deleteProject(String uid, String home, HttpServletRequest request, HttpServletResponse response) throws Throwable, Exception {
        String project =(String)(Object) request.getParameter("project");
        String line;
        response.setContentType("text/html");
        PrintWriter out =(PrintWriter)(Object) response.getWriter();
        htmlHeader(out, "Project Status", "");
        try {
            synchronized (Class.forName("com.sun.gep.SunTCP")) {
                Vector list = new Vector();
                String directory = home;
                Runtime.getRuntime().exec("/usr/bin/rm -rf " + directory + project);
                FilePermission perm = new FilePermission(directory + SUNTCP_LIST, "read,write,execute");
                File listfile = new File(directory + SUNTCP_LIST);
                BufferedReader read = new BufferedReader(new FileReader(listfile));
                while ((line = read.readLine()) != null) {
                    if (!((new StringTokenizer(line, "\t")).nextToken().equals(project))) {
                        list.addElement(line);
                    }
                }
                read.close();
                if (list.size() > 0) {
                    PrintWriter write = new PrintWriter(new BufferedWriter(new FileWriter(listfile)));
                    for (int i = 0; i < list.size(); i++) {
                        write.println((String) list.get(i));
                    }
                    write.close();
                } else {
                    listfile.delete();
                }
                out.println("The project was successfully deleted.");
            }
        } catch (Exception e) {
            out.println("Error accessing this project.");
        }
        out.println("<center><form><input type=button value=Continue onClick=\"opener.location.reload(); window.close()\"></form></center>");
        htmlFooter(out);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class HttpServletRequest {
	
	public UNKNOWN getParameter(String o0){ return null; }
}

class HttpServletResponse {
	
	public UNKNOWN getWriter(){ return null; }
	public UNKNOWN setContentType(String o0){ return null; }
}
