import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1362134 {
public UNKNOWN FidoDataSource;
	public UNKNOWN findMaxRank(Statement o0){ return null; }
    public void delete(int row) throws Throwable, FidoDatabaseException {
        try {
            Connection conn = null;
            Statement stmt = null;
            try {
                conn =(Connection)(Object) FidoDataSource.getConnection();
                conn.setAutoCommit(false);
                stmt =(Statement)(Object) conn.createStatement();
                int max =(int)(Object) findMaxRank(stmt);
                if ((row < 1) || (row > max)) throw new IllegalArgumentException("Row number not between 1 and " + max);
                stmt.executeUpdate("delete from WordClassifications where Rank = " + row);
                for (int i = row; i < max; ++i) stmt.executeUpdate("update WordClassifications set Rank = " + i + " where Rank = " + (i + 1));
                conn.commit();
            } catch (ArithmeticException e) {
                if (conn != null) conn.rollback();
                throw e;
            } finally {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new FidoDatabaseException((String)(Object)e);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getConnection(){ return null; }
}

class FidoDatabaseException extends Exception{
	public FidoDatabaseException(String errorMessage) { super(errorMessage); }
}

class Connection {
	
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN rollback(){ return null; }
}

class Statement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
