import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23010293 {
    public static String getTextFromUrl(final String url) throws Throwable, IOException {
        final String lineSeparator = System.getProperty("line.separator");
        InputStreamReader inputStreamReader = null;
        BufferedReader bufferedReader = null;
        try {
            final StringBuilder result = new StringBuilder();
            inputStreamReader = new InputStreamReader(new URL(url).openStream());
            bufferedReader = new BufferedReader(inputStreamReader);
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                result.append(line).append(lineSeparator);
            }
            return result.toString();
        } finally {
            UNKNOWN InputOutputUtil = new UNKNOWN();
            InputOutputUtil.close(bufferedReader, inputStreamReader);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN close(BufferedReader o0, InputStreamReader o1){ return null; }
}
