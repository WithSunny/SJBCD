import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22556550 {
    private void copyFiles(File oldFolder, File newFolder)  throws Throwable {
        for (File fileToCopy : oldFolder.listFiles()) {
            File copiedFile = new File(newFolder.getAbsolutePath() + "\\" + fileToCopy.getName());
            try {
                FileInputStream source = new FileInputStream(fileToCopy);
                FileOutputStream destination = new FileOutputStream(copiedFile);
                FileChannel sourceFileChannel =(FileChannel)(Object) source.getChannel();
                FileChannel destinationFileChannel =(FileChannel)(Object) destination.getChannel();
                long size =(long)(Object) sourceFileChannel.size();
                sourceFileChannel.transferTo(0, size, destinationFileChannel);
                source.close();
                destination.close();
            } catch (Exception exc) {
                exc.printStackTrace();
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, long o1, FileChannel o2){ return null; }
	public UNKNOWN size(){ return null; }
}
