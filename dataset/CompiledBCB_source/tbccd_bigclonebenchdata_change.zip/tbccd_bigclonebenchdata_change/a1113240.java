import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1113240 {
        public RemotePolicyMigrator createRemotePolicyMigrator()  throws Throwable {
            return new RemotePolicyMigrator() {

                public String migratePolicy(InputStream stream, String url) throws ResourceMigrationException, IOException {
                    ByteArrayOutputCreator oc = new ByteArrayOutputCreator();
                    UNKNOWN IOUtils = new UNKNOWN();
                    IOUtils.copyAndClose(stream, oc.getOutputStream());
                    return oc.getOutputStream().toString();
                }
            };
        }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copyAndClose(InputStream o0, UNKNOWN o1){ return null; }
}

class RemotePolicyMigrator {
	
	
}

class ResourceMigrationException extends Exception{
	public ResourceMigrationException(String errorMessage) { super(errorMessage); }
}

class ByteArrayOutputCreator {
	
	public UNKNOWN getOutputStream(){ return null; }
}
