import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15364153 {
public UNKNOWN storeConfiguration(Properties o0, String o1){ return null; }
    private void storeConfigurationPropertiesFile(java.net.URL url, String comp)  throws Throwable {
        java.util.Properties p;
        try {
            p = new java.util.Properties();
            p.load(url.openStream());
        } catch (java.io.IOException ie) {
            System.err.println("error opening: " + url.getPath() + ": " + ie.getMessage());
            return;
        }
        storeConfiguration(p, comp);
        return;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
