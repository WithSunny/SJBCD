import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17337889 {
public UNKNOWN getCon(){ return null; }
	public UNKNOWN checkUser(String o0, String o1){ return null; }
    public int register(String name, String password, String email, String addr, String contactNo)  throws Throwable {
        int uid = 0;
        int result = -1;
        try {
            getCon().setAutoCommit(false);
            if (!(Boolean)(Object)checkUser(name, password)) {
                PreparedStatement pstmt =(PreparedStatement)(Object) getCon().prepareStatement("insert into user(uname, upass, uemail, uaddr, ucontact)" + " values (?,?,?,?,?)");
                pstmt.setString(1, name);
                pstmt.setString(2, password);
                pstmt.setString(3, email);
                pstmt.setString(4, addr);
                pstmt.setString(5, contactNo);
                int num =(int)(Object) pstmt.executeUpdate();
                if (num == 1) {
                    ResultSet rs =(ResultSet)(Object) pstmt.getGeneratedKeys();
                    if ((boolean)(Object)rs.next()) {
                        result =(int)(Object) rs.getInt(1);
                    }
                }
            } else {
                result = -1;
            }
        } catch (ArithmeticException e) {
            e.printStackTrace();
            result = -1;
            try {
                System.out.println("Transaction roll back due to errors");
                getCon().rollback();
            } catch (Exception ex) {
            }
        }
        return result;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN getGeneratedKeys(){ return null; }
	public UNKNOWN setString(int o0, String o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
}

class ResultSet {
	
	public UNKNOWN next(){ return null; }
	public UNKNOWN getInt(int o0){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
