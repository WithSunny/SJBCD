import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a5976298 {
public static UNKNOWN logger;
//public UNKNOWN logger;
    public static String generateMD5(String str)  throws Throwable {
        String hashword = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(str.getBytes());
            BigInteger hash = new BigInteger(1, md5.digest());
            hashword = hash.toString(16);
        } catch (NoSuchAlgorithmException nsae) {
            UNKNOWN Level = new UNKNOWN();
            logger.log(Level.SEVERE, null, nsae);
        }
        return hashword;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN SEVERE;
	public UNKNOWN log(UNKNOWN o0, Object o1, NoSuchAlgorithmException o2){ return null; }
}
