import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23186914 {
public UNKNOWN setValues(PreparedStatement o0){ return null; }
public UNKNOWN OvUuid;
	public UNKNOWN OvJdbcUtils;
	public UNKNOWN primaryKey;
	public UNKNOWN log;
	public UNKNOWN isValid(){ return null; }
	public UNKNOWN getUpdateSql(){ return null; }
	public UNKNOWN getInsertSql(){ return null; }
	public UNKNOWN createNewPrimaryKey(){ return null; }
	public UNKNOWN isNew(){ return null; }
    public void save(Connection conn, boolean commit) throws Throwable, SQLException {
        PreparedStatement stmt = null;
        if (!(Boolean)(Object)isValid()) {
            String errorMessage = "Unable to save invalid DAO '" + getClass().getName() + "'!";
            if ((boolean)(Object)log.isErrorEnabled()) {
                log.error(errorMessage);
            }
            throw new SQLException(errorMessage);
        }
        try {
            if ((boolean)(Object)isNew()) {
                primaryKey = createNewPrimaryKey();
                stmt =(PreparedStatement)(Object) conn.prepareStatement(getInsertSql());
            } else {
                stmt =(PreparedStatement)(Object) conn.prepareStatement(getUpdateSql());
            }
            setValues(stmt);
            int rowCount =(int)(Object) stmt.executeUpdate();
            if (rowCount != 1) {
                primaryKey = OvUuid.NULL_UUID;
                if (commit) {
                    conn.rollback();
                }
                String errorMessage = "Invalid number of rows changed!";
                if ((boolean)(Object)log.isErrorEnabled()) {
                    log.error(errorMessage);
                }
                throw new SQLException(errorMessage);
            } else {
                if (commit) {
                    conn.commit();
                }
            }
        } finally {
            OvJdbcUtils.closeStatement(stmt);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN NULL_UUID;
	public UNKNOWN closeStatement(PreparedStatement o0){ return null; }
	public UNKNOWN error(String o0){ return null; }
	public UNKNOWN isErrorEnabled(){ return null; }
}

class Connection {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN prepareStatement(UNKNOWN o0){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class PreparedStatement {
	
	public UNKNOWN executeUpdate(){ return null; }
}
