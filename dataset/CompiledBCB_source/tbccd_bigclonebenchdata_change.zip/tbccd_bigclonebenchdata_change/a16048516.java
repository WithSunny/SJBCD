import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a16048516 {
    public static SVNConfiguracion load(URL urlConfiguracion)  throws Throwable {
        SVNConfiguracion configuracion = null;
        try {
            XMLDecoder xenc = new XMLDecoder(urlConfiguracion.openStream());
            configuracion = (SVNConfiguracion)(SVNConfiguracion)(Object) xenc.readObject();
            configuracion.setFicheroConfiguracion(urlConfiguracion);
            xenc.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return configuracion;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class SVNConfiguracion {
	
	public UNKNOWN setFicheroConfiguracion(URL o0){ return null; }
}

class XMLDecoder {
	
	XMLDecoder(){}
	XMLDecoder(InputStream o0){}
	public UNKNOWN close(){ return null; }
	public UNKNOWN readObject(){ return null; }
}
