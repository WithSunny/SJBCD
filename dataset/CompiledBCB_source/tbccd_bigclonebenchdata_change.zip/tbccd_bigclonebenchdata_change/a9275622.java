import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9275622 {
    private boolean copyFile(File _file1, File _file2)  throws Throwable {
        FileInputStream fis;
        FileOutputStream fos;
        try {
            fis = new FileInputStream(_file1);
            fos = new FileOutputStream(_file2);
            FileChannel canalFuente =(FileChannel)(Object) fis.getChannel();
            canalFuente.transferTo(0, canalFuente.size(), fos.getChannel());
            fis.close();
            fos.close();
            return true;
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
        }
        return false;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN transferTo(int o0, UNKNOWN o1, java.nio.channels.FileChannel o2){ return null; }
	public UNKNOWN size(){ return null; }
}
