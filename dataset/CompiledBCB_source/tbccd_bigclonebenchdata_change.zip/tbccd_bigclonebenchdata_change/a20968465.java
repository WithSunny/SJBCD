import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20968465 {
    private boolean downloadFile(Proxy proxy, URL url, File file)  throws Throwable {
        try {
            URLConnection conn = null;
            if (null == proxy) {
                conn = url.openConnection();
            } else {
                conn = url.openConnection(proxy);
            }
            conn.connect();
            File destFile = new File(file.getAbsolutePath() + ".update");
            ;
            FileOutputStream fos = new FileOutputStream(destFile);
            byte[] buffer = new byte[2048];
            while (true) {
                int len = conn.getInputStream().read(buffer);
                if (len < 0) {
                    break;
                } else {
                    fos.write(buffer, 0, len);
                }
            }
            fos.close();
            file.delete();
            destFile.renameTo(file);
            return true;
        } catch (Exception e) {
            UNKNOWN logger = new UNKNOWN();
            logger.error("Failed to get remote hosts file.", e);
        }
        return false;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0, Exception o1){ return null; }
}
