import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4697213 {
    protected void downloadJar(URL downloadURL, File jarFile, IProgressListener pl)  throws Throwable {
        BufferedOutputStream out = null;
        InputStream in = null;
        URLConnection urlConnection = null;
        try {
            urlConnection = downloadURL.openConnection();
            out = new BufferedOutputStream(new FileOutputStream(jarFile));
            in = urlConnection.getInputStream();
            int len = in.available();
            UNKNOWN Log = new UNKNOWN();
            Log.log("downloading jar with size: " + urlConnection.getContentLength());
            if (len < 1) len = 1024;
            byte[] buffer = new byte[len];
            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }
            out.close();
            in.close();
        } catch (Exception e) {
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException ignore) {
                }
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignore) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN log(String o0){ return null; }
}

class IProgressListener {
	
	
}
