import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22899260 {
public static UNKNOWN logger;
	public static UNKNOWN byteArrayToString(byte[] o0){ return null; }
//public UNKNOWN logger;
//	public UNKNOWN byteArrayToString(byte[] o0){ return null; }
    public static String sha1Hash(String input)  throws Throwable {
        try {
            MessageDigest sha1Digest = MessageDigest.getInstance("SHA-1");
            sha1Digest.update(input.getBytes());
            return(String)(Object) byteArrayToString(sha1Digest.digest());
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        return "";
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0, Exception o1){ return null; }
}
