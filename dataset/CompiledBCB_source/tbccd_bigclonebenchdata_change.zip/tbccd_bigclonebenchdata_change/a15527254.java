import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15527254 {
public UNKNOWN executeRequest(GetPageRequest o0){ return null; }
public UNKNOWN getHttpClient(){ return null; }
    protected String parseAction() throws Throwable, ChangesOnServerException, ConnectionException, RequestCancelledException {
        GetPageRequest request =(GetPageRequest)(Object) getHttpClient().createGetPageRequest();
        request.setUrl("http://www.zippyshare.com/index_old.jsp");
        HttpResponse response =(HttpResponse)(Object) executeRequest(request);
        try {
            Parser p = new Parser(response.getResponseBody());
            String action =(String)(Object) p.parseOne("enctype=\"multipart/form-data\" action=\"(.*)\">");
            return action;
        } catch (ArithmeticException ex) {
            throw new ChangesOnServerException();
        } catch (ArrayIndexOutOfBoundsException ex) {
            throw new ChangesOnServerException();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN createGetPageRequest(){ return null; }
}

class ChangesOnServerException extends Exception{
	public ChangesOnServerException(String errorMessage) { super(errorMessage); }
	ChangesOnServerException(){}
}

class ConnectionException extends Exception{
	public ConnectionException(String errorMessage) { super(errorMessage); }
}

class RequestCancelledException extends Exception{
	public RequestCancelledException(String errorMessage) { super(errorMessage); }
}

class GetPageRequest {
	
	public UNKNOWN setUrl(String o0){ return null; }
}

class HttpResponse {
	
	public UNKNOWN getResponseBody(){ return null; }
}

class Parser {
	
	Parser(UNKNOWN o0){}
	Parser(){}
	public UNKNOWN parseOne(String o0){ return null; }
}

class ParsingException extends Exception{
	public ParsingException(String errorMessage) { super(errorMessage); }
}
