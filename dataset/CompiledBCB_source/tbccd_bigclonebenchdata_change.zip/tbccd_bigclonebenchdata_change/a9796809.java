import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9796809 {
public UNKNOWN lastException;
	public UNKNOWN bufferFileData(){ return null; }
//    @Override
    protected byte[] computeHash()  throws Throwable {
        try {
            final MessageDigest inputHash = MessageDigest.getInstance("SHA");
            inputHash.update((byte)(Object)bufferFileData().getBytes());
            return inputHash.digest();
        } catch (final NoSuchAlgorithmException nsae) {
            lastException =(UNKNOWN)(Object) nsae;
            return new byte[0];
        } catch (final ArithmeticException ioe) {
            lastException =(UNKNOWN)(Object) ioe;
            return new byte[0];
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getBytes(){ return null; }
}
