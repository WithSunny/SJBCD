import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12482760 {
public UNKNOWN formatFTPReplyString(UNKNOWN o0){ return null; }
public UNKNOWN protocol;
	public UNKNOWN protection;
	public UNKNOWN impliciteSec;
	public UNKNOWN Util;
	public UNKNOWN debug(String o0, UNKNOWN o1){ return null; }
	public UNKNOWN debug(String o0, String o1){ return null; }
public UNKNOWN client;
	public UNKNOWN remoteServer;
	public UNKNOWN connectionId;
	public UNKNOWN FTP;
	public UNKNOWN Logger;
	public UNKNOWN passivMode;
	public UNKNOWN controlEncoding;
	public UNKNOWN FTPReply;
	public UNKNOWN login;
	public UNKNOWN password;
	public UNKNOWN remotePort;
	public UNKNOWN disconnect(){ return null; }
	public UNKNOWN clearCache(){ return null; }
	public UNKNOWN resetClient(SocketException o0){ return null; }
	public UNKNOWN debug(String o0){ return null; }
	public UNKNOWN updateOpTime(){ return null; }
	public UNKNOWN resetClient(IOException o0){ return null; }
	public UNKNOWN isSecured(){ return null; }
	public UNKNOWN resetClient(UnknownHostException o0){ return null; }
	public UNKNOWN checkLocked(){ return null; }
    public synchronized void connect() throws Throwable, FTPConnectionException {
        checkLocked();
        try {
            int reply;
            this.disconnect();
            if ((boolean)(Object)isSecured()) {
                this.client =(UNKNOWN)(Object) new FTPSClient(protocol, protection, impliciteSec, null, null);
            } else {
                this.client =(UNKNOWN)(Object) new FTPClient();
            }
            if (this.controlEncoding != null) {
                this.client.setControlEncoding(this.controlEncoding);
                debug("control encoding : ", controlEncoding);
            }
            Logger.defaultLogger().info("Trying to connect to server : " + this.remoteServer + " ...");
            debug("connect : connect", remoteServer);
            client.connect(remoteServer, this.remotePort);
            Logger.defaultLogger().info("Received FTP server response : " + formatFTPReplyString(client.getReplyString()));
            this.connectionId = Util.getRndLong();
            reply =(int)(Object) client.getReplyCode();
            if (!(Boolean)(Object)FTPReply.isPositiveCompletion(reply)) {
                String msg =(String)(Object) formatFTPReplyString(client.getReplyString());
                this.disconnect();
                throw new FTPConnectionException("Unable to communicate with remote FTP server. Got message : " + msg);
            } else {
                Logger.defaultLogger().info("Trying to log in with user : " + this.login + " ...");
                debug("connect : login", login + "/" + password);
                if (!(Boolean)(Object)client.login(this.login, this.password)) {
                    String msg =(String)(Object) formatFTPReplyString(client.getReplyString());
                    this.disconnect();
                    throw new FTPConnectionException("Unable to login on FTP server (" + login + "/" + password + "). Received response : " + msg);
                } else {
                    Logger.defaultLogger().info("Logged in with user : " + this.login + ". Received response : " + formatFTPReplyString(client.getReplyString()));
                    if ((boolean)(Object)this.passivMode) {
                        Logger.defaultLogger().info("Switching to passive mode ...");
                        debug("connect : pasv");
                        client.enterLocalPassiveMode();
                        reply =(int)(Object) client.getReplyCode();
                        if (!(Boolean)(Object)FTPReply.isPositiveCompletion(reply)) {
                            String msg =(String)(Object) formatFTPReplyString(client.getReplyString());
                            this.disconnect();
                            throw new FTPConnectionException("Unable to switch to passiv mode. Received response : " + msg);
                        } else {
                            this.updateOpTime();
                        }
                    } else {
                        this.updateOpTime();
                    }
                    debug("connect : bin");
                    client.setFileType(FTP.BINARY_FILE_TYPE);
                    Logger.defaultLogger().info("Connected to server : " + this.remoteServer);
                }
            }
        } catch (ArithmeticException e) {
            resetClient((SocketException)(Object)e);
            throw new FTPConnectionException("Unknown FTP server : " + this.remoteServer);
        } catch (ArrayIndexOutOfBoundsException e) {
            resetClient((SocketException)(Object)e);
            throw new FTPConnectionException("Error during FTP connection : " + e.getMessage());
        } catch (ArrayStoreException e) {
            resetClient((SocketException)(Object)e);
            throw new FTPConnectionException("Error during FTP connection : " + e.getMessage());
        } finally {
            clearCache();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN BINARY_FILE_TYPE;
	public UNKNOWN isPositiveCompletion(int o0){ return null; }
	public UNKNOWN connect(UNKNOWN o0, UNKNOWN o1){ return null; }
	public UNKNOWN defaultLogger(){ return null; }
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN setControlEncoding(UNKNOWN o0){ return null; }
	public UNKNOWN getReplyString(){ return null; }
	public UNKNOWN getRndLong(){ return null; }
	public UNKNOWN getReplyCode(){ return null; }
	public UNKNOWN login(UNKNOWN o0, UNKNOWN o1){ return null; }
	public UNKNOWN setFileType(UNKNOWN o0){ return null; }
	public UNKNOWN enterLocalPassiveMode(){ return null; }
}

class FTPConnectionException extends Exception{
	public FTPConnectionException(String errorMessage) { super(errorMessage); }
}

class FTPSClient {
	
	FTPSClient(UNKNOWN o0, UNKNOWN o1, UNKNOWN o2, Object o3, Object o4){}
	FTPSClient(){}
}

class FTPClient {
	
	
}
