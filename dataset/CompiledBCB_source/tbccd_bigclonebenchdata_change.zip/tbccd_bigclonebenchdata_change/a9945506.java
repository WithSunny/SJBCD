import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a9945506 {
    public synchronized String decrypt(String plaintext) throws Throwable, Exception {
        MessageDigest md = null;
        String strhash = new String((String)(Object)(new BASE64Decoder()).decodeBuffer(plaintext));
        System.out.println("strhash1122  " + strhash);
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            e.printStackTrace();
        }
        byte raw[] = md.digest();
        try {
            md.update(new String(raw).getBytes("UTF-8"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("plain text  " + strhash);
        String strcode = new String(raw);
        System.out.println("strcode.." + strcode);
        return strcode;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class BASE64Decoder {
	
	public UNKNOWN decodeBuffer(String o0){ return null; }
}
