import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a15759378 {
    public static String email_get_public_hash(String email)  throws Throwable {
        try {
            if (email != null) {
                email = email.trim().toLowerCase();
                CRC32 crc32 = new CRC32();
                crc32.reset();
                crc32.update(email.getBytes());
                MessageDigest md5 = MessageDigest.getInstance("MD5");
                md5.reset();
                return crc32.getValue() + " " + new String(md5.digest(email.getBytes()));
            }
        } catch (Exception e) {
        }
        return "";
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class CRC32 {
	
	public UNKNOWN update(byte[] o0){ return null; }
	public UNKNOWN getValue(){ return null; }
	public UNKNOWN reset(){ return null; }
}
