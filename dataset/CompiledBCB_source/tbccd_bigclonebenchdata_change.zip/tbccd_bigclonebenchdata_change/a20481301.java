import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20481301 {
public static UNKNOWN m_URLImageMap;
	public static UNKNOWN getImage(InputStream o0){ return null; }
	public static UNKNOWN getPluginImageURL(Object o0, String o1){ return null; }
//public UNKNOWN m_URLImageMap;
//	public UNKNOWN getImage(InputStream o0){ return null; }
//	public UNKNOWN getPluginImageURL(Object o0, String o1){ return null; }
    public static Image getPluginImage(final Object plugin, final String name)  throws Throwable {
        try {
            try {
                URL url =(URL)(Object) getPluginImageURL(plugin, name);
                if ((boolean)(Object)m_URLImageMap.containsKey(url)) return(Image)(Object) m_URLImageMap.get(url);
                InputStream is = url.openStream();
                Image image;
                try {
                    image =(Image)(Object) getImage(is);
                    m_URLImageMap.put(url, image);
                } finally {
                    is.close();
                }
                return image;
            } catch (Throwable e) {
            }
        } catch (Throwable e) {
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN get(URL o0){ return null; }
	public UNKNOWN put(URL o0, Image o1){ return null; }
	public UNKNOWN containsKey(URL o0){ return null; }
}

class Image {
	
	
}
