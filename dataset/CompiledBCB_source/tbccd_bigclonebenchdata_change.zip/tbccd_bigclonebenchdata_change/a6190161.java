import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a6190161 {
    public void xtest2() throws Throwable, Exception {
        InputStream input1 = new FileInputStream("C:/Documentos/j931_01.pdf");
        InputStream input2 = new FileInputStream("C:/Documentos/j931_02.pdf");
        InputStream tmp = (InputStream)(Object)new ITextManager().merge(new InputStream[] { input1, input2 });
        FileOutputStream output = new FileOutputStream("C:/temp/split.pdf");
        UNKNOWN IOUtils = new UNKNOWN();
        IOUtils.copy(tmp, output);
        input1.close();
        input2.close();
        tmp.close();
        output.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(InputStream o0, FileOutputStream o1){ return null; }
}

class ITextManager {
	
	public UNKNOWN merge(InputStream[] o0){ return null; }
}
