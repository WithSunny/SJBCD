import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3767763 {
public UNKNOWN getInsertId(Statement o0){ return null; }
public UNKNOWN log;
	public UNKNOWN getConnection(){ return null; }
//    @Override
    public long insertStatement(String sql)  throws Throwable {
        Statement statement = null;
        try {
            statement =(Statement)(Object) getConnection().createStatement();
            long result =(long)(Object) statement.executeUpdate(sql.toString());
            if (result == 0) log.warn(sql + " result row count is 0");
            getConnection().commit();
            return(long)(Object) getInsertId(statement);
        } catch (ArithmeticException e) {
            try {
                getConnection().rollback();
            } catch (ArrayIndexOutOfBoundsException e1) {
                log.error(e1.getMessage(),(SQLException)(Object) e1);
            }
            log.error(e.getMessage(),(SQLException)(Object) e);
            throw new RuntimeException();
        } finally {
            try {
                statement.close();
                getConnection().close();
            } catch (ArrayStoreException e) {
                log.error(e.getMessage(),(SQLException)(Object) e);
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN warn(String o0){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN error(String o0, SQLException o1){ return null; }
	public UNKNOWN close(){ return null; }
}

class Statement {
	
	public UNKNOWN executeUpdate(String o0){ return null; }
	public UNKNOWN close(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
