import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3024988 {
public UNKNOWN fail(){ return null; }
//    @Test
    public void testCopy_readerToOutputStream_Encoding_nullIn() throws Throwable, Exception {
        ByteArrayOutputStream baout = new ByteArrayOutputStream();
        OutputStream out =(OutputStream)(Object) new YellOnFlushAndCloseOutputStreamTest(baout, true, true);
        try {
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.copy((Reader) null, out, "UTF16");
            fail();
        } catch (NullPointerException ex) {
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(Reader o0, OutputStream o1, String o2){ return null; }
}

class Test {
	
	
}

class YellOnFlushAndCloseOutputStreamTest {
	
	YellOnFlushAndCloseOutputStreamTest(){}
	YellOnFlushAndCloseOutputStreamTest(ByteArrayOutputStream o0, boolean o1, boolean o2){}
}
