import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a3635291 {
public static UNKNOWN convertToHex(byte[] o0){ return null; }
//public UNKNOWN convertToHex(byte[] o0){ return null; }
    public static String getSHA1Digest(String inputStr) throws Throwable, NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = null;
        byte[] sha1hash = null;
        md = MessageDigest.getInstance("SHA");
        sha1hash = new byte[40];
        md.update(inputStr.getBytes("iso-8859-1"), 0, inputStr.length());
        sha1hash = md.digest();
        return(String)(Object) convertToHex(sha1hash);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
