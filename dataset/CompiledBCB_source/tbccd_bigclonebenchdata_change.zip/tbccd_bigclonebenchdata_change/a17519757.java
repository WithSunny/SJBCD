import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17519757 {
    public static InputStream download(String endereco, ProxyConfig proxy)  throws Throwable {
        if (proxy != null) {
            System.getProperties().put("proxySet", "true");
            System.getProperties().put("proxyPort", proxy.getPorta());
            System.getProperties().put("proxyHost", proxy.getHost());
            Authenticator.setDefault((Authenticator)(Object)new ProxyAuthenticator(proxy.getUsuario(), proxy.getSenha()));
        }
        try {
            URL url = new URL(endereco);
            ;
            URLConnection connection = url.openConnection();
            InputStream bis = new BufferedInputStream(connection.getInputStream());
            return bis;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ProxyConfig {
	
	public UNKNOWN getPorta(){ return null; }
	public UNKNOWN getUsuario(){ return null; }
	public UNKNOWN getSenha(){ return null; }
	public UNKNOWN getHost(){ return null; }
}

class ProxyAuthenticator {
	
	ProxyAuthenticator(UNKNOWN o0, UNKNOWN o1){}
	ProxyAuthenticator(){}
}
