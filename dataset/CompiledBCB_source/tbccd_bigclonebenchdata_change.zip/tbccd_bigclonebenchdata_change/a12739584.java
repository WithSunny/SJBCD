import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12739584 {
public UNKNOWN assertNotNull(ResultSet o0){ return null; }
public UNKNOWN getConnection(){ return null; }
	public UNKNOWN assertTrue(boolean o0){ return null; }
	public UNKNOWN dropTable(String o0){ return null; }
    public void testTransactions0010() throws Throwable, Exception {
        Connection cx =(Connection)(Object) getConnection();
        dropTable("#t0010");
        Statement stmt =(Statement)(Object) cx.createStatement();
        stmt.executeUpdate("create table #t0010 " + "  (i  integer  not null,      " + "   s  char(10) not null)      ");
        cx.setAutoCommit(false);
        PreparedStatement pStmt =(PreparedStatement)(Object) cx.prepareStatement("insert into #t0010 values (?, ?)");
        int rowsToAdd = 8;
        final String theString = "abcdefghijklmnopqrstuvwxyz";
        int count = 0;
        for (int i = 1; i <= rowsToAdd; i++) {
            pStmt.setInt(1, i);
            pStmt.setString(2, theString.substring(0, i));
            count += (int)(Object)pStmt.executeUpdate();
        }
        assertTrue(count == rowsToAdd);
        cx.rollback();
        stmt =(Statement)(Object) cx.createStatement();
        ResultSet rs =(ResultSet)(Object) stmt.executeQuery("select s, i from #t0010");
        assertNotNull(rs);
        count = 0;
        while ((boolean)(Object)rs.next()) {
            count++;
            assertTrue(rs.getString(1).trim().length() == rs.getInt(2));
        }
        assertTrue(count == 0);
        cx.commit();
        rowsToAdd = 6;
        for (int j = 1; j <= 2; j++) {
            count = 0;
            for (int i = 1; i <= rowsToAdd; i++) {
                pStmt.setInt(1, i + ((j - 1) * rowsToAdd));
                pStmt.setString(2, theString.substring(0, i));
                count += (int)(Object)pStmt.executeUpdate();
            }
            assertTrue(count == rowsToAdd);
            cx.commit();
        }
        rs =(ResultSet)(Object) stmt.executeQuery("select s, i from #t0010");
        count = 0;
        while ((boolean)(Object)rs.next()) {
            count++;
            int i =(int)(Object) rs.getInt(2);
            if (i > rowsToAdd) i -= rowsToAdd;
            assertTrue((int)(Object)rs.getString(1).trim().length() == i);
        }
        assertTrue(count == (2 * rowsToAdd));
        cx.commit();
        cx.setAutoCommit(true);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN length(){ return null; }
	public UNKNOWN trim(){ return null; }
}

class Connection {
	
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
}

class Statement {
	
	public UNKNOWN executeQuery(String o0){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN setString(int o0, String o1){ return null; }
	public UNKNOWN setInt(int o0, int o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
}

class ResultSet {
	
	public UNKNOWN next(){ return null; }
	public UNKNOWN getString(int o0){ return null; }
	public UNKNOWN getInt(int o0){ return null; }
}
