import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1141361 {
public UNKNOWN m_connection;
	public UNKNOWN ensureConnection(){ return null; }
//    @Override
    public void makeRead(final String user, final long databaseID, final long time) throws Throwable, SQLException {
        final String query = "insert into fs.read_post (post, user, read_date) values (?, ?, ?)";
        ensureConnection();
        final PreparedStatement statement =(PreparedStatement)(Object) m_connection.prepareStatement(query);
        try {
            statement.setLong(1, databaseID);
            statement.setString(2, user);
            statement.setTimestamp(3, new Timestamp(time));
            final int count =(int)(Object) statement.executeUpdate();
            if (0 == count) {
                throw new SQLException("Nothing updated.");
            }
            m_connection.commit();
        } catch (final SQLException e) {
            m_connection.rollback();
            throw e;
        } finally {
            statement.close();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN commit(){ return null; }
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN rollback(){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class PreparedStatement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN setString(int o0, String o1){ return null; }
	public UNKNOWN setTimestamp(int o0, Timestamp o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN setLong(int o0, long o1){ return null; }
}

class Timestamp {
	
	Timestamp(long o0){}
	Timestamp(){}
}
