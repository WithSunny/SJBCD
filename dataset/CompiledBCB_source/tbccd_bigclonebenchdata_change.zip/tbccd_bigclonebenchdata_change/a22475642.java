import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22475642 {
    void getAddress(String lat, String lag) {
        try {
            URL url = new URL("http://maps.google.cn/maps/geo?key=abcdefg&q=" + lat + "," + lag);
            InputStream inputStream = url.openConnection().getInputStream();
            InputStreamReader inputReader = new InputStreamReader(inputStream, "utf-8");
            BufferedReader bufReader = new BufferedReader(inputReader);
            String line = "", lines = "";
            while ((line = bufReader.readLine()) != null) {
                lines += line;
            }
            if (!lines.equals("")) {
                JSONObject jsonobject = new JSONObject(lines);
                JSONArray jsonArray = new JSONArray(jsonobject.get("Placemark").toString());
                for (int i = 0; i < (int)(Object)jsonArray.length(); i++) {
                    UNKNOWN mTextView = new UNKNOWN();
                    mTextView.setText(mTextView.getText() + "\n" + jsonArray.getJSONObject(i).getString("address"));
                }
            }
        } catch (Exception e) {
            ;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getString(String o0){ return null; }
	public UNKNOWN setText(String o0){ return null; }
	public UNKNOWN getText(){ return null; }
}

class JSONObject {
	
	JSONObject(String o0){}
	JSONObject(){}
	public UNKNOWN get(String o0){ return null; }
}

class JSONArray {
	
	JSONArray(){}
	JSONArray(String o0){}
	public UNKNOWN length(){ return null; }
	public UNKNOWN getJSONObject(int o0){ return null; }
}
