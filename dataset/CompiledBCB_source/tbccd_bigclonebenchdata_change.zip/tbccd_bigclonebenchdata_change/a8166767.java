import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8166767 {
public UNKNOWN discoverServiceUrl(UNKNOWN o0){ return null; }
public UNKNOWN HttpClientUtils;
	public UNKNOWN log;
	public UNKNOWN JsonUtils;
	public UNKNOWN urlFromDiscovery;
	public UNKNOWN setServiceUrl(String o0){ return null; }
	public UNKNOWN getServiceInterface(){ return null; }
	public UNKNOWN getServiceUrl(){ return null; }
    public Object invoke(MethodInvocation invocation, int retryTimes) throws Throwable {
        retryTimes--;
        try {
            String url = getServiceUrl() + "/" + invocation.getMethod().getName();
            HttpPost postMethod = new HttpPost(url);
            if ((int)(Object)invocation.getMethod().getParameterTypes().length > 0) postMethod.setEntity(new StringEntity(JsonUtils.toJson(invocation.getArguments())));
            HttpResponse rsp =(HttpResponse)(Object) HttpClientUtils.getDefaultInstance().execute(postMethod);
            StatusLine sl =(StatusLine)(Object) rsp.getStatusLine();
            if ((int)(Object)sl.getStatusCode() >= 300) {
                throw new RuntimeException("Did not receive successful HTTP response: status code = " + sl.getStatusCode() + ", status message = [" + sl.getReasonPhrase() + "]");
            }
            HttpEntity entity =(HttpEntity)(Object) rsp.getEntity();
            StringBuilder sb = new StringBuilder();
            InputStream is =(InputStream)(Object) entity.getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf-8"));
            String line;
            while ((line = reader.readLine()) != null) sb.append(line).append("\n");
            reader.close();
            is.close();
            String responseBody = null;
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
                responseBody = sb.toString();
            }
            Type t =(Type)(Object) invocation.getMethod().getGenericReturnType();
            if (t.equals(Void.class) || responseBody == null) return null;
            return JsonUtils.fromJson(responseBody, t);
        } catch (ArithmeticException e) {
            if (retryTimes < 0) throw e;
            if ((boolean)(Object)urlFromDiscovery) {
                String serviceUrl =(String)(Object) discoverServiceUrl(getServiceInterface().getName());
                if (!serviceUrl.equals(getServiceUrl())) {
                    setServiceUrl(serviceUrl);
                    log.info("relocate service url:" + serviceUrl);
                }
            }
            return invoke(invocation, retryTimes);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN length;
	public UNKNOWN fromJson(String o0, Type o1){ return null; }
	public UNKNOWN execute(HttpPost o0){ return null; }
	public UNKNOWN getDefaultInstance(){ return null; }
	public UNKNOWN toJson(UNKNOWN o0){ return null; }
	public UNKNOWN getParameterTypes(){ return null; }
	public UNKNOWN getGenericReturnType(){ return null; }
	public UNKNOWN info(String o0){ return null; }
	public UNKNOWN getName(){ return null; }
}

class MethodInvocation {
	
	public UNKNOWN getMethod(){ return null; }
	public UNKNOWN getArguments(){ return null; }
}

class HttpPost {
	
	HttpPost(){}
	HttpPost(String o0){}
	public UNKNOWN setEntity(StringEntity o0){ return null; }
}

class StringEntity {
	
	StringEntity(){}
	StringEntity(UNKNOWN o0){}
}

class HttpResponse {
	
	public UNKNOWN getStatusLine(){ return null; }
	public UNKNOWN getEntity(){ return null; }
}

class StatusLine {
	
	public UNKNOWN getStatusCode(){ return null; }
	public UNKNOWN getReasonPhrase(){ return null; }
}

class HttpEntity {
	
	public UNKNOWN getContent(){ return null; }
}

class Type {
	
	
}

class ConnectTimeoutException extends Exception{
	public ConnectTimeoutException(String errorMessage) { super(errorMessage); }
}
