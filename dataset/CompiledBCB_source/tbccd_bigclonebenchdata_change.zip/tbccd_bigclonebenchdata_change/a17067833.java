import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17067833 {
    private void copyResourceToDir(String ondexDir, String resource)  throws Throwable {
        InputStream inputStream = OndexGraphImpl.class.getClassLoader().getResourceAsStream(resource);
        try {
            FileWriter fileWriter = new FileWriter(new File(ondexDir, resource));
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.copy(inputStream, fileWriter);
            fileWriter.flush();
            fileWriter.close();
        } catch (IOException e) {
            UNKNOWN logger = new UNKNOWN();
            logger.error("Unable to copy '" + resource + "' file to " + ondexDir + "'");
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN copy(InputStream o0, FileWriter o1){ return null; }
	public UNKNOWN error(String o0){ return null; }
}

class OndexGraphImpl {
	
	
}
