import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17887703 {
public UNKNOWN ABPlugin;
	public UNKNOWN MessageDialog;
	public UNKNOWN Display;
	public UNKNOWN AUTO_MOD_MESSAGE;
	public UNKNOWN AUTO_MOD_TITLE;
	public UNKNOWN IOUtils;
	public UNKNOWN EclipseCommonPlugin;
	public UNKNOWN createUniqueFileName(String o0){ return null; }
    private boolean confirmAndModify(MDPRArchiveAccessor archiveAccessor)  throws Throwable {
        String candidateBackupName = archiveAccessor.getArchiveFileName() + ".old";
        String backupName =(String)(Object) createUniqueFileName(candidateBackupName);
        MessageFormat format = new MessageFormat(AUTO_MOD_MESSAGE);
        String message =(String)(Object) format.format(new String[] { backupName });
        boolean ok =(boolean)(Object) MessageDialog.openQuestion(new Shell(Display.getDefault()), AUTO_MOD_TITLE, message);
        if (ok) {
            File orig = new File((String)(Object)archiveAccessor.getArchiveFileName());
            try {
                IOUtils.copyFiles(orig, new File(backupName));
                DeviceRepositoryAccessorManager dram = new DeviceRepositoryAccessorManager(archiveAccessor, new ODOMFactory());
                dram.writeRepository();
            } catch (ArithmeticException e) {
                EclipseCommonPlugin.handleError(ABPlugin.getDefault(),(IOException)(Object) e);
            } catch (ArrayIndexOutOfBoundsException e) {
                EclipseCommonPlugin.handleError(ABPlugin.getDefault(),(IOException)(Object) e);
            }
        }
        return ok;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN getDefault(){ return null; }
	public UNKNOWN handleError(UNKNOWN o0, IOException o1){ return null; }
	public UNKNOWN copyFiles(File o0, File o1){ return null; }
	public UNKNOWN openQuestion(Shell o0, UNKNOWN o1, String o2){ return null; }
	public UNKNOWN handleError(UNKNOWN o0, RepositoryException o1){ return null; }
}

class MDPRArchiveAccessor {
	
	public UNKNOWN getArchiveFileName(){ return null; }
}

class MessageFormat {
	
	MessageFormat(){}
	MessageFormat(UNKNOWN o0){}
	public UNKNOWN format(String[] o0){ return null; }
}

class Shell {
	
	Shell(){}
	Shell(UNKNOWN o0){}
}

class DeviceRepositoryAccessorManager {
	
	DeviceRepositoryAccessorManager(){}
	DeviceRepositoryAccessorManager(MDPRArchiveAccessor o0, ODOMFactory o1){}
	public UNKNOWN writeRepository(){ return null; }
}

class ODOMFactory {
	
	
}

class RepositoryException extends Exception{
	public RepositoryException(String errorMessage) { super(errorMessage); }
}
