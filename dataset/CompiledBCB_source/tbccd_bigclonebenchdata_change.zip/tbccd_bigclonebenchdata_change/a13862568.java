import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13862568 {
    private String getShaderIncludeSource(String path) throws Exception {
        URL url = this.getClass().getResource(path);
        BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
        boolean run = true;
        String str;
        String ret = new String();
        while (run) {
            str = in.readLine();
            if (str != null) ret += str + "\n"; else run = false;
        }
        in.close();
        return ret;
    }
}