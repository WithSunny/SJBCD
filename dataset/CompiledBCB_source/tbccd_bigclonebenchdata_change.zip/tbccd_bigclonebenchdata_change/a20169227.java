import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20169227 {
public UNKNOWN INSERT_USER_STATEMENT;
	public UNKNOWN USER_CURR_VALUE;
	public UNKNOWN UPDATE_USER_STATEMENT;
	public UNKNOWN LOGGER;
	public UNKNOWN getConnection(){ return null; }
	public UNKNOWN closeConnection(){ return null; }
//    @Override
    public String addUser(UserInfoItem user) throws Throwable, DatabaseException {
        if (user == null) throw new NullPointerException("user");
        if (user.getSurname() == null || "".equals(user.getSurname())) throw new NullPointerException("user.getSurname()");
        try {
            getConnection().setAutoCommit(false);
        } catch (ArithmeticException e) {
            LOGGER.warn("Unable to set autocommit off",(SQLException)(Object) e);
        }
        String retID = "exist";
        PreparedStatement insSt = null, updSt = null, seqSt = null;
        try {
            int modified = 0;
            if (user.getId() != null) {
                long id = Long.parseLong((String)(Object)user.getId());
                updSt =(PreparedStatement)(Object) getConnection().prepareStatement(UPDATE_USER_STATEMENT);
                updSt.setString(1, user.getName());
                updSt.setString(2, user.getSurname());
                updSt.setLong(3, id);
                modified =(int)(Object) updSt.executeUpdate();
            } else {
                insSt =(PreparedStatement)(Object) getConnection().prepareStatement(INSERT_USER_STATEMENT);
                insSt.setString(1, user.getName());
                insSt.setString(2, user.getSurname());
                insSt.setBoolean(3, "m".equalsIgnoreCase((String)(Object)user.getSex()));
                modified =(int)(Object) insSt.executeUpdate();
                seqSt =(PreparedStatement)(Object) getConnection().prepareStatement(USER_CURR_VALUE);
                ResultSet rs =(ResultSet)(Object) seqSt.executeQuery();
                while ((boolean)(Object)rs.next()) {
                    retID =(String)(Object) rs.getString(1);
                }
            }
            if (modified == 1) {
                getConnection().commit();
                LOGGER.debug("DB has been updated. Queries: \"" + seqSt + "\" and \"" + (user.getId() != null ? updSt : insSt) + "\"");
            } else {
                getConnection().rollback();
                LOGGER.debug("DB has not been updated. -> rollback! Queries: \"" + seqSt + "\" and \"" + (user.getId() != null ? updSt : insSt) + "\"");
                retID = "error";
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            LOGGER.error((SQLException)(Object)e);
            retID = "error";
        } finally {
            closeConnection();
        }
        return retID;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN error(SQLException o0){ return null; }
	public UNKNOWN commit(){ return null; }
	public UNKNOWN debug(String o0){ return null; }
	public UNKNOWN prepareStatement(UNKNOWN o0){ return null; }
	public UNKNOWN warn(String o0, SQLException o1){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
}

class UserInfoItem {
	
	public UNKNOWN getName(){ return null; }
	public UNKNOWN getSex(){ return null; }
	public UNKNOWN getSurname(){ return null; }
	public UNKNOWN getId(){ return null; }
}

class DatabaseException extends Exception{
	public DatabaseException(String errorMessage) { super(errorMessage); }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}

class PreparedStatement {
	
	public UNKNOWN setLong(int o0, long o1){ return null; }
	public UNKNOWN setBoolean(int o0, boolean o1){ return null; }
	public UNKNOWN setString(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
	public UNKNOWN executeQuery(){ return null; }
}

class ResultSet {
	
	public UNKNOWN next(){ return null; }
	public UNKNOWN getString(int o0){ return null; }
}
