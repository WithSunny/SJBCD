import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8288993 {
    private SecretKey getSecretKey()  throws Throwable {
        try {
            String path = "/org.dbreplicator/repconsole/secretKey.obj";
            java.net.URL url1 = getClass().getResource(path);
            ObjectInputStream ois = new ObjectInputStream(new BufferedInputStream(url1.openStream()));
            SecretKey sk = (SecretKey) ois.readObject();
            return sk;
        } catch (IOException ex) {
        } catch (ClassNotFoundException ex) {
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class SecretKey {
	
	
}
