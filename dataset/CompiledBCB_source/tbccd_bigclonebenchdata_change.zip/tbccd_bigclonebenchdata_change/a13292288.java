import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13292288 {
    private static void doCopyFile(File srcFile, File destFile, boolean preserveFileDate) throws Throwable, IOException {
        if (destFile.exists() && destFile.isDirectory()) {
            throw new IOException("Destination '" + destFile + "' exists but is a directory");
        }
        FileInputStream input = new FileInputStream(srcFile);
        try {
            FileOutputStream output = new FileOutputStream(destFile);
            try {
                UNKNOWN IOUtils = new UNKNOWN();
                IOUtils.copy(input, output);
            } finally {
                UNKNOWN IOUtils = new UNKNOWN();
                IOUtils.closeQuietly(output);
            }
        } finally {
            UNKNOWN IOUtils = new UNKNOWN();
            IOUtils.closeQuietly(input);
        }
        if (srcFile.length() != destFile.length()) {
            throw new IOException("Failed to copy full contents from '" + srcFile + "' to '" + destFile + "'");
        }
        if (preserveFileDate) {
            destFile.setLastModified(srcFile.lastModified());
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN closeQuietly(FileOutputStream o0){ return null; }
	public UNKNOWN copy(FileInputStream o0, FileOutputStream o1){ return null; }
	public UNKNOWN closeQuietly(FileInputStream o0){ return null; }
}
