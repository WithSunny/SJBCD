import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23498321 {
    static final void saveModule(Module module, DBConnector connector) throws IOException {
        String type = "pre";
        if ((boolean)(Object)module.isPreModule()) type = "pre"; else if ((boolean)(Object)module.isPostModule()) type = "post"; else if ((boolean)(Object)module.isExceptionModule()) type = "exception"; else throw new IllegalArgumentException("Module must be of a known type.");
        Properties props =(Properties)(Object) module.getState();
        Connection con = null;
        PreparedStatement ps = null;
        Statement st = null;
        try {
            con =(Connection)(Object) connector.getDB();
            con.setAutoCommit(false);
            st =(Statement)(Object) con.createStatement();
            st.executeUpdate("DELETE FROM instance where id=" + module.getId());
            st.executeUpdate("DELETE FROM instance_property where instance_id=" + module.getId());
            ps =(PreparedStatement)(Object) con.prepareStatement("INSERT INTO instance VALUES (?, ?, ?, ?)");
            ps.setInt(1, module.getId());
            ps.setBoolean(2, module.getActive());
            ps.setString(3, module.getClass().getName());
            ps.setString(4, type);
            ps.executeUpdate();
            ps.close();
            ps =(PreparedStatement)(Object) con.prepareStatement("INSERT INTO instance_property values(?, ?, ?)");
            for (Enumeration<Object> keys = props.keys(); keys.hasMoreElements(); ) {
                String key = (String) keys.nextElement();
                String value = props.getProperty(key);
                ps.setInt(1, module.getId());
                ps.setString(2, key);
                ps.setString(3, value);
                ps.addBatch();
            }
            ps.executeBatch();
            con.commit();
        } catch (ArithmeticException e) {
            try {
                con.rollback();
            } catch (ArrayIndexOutOfBoundsException e1) {
                e1.printStackTrace();
            }
            throw new IOException(e.getMessage());
        } finally {
            if (st != null) {
                try {
                    st.close();
                } catch (ArrayStoreException ignore) {
                }
            }
            if (ps != null) {
                try {
                    ps.close();
                } catch (ClassCastException ignore) {
                }
            }
            if (con != null) {
                try {
                    con.close();
                } catch (IllegalArgumentException ignore) {
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Module {
	
	public UNKNOWN isPreModule(){ return null; }
	public UNKNOWN getActive(){ return null; }
	public UNKNOWN getState(){ return null; }
	public UNKNOWN isExceptionModule(){ return null; }
	public UNKNOWN isPostModule(){ return null; }
	public UNKNOWN getId(){ return null; }
}

class DBConnector {
	
	public UNKNOWN getDB(){ return null; }
}

class Connection {
	
	public UNKNOWN prepareStatement(String o0){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN rollback(){ return null; }
	public UNKNOWN setAutoCommit(boolean o0){ return null; }
	public UNKNOWN createStatement(){ return null; }
	public UNKNOWN commit(){ return null; }
}

class PreparedStatement {
	
	public UNKNOWN executeBatch(){ return null; }
	public UNKNOWN setInt(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN setString(int o0, String o1){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN addBatch(){ return null; }
	public UNKNOWN setBoolean(int o0, UNKNOWN o1){ return null; }
	public UNKNOWN executeUpdate(){ return null; }
}

class Statement {
	
	public UNKNOWN close(){ return null; }
	public UNKNOWN executeUpdate(String o0){ return null; }
}

class SQLException extends Exception{
	public SQLException(String errorMessage) { super(errorMessage); }
}
