import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a20584513 {
public static UNKNOWN println(String o0){ return null; }
	public static UNKNOWN toHexString(byte[] o0){ return null; }
//public UNKNOWN toHexString(byte[] o0){ return null; }
//	public UNKNOWN println(String o0){ return null; }
    public static final String getUniqueKey()  throws Throwable {
        String digest = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            String timeVal = "" + (System.currentTimeMillis() + 1);
            String localHost = "";
            ;
            try {
                localHost = InetAddress.getLocalHost().toString();
            } catch (UnknownHostException e) {
                println("Warn: getUniqueKey(), Error trying to get localhost" + e.getMessage());
            }
            String randVal = "" + new Random().nextInt();
            String val = timeVal + localHost + randVal;
            md.reset();
            md.update(val.getBytes());
            digest =(String)(Object) toHexString(md.digest());
        } catch (NoSuchAlgorithmException e) {
            println("Warn: getUniqueKey() " + e);
        }
        return digest;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
