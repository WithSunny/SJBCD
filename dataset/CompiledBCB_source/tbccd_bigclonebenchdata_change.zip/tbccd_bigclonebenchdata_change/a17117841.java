import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17117841 {
public UNKNOWN getCharacterDataFromElement(Element o0){ return null; }
public UNKNOWN list;
	public UNKNOWN DocumentBuilderFactory;
    public  void SearchHandler(String criteria, int langId)  throws Throwable {
        try {
            URL url = new URL("http://eiffel.itba.edu.ar/hci/service/Catalog.groovy?method=GetProductListByName&criteria=" + criteria + "&language_id=" + langId);
            URLConnection urlc = url.openConnection();
            urlc.setDoOutput(false);
            urlc.setAllowUserInteraction(false);
            BufferedReader br = new BufferedReader(new InputStreamReader(urlc.getInputStream()));
            String str;
            StringBuffer sb = new StringBuffer();
            while ((str = br.readLine()) != null) {
                sb.append(str);
                sb.append("\n");
            }
            br.close();
            String response = sb.toString();
            if (response == null) {
                return;
            }
            DocumentBuilderFactory dbf =(DocumentBuilderFactory)(Object) DocumentBuilderFactory.newInstance();
            DocumentBuilder db =(DocumentBuilder)(Object) dbf.newDocumentBuilder();
            InputSource is = new InputSource();
            is.setCharacterStream(new StringReader(response));
            Document dom =(Document)(Object) db.parse(is);
            NodeList nl =(NodeList)(Object) dom.getElementsByTagName("product");
            for (int i = 0; i < (int)(Object)nl.getLength(); i++) {
                Element nodes = (Element)(Element)(Object) nl.item(i);
                String id = nodes.getAttribute("id").toString();
                NodeList name =(NodeList)(Object) nodes.getElementsByTagName("name");
                NodeList rank2 =(NodeList)(Object) nodes.getElementsByTagName("sales_rank");
                NodeList price =(NodeList)(Object) nodes.getElementsByTagName("price");
                NodeList url2 =(NodeList)(Object) nodes.getElementsByTagName("image_url");
                String nameS =(String)(Object) getCharacterDataFromElement((Element)(Element)(Object) name.item(0));
                String rank2S =(String)(Object) getCharacterDataFromElement((Element)(Element)(Object) rank2.item(0));
                String priceS =(String)(Object) getCharacterDataFromElement((Element)(Element)(Object) price.item(0));
                String url2S =(String)(Object) getCharacterDataFromElement((Element)(Element)(Object) url2.item(0));
                list.add(new ProductShort(id, nameS, rank2S, priceS, url2S));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN add(ProductShort o0){ return null; }
	public UNKNOWN newInstance(){ return null; }
}

class DocumentBuilderFactory {
	
	public UNKNOWN newDocumentBuilder(){ return null; }
}

class DocumentBuilder {
	
	public UNKNOWN parse(InputSource o0){ return null; }
}

class InputSource {
	
	public UNKNOWN setCharacterStream(StringReader o0){ return null; }
}

class Document {
	
	public UNKNOWN getElementsByTagName(String o0){ return null; }
}

class NodeList {
	
	public UNKNOWN getLength(){ return null; }
	public UNKNOWN item(int o0){ return null; }
}

class Element {
	
	public UNKNOWN getAttribute(String o0){ return null; }
	public UNKNOWN getElementsByTagName(String o0){ return null; }
}

class ProductShort {
	
	ProductShort(){}
	ProductShort(String o0, String o1, String o2, String o3, String o4){}
}
