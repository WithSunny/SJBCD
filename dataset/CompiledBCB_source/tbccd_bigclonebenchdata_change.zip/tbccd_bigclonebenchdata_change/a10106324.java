import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10106324 {
public static UNKNOWN toHexString(byte[] o0){ return null; }
//public UNKNOWN toHexString(byte[] o0){ return null; }
    public static String md5Encode(String s)  throws Throwable {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(s.getBytes());
            return(String)(Object) toHexString(md.digest());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return s;
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
