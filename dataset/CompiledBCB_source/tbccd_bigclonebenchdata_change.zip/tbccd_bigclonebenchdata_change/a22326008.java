import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a22326008 {
//    @Override
    public void sortArray(int[] array)  throws Throwable {
        boolean sorted = false;
        while (sorted == false) {
            sorted = true;
            for (int i = 0; i <= array.length - 2; i++) {
                if (array[i] > array[i + 1]) {
                    int temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
                    sorted = false;
                }
            }
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
