import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17538992 {
    public static boolean check(String urlStr)  throws Throwable {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setConnectTimeout(2000);
            urlConnection.getContent();
        } catch (Exception e) {
            UNKNOWN logger = new UNKNOWN();
            logger.error("There is no internet connection", e);
            return false;
        }
        return true;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN error(String o0, Exception o1){ return null; }
}
