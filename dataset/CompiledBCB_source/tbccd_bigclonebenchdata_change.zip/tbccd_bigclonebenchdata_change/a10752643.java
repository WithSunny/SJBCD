import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a10752643 {
public static UNKNOWN convertToHex(byte[] o0){ return null; }
//public UNKNOWN convertToHex(byte[] o0){ return null; }
    public static String MD5(String text) throws Throwable, Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(text.getBytes());
        byte[] md5hash = md.digest();
        return(String)(Object) convertToHex(md5hash);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
