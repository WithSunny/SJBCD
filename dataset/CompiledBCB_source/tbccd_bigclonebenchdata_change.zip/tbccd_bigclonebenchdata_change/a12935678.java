import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a12935678 {
public static UNKNOWN convertToHex(byte[] o0){ return null; }
//public UNKNOWN convertToHex(byte[] o0){ return null; }
    private static String makeMD5(String str)  throws Throwable {
        byte[] bytes = new byte[32];
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes("iso-8859-1"), 0, str.length());
            bytes = md.digest();
        } catch (Exception e) {
            return null;
        }
        return(String)(Object) convertToHex(bytes);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
