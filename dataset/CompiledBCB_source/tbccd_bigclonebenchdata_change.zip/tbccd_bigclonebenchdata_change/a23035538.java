import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a23035538 {
    public static void main(String[] args)  throws Throwable {
        try {
            String user = "techbeherca";
            String targetUrl = "http://api.fanfou.com/statuses/user_timeline.xml?id=" + user;
            URL url = new URL(targetUrl);
            InputStream in = url.openStream();
            ArrayList<MessageObj> list;
            if (in != null) {
                MessageListDOMParser parser = new MessageListDOMParser();
                list = (ArrayList<MessageObj>)(ArrayList<MessageObj>)(Object) parser.parseXML(in);
                TransactionDAO dao = new TransactionDAO();
                dao.insert(list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class MessageObj {
	
	
}

class MessageListDOMParser {
	
	public UNKNOWN parseXML(InputStream o0){ return null; }
}

class TransactionDAO {
	
	public UNKNOWN insert(ArrayList<MessageObj> o0){ return null; }
}
