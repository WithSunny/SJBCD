import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a4245652 {
    public InputStream getExportFile()  throws Throwable {
        URL url = ExportAction.class.getClassLoader().getResource("sysConfig.xml");
        if (url != null) try {
            return url.openStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ExportAction {
	
	
}
