import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21566853 {
    public void readURL() throws Exception {
        URL url = new URL("http://www.google.com");
        URLConnection c = url.openConnection();
        Map<String, List<String>> headers = c.getHeaderFields();
        for (String s : headers.keySet()) {
            System.out.println(s + ": " + headers.get(s));
        }
        BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
        String line = reader.readLine();
        while (line != null) {
            System.out.println(line);
            line = reader.readLine();
        }
        reader.close();
    }
}