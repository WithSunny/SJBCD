import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a1300030 {
public UNKNOWN phoneDurations;
	public UNKNOWN parseAndAdd(String o0){ return null; }
    public  void PhoneDurationsImpl(URL url) throws Throwable, IOException {
        BufferedReader reader;
        String line;
        phoneDurations =(UNKNOWN)(Object) new HashMap();
        reader = new BufferedReader(new InputStreamReader(url.openStream()));
        line = reader.readLine();
        while (line != null) {
            if (!line.startsWith("***")) {
                parseAndAdd(line);
            }
            line = reader.readLine();
        }
        reader.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
