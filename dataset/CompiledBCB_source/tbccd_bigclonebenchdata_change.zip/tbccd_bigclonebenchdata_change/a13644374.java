import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a13644374 {
public UNKNOWN EntityUtils;
	public UNKNOWN getHttpClient(){ return null; }
    public byte[] getBytesFromUrl(String url)  throws Throwable {
        try {
            HttpGet get = new HttpGet(url);
            HttpResponse response =(HttpResponse)(Object) this.getHttpClient().execute(get);
            HttpEntity entity =(HttpEntity)(Object) response.getEntity();
            if (entity == null) {
                throw new RuntimeException("response body was empty");
            }
            return(byte[])(Object) EntityUtils.toByteArray(entity);
        } catch (RuntimeException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN toByteArray(HttpEntity o0){ return null; }
	public UNKNOWN execute(HttpGet o0){ return null; }
}

class HttpGet {
	
	HttpGet(){}
	HttpGet(String o0){}
}

class HttpResponse {
	
	public UNKNOWN getEntity(){ return null; }
}

class HttpEntity {
	
	
}
