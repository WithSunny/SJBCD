import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a2640244 {
public UNKNOWN textPane;
	public UNKNOWN MessageBundle;
	public UNKNOWN StdScrollPane;
	public UNKNOWN textArea;
	public UNKNOWN getContentPane(){ return null; }
	public UNKNOWN setTitle(String o0){ return null; }
    public  void DocumentDialog(Frame frame, String title, String document)  throws Throwable {
        setTitle(title);
        textArea =(UNKNOWN)(Object) new JTextArea();
        textPane =(UNKNOWN)(Object) new StdScrollPane(textArea, StdScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, StdScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        textArea.setEditable(false);
        getContentPane().add(textPane);
        URL url = DocumentDialog.class.getClassLoader().getResource(document);
        try {
            StringBuilder sb = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
            String buildNumber =(String)(Object) MessageBundle.getBuildNumber();
            String releaseNumber =(String)(Object) MessageBundle.getReleaseNumber();
            String tmp;
            while ((tmp = in.readLine()) != null) {
                tmp = tmp.replace("${build_number}", buildNumber);
                tmp = tmp.replace("${release_number}", releaseNumber);
                sb.append(tmp + "\n");
            }
            textArea.setText(sb.toString());
            textArea.setCaretPosition(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	public UNKNOWN VERTICAL_SCROLLBAR_AS_NEEDED;
	public UNKNOWN HORIZONTAL_SCROLLBAR_AS_NEEDED;
	public UNKNOWN setEditable(boolean o0){ return null; }
	public UNKNOWN getReleaseNumber(){ return null; }
	public UNKNOWN setText(String o0){ return null; }
	public UNKNOWN getBuildNumber(){ return null; }
	public UNKNOWN add(UNKNOWN o0){ return null; }
	public UNKNOWN setCaretPosition(int o0){ return null; }
}

class Frame {
	
	
}

class JTextArea {
	
	
}

class StdScrollPane {
	
	StdScrollPane(){}
	StdScrollPane(UNKNOWN o0, UNKNOWN o1, UNKNOWN o2){}
}

class DocumentDialog {
	
	
}
