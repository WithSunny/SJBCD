import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a6863593 {
    private String hashmd5(String suppliedPassword) throws Throwable, NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(suppliedPassword.getBytes());
        String encriptedPassword = null;
        try {
            encriptedPassword = new String((byte[])(Object)Base64.encode(md.digest()), "ASCII");
        } catch (UnsupportedEncodingException e) {
        }
        return encriptedPassword;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class Base64 {
	
	public static UNKNOWN encode(byte[] o0){ return null; }
}
