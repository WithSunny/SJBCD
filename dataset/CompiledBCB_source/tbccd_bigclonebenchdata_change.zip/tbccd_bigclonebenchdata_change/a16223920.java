import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a16223920 {
public UNKNOWN getFMT(InputStream o0, boolean o1){ return null; }
    public AudioFileFormat getAudioFileFormat(URL url) throws Throwable, UnsupportedAudioFileException, IOException {
        InputStream urlStream = url.openStream();
        AudioFileFormat fileFormat = null;
        try {
            fileFormat =(AudioFileFormat)(Object) getFMT(urlStream, false);
        } finally {
            urlStream.close();
        }
        return fileFormat;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class AudioFileFormat {
	
	
}

class UnsupportedAudioFileException extends Exception{
	public UnsupportedAudioFileException(String errorMessage) { super(errorMessage); }
}
