import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a21561833 {
    private static void copyFile(String src, String dest) throws Throwable, IOException {
        File destFile = new File(dest);
        if (destFile.exists()) {
            destFile.delete();
        }
        FileChannel srcChannel = (FileChannel)(Object)new FileInputStream(src).getChannel();
        FileChannel dstChannel = (FileChannel)(Object)new FileOutputStream(dest).getChannel();
        dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
        srcChannel.close();
        dstChannel.close();
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class FileChannel {
	
	public UNKNOWN size(){ return null; }
	public UNKNOWN close(){ return null; }
	public UNKNOWN transferFrom(FileChannel o0, int o1, UNKNOWN o2){ return null; }
}
