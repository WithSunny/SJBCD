import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a17029388 {
public static UNKNOWN getConfigResource(UNKNOWN o0){ return null; }
//public UNKNOWN getConfigResource(UNKNOWN o0){ return null; }
    public static InputStream getConfigIs(String path, String name) throws Throwable, ProgrammerException, DesignerException, UserException {
        InputStream is = null;
        try {
            URL url =(URL)(Object) getConfigResource(new MonadUri(path).append(name));
            if (url != null) {
                is = url.openStream();
            }
        } catch (IOException e) {
            throw new ProgrammerException((String)(Object)e);
        }
        return is;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}

class ProgrammerException extends Exception{
	public ProgrammerException(String errorMessage) { super(errorMessage); }
}

class DesignerException extends Exception{
	public DesignerException(String errorMessage) { super(errorMessage); }
}

class UserException extends Exception{
	public UserException(String errorMessage) { super(errorMessage); }
}

class MonadUri {
	
	MonadUri(String o0){}
	MonadUri(){}
	public UNKNOWN append(String o0){ return null; }
}
