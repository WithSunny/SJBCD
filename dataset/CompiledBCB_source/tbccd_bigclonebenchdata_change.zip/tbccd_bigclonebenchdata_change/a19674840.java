import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a19674840 {
public UNKNOWN convertToHex(byte[] o0){ return null; }
    public String SHA1(String text) throws Throwable, NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md;
        md = MessageDigest.getInstance("SHA-1");
        byte[] sha1hash = new byte[40];
        md.update(text.getBytes("iso-8859-1"), 0, text.length());
        sha1hash = md.digest();
        return(String)(Object) convertToHex(sha1hash);
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	
}
