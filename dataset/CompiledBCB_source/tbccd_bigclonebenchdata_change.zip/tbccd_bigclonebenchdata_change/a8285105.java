import java.io.*;
import java.lang.*;
import java.util.*;
import java.math.*;
import java.net.*;
import java.applet.*;
import java.security.*;
class a8285105 {
public UNKNOWN URIUtil;
	public UNKNOWN containsNormalizedUriKey(URI o0){ return null; }
	public UNKNOWN getNormalizedUri(URI o0){ return null; }
	public UNKNOWN iteratorModulePaths(){ return null; }
	public UNKNOWN putNormalizedUri(URI o0, URI o1){ return null; }
	public UNKNOWN toURL(String o0){ return null; }
	public UNKNOWN normalizePath(String o0){ return null; }
    public URI normalize(final URI uri)  throws Throwable {
        URI normalizedUri = this.normalize(uri);
        if (normalizedUri.equals(uri)) {
            String resourceName = uri.toString().replaceAll(".*(\\\\+|/)", "");
            if (!(Boolean)(Object)containsNormalizedUriKey(uri)) {
                for (Iterator<Path> iterator =(Iterator<Path>)(Object) this.iteratorModulePaths(); iterator.hasNext(); ) {
                    String searchPath =(String)(Object) iterator.next().getPath();
                    String completePath =(String)(Object) this.normalizePath(searchPath + '/' + resourceName);
                    try {
                        InputStream stream = null;
                        URL url =(URL)(Object) toURL(completePath);
                        if (url != null) {
                            try {
                                stream = url.openStream();
                                stream.close();
                            } catch (Exception exception) {
                                url = null;
                            } finally {
                                stream = null;
                            }
                            if (url != null) {
                                normalizedUri =(URI)(Object) URIUtil.createUri(url.toString());
                                this.putNormalizedUri(uri, normalizedUri);
                                break;
                            }
                        }
                    } catch (Exception exception) {
                    }
                }
            } else {
                normalizedUri =(URI)(Object) getNormalizedUri(uri);
            }
        }
        return normalizedUri;
    }
}
// Code below this line has been added to remove errors
class UNKNOWN {
	
	public UNKNOWN createUri(String o0){ return null; }
}

class Path {
	
	public UNKNOWN getPath(){ return null; }
}
